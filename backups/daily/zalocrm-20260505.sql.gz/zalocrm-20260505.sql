--
-- PostgreSQL database dump
--

\restrict dyvyDPCNwUQJbqTPPM1cxwbKti1kYhU1OllTkB7aVejgEAWV5yFBalvg2mFthSn

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.activity_logs (
    id text NOT NULL,
    org_id text NOT NULL,
    user_id text,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.activity_logs OWNER TO crmuser;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.app_settings (
    id text NOT NULL,
    org_id text NOT NULL,
    setting_key text NOT NULL,
    value_plain text,
    value_encrypted bytea,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.app_settings OWNER TO crmuser;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.appointments (
    id text NOT NULL,
    org_id text NOT NULL,
    contact_id text NOT NULL,
    assigned_user_id text,
    appointment_date timestamp(3) without time zone NOT NULL,
    appointment_time text,
    type text,
    status text DEFAULT 'scheduled'::text NOT NULL,
    notes text,
    reminder_sent boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.appointments OWNER TO crmuser;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.contacts (
    id text NOT NULL,
    org_id text NOT NULL,
    zalo_uid text,
    phone text,
    email text,
    full_name text,
    avatar_url text,
    source text,
    source_date timestamp(3) without time zone,
    first_contact_date timestamp(3) without time zone,
    status text DEFAULT 'new'::text,
    next_appointment timestamp(3) without time zone,
    assigned_user_id text,
    notes text,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contacts OWNER TO crmuser;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.conversations (
    id text NOT NULL,
    org_id text NOT NULL,
    zalo_account_id text NOT NULL,
    contact_id text,
    "threadType" text DEFAULT 'user'::text NOT NULL,
    external_thread_id text,
    last_message_at timestamp(3) without time zone,
    unread_count integer DEFAULT 0 NOT NULL,
    is_replied boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversations OWNER TO crmuser;

--
-- Name: daily_message_stats; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.daily_message_stats (
    id text NOT NULL,
    org_id text NOT NULL,
    user_id text NOT NULL,
    zalo_account_id text NOT NULL,
    stat_date date NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    messages_received integer DEFAULT 0 NOT NULL,
    messages_unread integer DEFAULT 0 NOT NULL,
    messages_unreplied integer DEFAULT 0 NOT NULL,
    avg_response_time_seconds integer
);


ALTER TABLE public.daily_message_stats OWNER TO crmuser;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.messages (
    id text NOT NULL,
    conversation_id text NOT NULL,
    zalo_msg_id text,
    sender_type text NOT NULL,
    sender_uid text,
    sender_name text,
    content text,
    content_type text DEFAULT 'text'::text NOT NULL,
    attachments jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone NOT NULL,
    replied_by_user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.messages OWNER TO crmuser;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.orders (
    id text NOT NULL,
    org_id text NOT NULL,
    contact_id text NOT NULL,
    created_by_user_id text NOT NULL,
    conversation_id text,
    order_code text NOT NULL,
    total_amount double precision NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO crmuser;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.organizations (
    id text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.organizations OWNER TO crmuser;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.teams (
    id text NOT NULL,
    org_id text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.teams OWNER TO crmuser;

--
-- Name: users; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.users (
    id text NOT NULL,
    org_id text NOT NULL,
    team_id text,
    email text NOT NULL,
    password_hash text NOT NULL,
    full_name text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO crmuser;

--
-- Name: zalo_account_access; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.zalo_account_access (
    id text NOT NULL,
    zalo_account_id text NOT NULL,
    user_id text NOT NULL,
    permission text DEFAULT 'read'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.zalo_account_access OWNER TO crmuser;

--
-- Name: zalo_accounts; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.zalo_accounts (
    id text NOT NULL,
    org_id text NOT NULL,
    owner_user_id text NOT NULL,
    zalo_uid text,
    display_name text,
    avatar_url text,
    phone text,
    status text DEFAULT 'disconnected'::text NOT NULL,
    session_data jsonb,
    last_connected_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.zalo_accounts OWNER TO crmuser;

--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.activity_logs (id, org_id, user_id, action, entity_type, entity_id, details, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.app_settings (id, org_id, setting_key, value_plain, value_encrypted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.appointments (id, org_id, contact_id, assigned_user_id, appointment_date, appointment_time, type, status, notes, reminder_sent, created_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.contacts (id, org_id, zalo_uid, phone, email, full_name, avatar_url, source, source_date, first_contact_date, status, next_appointment, assigned_user_id, notes, tags, metadata, created_at, updated_at) FROM stdin;
bd7af861-3466-4c49-bfbd-fcc12733f9ca	ecae3be0-2ff7-4547-bf7a-308be16a20ad	246336029840242028	0925525263	hiephiep1002@gmail.com	LEO SLAYER VÀ NHỮNG NGƯỜI BẠN LORDS MOBILE	\N	FB	\N	2222-01-20 17:00:00	new	2323-03-01 17:00:00	\N	\N	[]	{"isGroup": true}	2026-05-02 04:58:31.389	2026-05-02 06:27:03.834
3818c757-0a5c-4139-848f-1c8c94a9d267	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4860181653371989109	\N	\N	KHOÁ LUẬN K17	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-02 07:09:03.168	2026-05-02 07:09:03.168
2f8c4bc5-fea1-4f9c-8f21-7bd4352de60e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8810000927059780676	\N	\N	Team Thực tập	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-02 14:14:26.559	2026-05-02 14:14:26.559
38fd2550-b5cc-4b25-aad2-261494be2147	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8590853056949506623	\N	\N	Vu Xuân Trường	https://s120-25-ava-talk.zadn.vn/50/a5d7279981b52c6e0d13934ee683f43f.jpg?key=BwYZvmwBODscPe88wrKAZg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.501	2026-05-04 02:46:13.501
2853cbcb-93ad-49e8-993d-a78e992a7514	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3365195044584063156	\N	\N	Thành Vinh	https://s120-25-ava-talk.zadn.vn/9/1d82a952930a2f7e1e417707bcf59421.jpg?key=Kk2VebyuUZ4VllCfqZCobg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.54	2026-05-04 02:46:13.54
d7895e02-a228-4f3a-8d45-c904e245e74e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5199815831260101678	\N	\N	Bảo Vân	https://s120-25-ava-talk.zadn.vn/17/a468f65558656518657f74b04c96fc04.jpg?key=dBnBEM1nl21R__PpQZmWUA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.555	2026-05-04 02:46:13.555
5bf0e2a3-3d0e-4fe9-8053-83bbacb4e18e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2377225580510953722	\N	\N	Bình Hải	https://s120-25-ava-talk.zadn.vn/8/c069d8aa8b7ea7b9e058e0a4fd0183d1.jpg?key=vRv6TpZpFcoYRemBfL2oOQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.568	2026-05-04 02:46:13.568
ecbd92df-a6d0-47c2-95f7-3592f75a444e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6997004832864396829	\N	\N	Tuấn Phương	https://s120-25-ava-talk.zadn.vn/11/45a05f856c50c2937080a9760d831f75.jpg?key=1zMYQxy3pfBPusUbQ7tsiA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.578	2026-05-04 02:46:13.578
24df0eb3-f670-49ed-a118-99a110c09feb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4363568070414806921	\N	\N	Lê Trung Hiếu	https://s120-25-ava-talk.zadn.vn/9/34c8c15b2c3ef696ccf2ea1951a13000.jpg?key=NMOaeZHHz9OTWebJNgM6cg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.586	2026-05-04 02:46:13.586
531b091d-2852-4b81-af7a-992d79b8693b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1318766047664325194	\N	\N	Minh Lâm	https://s120-25-ava-talk.zadn.vn/19/300552fa1e5fb484e2413f5804e9b6f4.jpg?key=BR1wg02mt0WaCmGwHFEk6g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.594	2026-05-04 02:46:13.594
1772f6a4-8a38-486a-9573-64b988d3be8a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3370964796099328975	\N	\N	Tuan	https://s120-25-ava-talk.zadn.vn/13/9fc14af5f6785d0521689c41b6e931b9.jpg?key=V1ZWoPhovEUScV0jYRnHOA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.6	2026-05-04 02:46:13.6
f5c4be65-d5d4-4fe8-810e-0684c13efa9a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1130453685897962167	\N	\N	Bhuy	https://s120-25-ava-talk.zadn.vn/7/047d22584e3688d5ccf226f7e4e99ece.jpg?key=KXRgTy1PbwUXb2ZKBVI6eQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.606	2026-05-04 02:46:13.606
a0fb7f51-eb1d-4789-a7d2-3d37dbdef149	ecae3be0-2ff7-4547-bf7a-308be16a20ad	892335756337869669	\N	\N	Học Giếng Khoan	https://s120-25-ava-talk.zadn.vn/57/ccbe5080d90c0609b23fb70b9da336cb.jpg?key=NQhI1nVtOY2yOgtZaZ1UBg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.613	2026-05-04 02:46:13.613
fb548f4e-94ad-4fb5-928f-aabf505c2d61	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5874788356599630720	\N	\N	Thắng Trần	https://s120-25-ava-talk.zadn.vn/21/f715c38edb2c4cae7d124f45276c8f40.jpg?key=vI_NtteF8pwJ7lgBMVvRlA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.62	2026-05-04 02:46:13.62
288a6492-1754-438b-b4e8-18a6546179e1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7533351490509930124	\N	\N	Quân	https://s120-25-ava-talk.zadn.vn/35/c316e9cfd6db16597a42c91a1085b9f2.jpg?key=Af5piiZr0U2A_lZn0MP_WA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.638	2026-05-04 02:46:13.638
056ae7a4-b1d2-404f-af94-d2c122b6ccdd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5529985907955986361	\N	\N	Thanh Huyền	https://s120-25-ava-talk.zadn.vn/139/698427b826a07cb208e62e1bd6747ae4.jpg?key=2Ezn_iZQeopD6rUV68LLUQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.651	2026-05-04 02:46:13.651
bc22012e-399d-4400-aaf8-6bb19a3d8914	ecae3be0-2ff7-4547-bf7a-308be16a20ad	968339493716156535	\N	\N	Phạm Anh Tuấn	https://s120-25-ava-talk.zadn.vn/45/245be5efe0ece3eb6989d8c0ece1bdd1.jpg?key=AQpQkA3ACOf5rwDhmIs_TQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.667	2026-05-04 02:46:13.667
37e18989-f91e-4dc5-8ac4-baac76afe98d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9112994558292890736	\N	\N	tung phat	https://s120-25-ava-talk.zadn.vn/2/4743bf5f3fc59ddd0caf006f4e9418de.jpg?key=kXDglAsOIBy_p0vn-1eGlQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.676	2026-05-04 02:46:13.676
b0d0fac3-ba33-495e-9a98-fb88f11f3d98	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7491386531983166705	\N	\N	Hùng	https://s120-25-ava-talk.zadn.vn/1/16f15a2c7f8714a28efcc01e8e546145.jpg?key=dGtyuUsj9XAL_Z7P5NLjMQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.684	2026-05-04 02:46:13.684
598f079c-9423-4488-8338-673d762118cc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1391940534205472598	\N	\N	Nguyễn Văn Quyết	https://s120-25-ava-talk.zadn.vn/18/10822971154fd0ce762285e8f382e45a.jpg?key=ZU1YuEkCCCoVw_7xT1RizA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.69	2026-05-04 02:46:13.69
47e138af-b4de-40f6-8e5e-1c7cf90ec917	ecae3be0-2ff7-4547-bf7a-308be16a20ad	106465284304135805	\N	\N	Minh Vương	https://s120-25-ava-talk.zadn.vn/21/7421420438ee8cf99f808f581b5a7f15.jpg?key=1NGTNbQYYXCMv2bG_IfZ5g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.695	2026-05-04 02:46:13.695
bc337a04-7c4f-499e-b0b0-eee163c576c3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5027984576024583873	\N	\N	Nguyễn Đình Thuật	https://s120-25-ava-talk.zadn.vn/10/6317ec417b8dd4df39a8048ac3bb3463.jpg?key=DkifDKLlfAxoJ0CyPHq5Eg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.7	2026-05-04 02:46:13.7
e341c945-3a7f-4b73-9f62-1df1f4c1903e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7973708775326145455	\N	\N	Hưng Nguyễn	https://s120-25-ava-talk.zadn.vn/3/24db55890f4814b7044aa6f9797dd838.jpg?key=U5hMPGAlDMTjYdjGjg-M-w&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.705	2026-05-04 02:46:13.705
ece0f557-ff74-425f-8844-6f62c83922f6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5843532481371558943	\N	\N	Zalo	https://s120-25-ava-talk.zadn.vn/36/16782d311b12da6d28daa13e343986b8.jpg?key=OTUaPptq6lZULMEXjNAHsQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.712	2026-05-04 02:46:13.712
37605307-e718-466c-849c-8f5f1a98e854	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1020544710927759918	\N	\N	Đati	https://s120-25-ava-talk.zadn.vn/37/0bf74bd37a074d1e9f0d545e07755798.jpg?key=KgojBiShsfxiHUnEPvn83Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.724	2026-05-04 02:46:13.724
04889a8f-1603-4a2b-a838-2e4dfb4f072d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	813938803663625548	\N	\N	Huệ	https://s120-25-ava-talk.zadn.vn/101/a61a879fda9581de34de1b23d1634170.jpg?key=Wg6E6pgTIrMBScoO8JkYrA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.731	2026-05-04 02:46:13.731
043b2e0c-eb3a-471a-bdbc-7ec6a35a595c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5589094428963815575	\N	\N	An Nguyễn	https://s120-25-ava-talk.zadn.vn/1/87495ea8651a2c11c861bde3a502c6f4.jpg?key=2bwGBZXTVrvkNGe4h53bCA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.736	2026-05-04 02:46:13.736
f2e776db-580d-4440-99ac-c467416377fd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6663625746799179902	\N	\N	Bao Bao	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.741	2026-05-04 02:46:13.741
8fc9e7ee-646c-45af-96b4-37cb4777c8b3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5227378038088588940	\N	\N	Nguyễn Sỹ Hiển	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.746	2026-05-04 02:46:13.746
23d3d1b9-a59b-4ab1-bf32-ac4737a40438	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6142746758236927800	\N	\N	Nguyễn Nhật Huỳnh	https://s120-25-ava-talk.zadn.vn/14/100eedf230c8fcc7a2d5f1c5091a721e.jpg?key=njyT7sLznmPf9RLlpLAWMA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.751	2026-05-04 02:46:13.751
18dae6d2-40b0-4934-96f4-603137263691	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8652078511014082325	\N	\N	Tiến Lộc	https://s120-25-ava-talk.zadn.vn/6/961eb945114df9ff085bb84343eaf0c6.jpg?key=qpeUvZDQX6F-HKCIAgX4TQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.759	2026-05-04 02:46:13.759
62271160-a4f7-4b31-b1e6-f522e568c5b4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6918032632913067014	\N	\N	Đình Ngân	https://s120-25-ava-talk.zadn.vn/4/dd103a5fcdc46b42458a6e03d3a85d8a.jpg?key=N7rzGsKh9LGMxRt1jzbaKg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.769	2026-05-04 02:46:13.769
e97244c8-c51a-4195-88a5-4ec4ebcc57ec	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7624815288856388823	\N	\N	David Lee	https://s120-25-ava-talk.zadn.vn/8/a334ef703a73fcb0379f2ba1c037c16c.jpg?key=HwqdHwoB2RKtLouxTipqZA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.775	2026-05-04 02:46:13.775
8cab9e0f-dfe9-4575-9296-7ff83c2dd61b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	442689131821776675	\N	\N	Trân	https://s120-25-ava-talk.zadn.vn/100/b1d08d2df83aab4633f925411628ee9d.jpg?key=Y_r34wnXAAY11eE79g3new&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.782	2026-05-04 02:46:13.782
f18cd854-a4c8-41b2-81ec-c6effc1d0296	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2075914187392143048	\N	\N	Trần Anh	https://s120-25-ava-talk.zadn.vn/22/713eb3a5350638c062edcdfc57215ad8.jpg?key=A6CJGST-yvulEw0dNtfdOQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.789	2026-05-04 02:46:13.789
d4719b63-e866-4004-b967-c7658e424f05	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5531375484717339332	\N	\N	Nguyễn	https://s120-25-ava-talk.zadn.vn/2/01072ef43e0d3554e40a419973036a88.jpg?key=kfCzUVreXdz6V1NPxJwu-Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.794	2026-05-04 02:46:13.794
f96ae4e7-af46-4ff3-b877-ce3c7537eed7	ecae3be0-2ff7-4547-bf7a-308be16a20ad	810978846930818886	\N	\N	Larry Nguyễn Hà	https://s120-25-ava-talk.zadn.vn/13/e7dddbbe91176868021bbe76cac86219.jpg?key=9ktmOSdztKZILL3zSvb7Qw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.798	2026-05-04 02:46:13.798
badebfff-4793-48e0-a703-c5c992698743	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7826078619176594076	\N	\N	Trần Trọng Phúc	https://s120-25-ava-talk.zadn.vn/10/67e43fa6c8ff94903f55c347a1a69ba3.jpg?key=V_2lFqvJzRmK8_6Zz1YtTg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.803	2026-05-04 02:46:13.803
496ac803-d14b-498e-8b0c-bf120a6f3f5b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9155780683281460488	\N	\N	Thuần	https://s120-25-ava-talk.zadn.vn/92/4d0dd370c6222f4d89b5eee3409ff6b8.jpg?key=Tqe8yeJS1R0-zUfBOFOgTQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.808	2026-05-04 02:46:13.808
daeb12c2-4895-4046-8a9d-712a7c573298	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1824701401457481301	\N	\N	Nghĩa Nv	https://s120-25-ava-talk.zadn.vn/6/17598219110c7a6719e15f93358e45e0.jpg?key=W-lbyI2FOUsoYRfXCAdP6g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.812	2026-05-04 02:46:13.812
8b70da1a-b73b-4493-82a5-24162d7eb55f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6659667179765541484	\N	\N	Ms Loan Giảng Viên Tiếng Anh	https://s120-25-ava-talk.zadn.vn/321/86de4bf90952554691e221b8cf232de1.jpg?key=-4DpGTxhaXhgX8H1esKRfA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.819	2026-05-04 02:46:13.819
8bf07684-6b35-4655-9000-5a9e5db08d5d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3510152909233036209	\N	\N	Vân nguyễn	https://s120-25-ava-talk.zadn.vn/12/7ade927de5dd3f61c699b8c28cc84c94.jpg?key=U56NJ16EWFZmKi7HmAFF9Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.824	2026-05-04 02:46:13.824
29691e33-46d3-4cf4-b370-1441912b5cd3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6794776306049124428	\N	\N	Mai Văn Minh	https://s120-25-ava-talk.zadn.vn/13/a4718df15a7c580add89b78633be2cc4.jpg?key=R58Jmz5KP4QALBsXQZkTiw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.828	2026-05-04 02:46:13.828
938be2c1-208c-4150-863c-6ccd0b0cb282	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4422396749875642200	\N	\N	Khánh Huy	https://s120-25-ava-talk.zadn.vn/11/194efd5652ad9c6facf07b36717f0d9d.jpg?key=jCvkJ0OVzAd8bubGOMBvPg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.835	2026-05-04 02:46:13.835
644c2723-fb12-4c36-9e10-5d15a2aee155	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5436396812168505206	\N	\N	Huy	https://s120-25-ava-talk.zadn.vn/26/31d4e9d2ff38e158584691184cdd1bcc.jpg?key=Z7ybNbBFb6-0XlJkItOU1Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.842	2026-05-04 02:46:13.842
5ef79c56-726a-4f8a-82df-3b671c2dfa12	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4719316730111107705	\N	\N	Phạm Mỹ Linh 美玲	https://s120-25-ava-talk.zadn.vn/83/9596d80db8b425deabc87ff49b5f833c.jpg?key=c0bsrWWa6N8CN5qTVgIbGg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.851	2026-05-04 02:46:13.851
fcd70979-0579-4c77-8fc1-5fb4110f84a9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2040756076357997397	84902430743	\N	Minh Nghĩa	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.877	2026-05-04 02:46:13.877
38590d90-e132-4db2-8887-b3e0d535966f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7282564884786440215	\N	\N	Lê Thế Dũng	https://s120-25-ava-talk.zadn.vn/3/b4f4cb28e8af27925360db5b6c5dd2c3.jpg?key=-HvY2Hcr9zDBvxKR58iVlA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.899	2026-05-04 02:46:13.899
33b2039e-0535-4edb-bca2-0cf5adb79f40	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7354752719437490710	\N	\N	Chàng Khờ Thủy Chung	https://s120-25-ava-talk.zadn.vn/18/dd7c8335ec4eb496e730ed7235a32263.jpg?key=6B3TA86-qaGulUcrckr2Ww&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.91	2026-05-04 02:46:13.91
acc2ecce-0ad6-48ea-be26-6c8a93844a61	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4849218015667787084	84794695728	\N	Lê Q Phú	https://s120-25-ava-talk.zadn.vn/13/4478b811c9463e4ca424f77482ccfdfe.jpg?key=8ss6qk_segMbh810A_UQmw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.929	2026-05-04 02:46:13.929
ef09ddcd-862a-4214-aa46-cf706d845c94	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5040625366319279092	\N	\N	Quang	https://s120-25-ava-talk.zadn.vn/15/fcd7749f0ccc73889166db174fe8737e.jpg?key=FP7rfkXguTThr9M8fk2o-g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.937	2026-05-04 02:46:13.937
11db9069-8490-41ae-b9a6-39a5333eae98	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1096119383979435057	\N	\N	Quốc Trung	https://s120-25-ava-talk.zadn.vn/21/cbea508cdef4e463f2f785e6c8a5034b.jpg?key=sKx615yJR0Oob2qVNMcVVA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.946	2026-05-04 02:46:13.946
a8dccc00-fdc6-484b-a9cb-1e20e9e0b777	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3575175767328469402	\N	\N	Nguyễn Hương	https://s120-25-ava-talk.zadn.vn/64/d699749a3bd6474b4e61e826c99953f2.jpg?key=ISWeXcDFlso-kBd1f5GsLg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.953	2026-05-04 02:46:13.953
486e0338-c5d5-43bd-a097-1f5f4f067af0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4552437174917173034	\N	\N	Bùi Minh Hiếu	https://s120-25-ava-talk.zadn.vn/16/585c0cf1796f4af4899ef3b2381cd817.jpg?key=t96nIMJ4iZIKb-wWMBFZSg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.969	2026-05-04 02:46:13.969
f86834b0-a8af-4ec0-bb3f-06e3cb05c7f9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2533279186909697583	\N	\N	Lê Đình Quang	https://s120-25-ava-talk.zadn.vn/2/f2ac5fcb311f3834945606f81e0749e4.jpg?key=7rrvTT_G61rpb_lWMJcpww&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.982	2026-05-04 02:46:13.982
ac181ede-3900-46b7-9e25-bdab949b730e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3571090561630184328	\N	\N	Phan Bá Bình	https://s120-25-ava-talk.zadn.vn/5/83485c8d4d762b75a28654e15cacf949.jpg?key=iQM-e3OzYoCZ134nqmWp1g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.989	2026-05-04 02:46:13.989
bc3c5456-dedb-4c9b-bd39-5f463ae9b3da	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6976290491141041623	\N	\N	Kim Duy	https://s120-25-ava-talk.zadn.vn/24/b79a18d00fd5959a2fdf85118f751504.jpg?key=OK8pwXcKjS4Ken7fBLUtTw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.995	2026-05-04 02:46:13.995
7429421c-051c-492b-ba9b-9d8d1082c712	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4032279182712627186	84909735707	\N	Van Anh	https://s120-25-ava-talk.zadn.vn/1/38ead18addf174ae886e85f97f2c6149.jpg?key=1oGImPXcCcohN9smr0cViQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.004	2026-05-04 02:46:14.004
5b2f058c-c260-43d7-b4ed-1aeb91c1bf3d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3115939052991645753	84363633072	\N	Phạm Huy Hoàng	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.01	2026-05-04 02:46:14.01
95730d4b-7a75-4a0e-99a1-17c4fa22aa19	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7180921203648944544	\N	\N	Lê Quốc Kỳ	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.016	2026-05-04 02:46:14.016
1ec4acb7-a8e8-4d1c-b655-32d85ea30c33	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2781427507630744222	\N	\N	Huỳnh Anh	https://s120-25-ava-talk.zadn.vn/153/a759af2c1ec546f8e7ffbe0fa48a2ce6.jpg?key=5oVBoasV_zHPJpbaF7M8fg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.022	2026-05-04 02:46:14.022
83fe060e-4d72-4e7d-969b-56ea3315538f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	542162771176889473	\N	\N	Nguyễn Thị Tú Trinh	https://s120-25-ava-talk.zadn.vn/38/72c95b3f34b3929d3021e70c158255f0.jpg?key=0JkNnLL1jc7CSR7CIvxe-Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.037	2026-05-04 02:46:14.037
2bd5f205-1d7e-49fe-a050-a2f0f44c7e42	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5957113213587088556	\N	\N	Lieu Nguyen	https://s120-25-ava-talk.zadn.vn/13/73d937a55b7cfef46c71b5f6e1cac14a.jpg?key=6qmbDnjnrJsPD1pE3Jhu2g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.05	2026-05-04 02:46:14.05
38f33647-d81e-4af8-9e5b-3371c2e6c64d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9034324555011293287	\N	\N	Thu Hà	https://s120-25-ava-talk.zadn.vn/8/36034afbeb33a8543ef31db9a9eeea95.jpg?key=hMMjnGG6tj-HAR1U8lqGbw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.063	2026-05-04 02:46:14.063
e17e80d0-4c8b-406d-bddf-0e2cc1599b8d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3856501922686217602	\N	\N	Nguyễn Nhật Hiếu	https://s120-25-ava-talk.zadn.vn/77/e24ff516cc6af3a82cdba2f9d189009e.jpg?key=G5_LUD8zMiv5vp9aG61SzA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.075	2026-05-04 02:46:14.075
903bfba9-dd84-4fba-9883-6ade7caaac25	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6339501809145327869	\N	\N	Kim Thoa- Đào Tạo Lái Xe	https://s120-25-ava-talk.zadn.vn/33/ac2275d7667a59584e10fba08bce1e7b.jpg?key=RbskoPXAslD8F3a_FsJMVQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.081	2026-05-04 02:46:14.081
7fe71d4d-84cf-4e87-a3e6-6de70113fddc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1064450961613248194	\N	\N	Kiều My	https://s120-25-ava-talk.zadn.vn/43/ff87850e46c85968f9f0f62ccb37b076.jpg?key=GlgL2hIbD0a1uBa0U277aA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.086	2026-05-04 02:46:14.086
67d41cab-da0e-4e77-8f36-67a497e83217	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2452072241461835776	\N	\N	Le Van Dang	https://s120-25-ava-talk.zadn.vn/4/1e86c2a82aca74bc02a65d33cd564f63.jpg?key=Oxh4zqTT7-rh4yE1YsaI3A&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.091	2026-05-04 02:46:14.091
9124af08-d273-4f01-93d0-24fa620dc568	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1326355304159373167	\N	\N	Thomnguyen	https://s120-25-ava-talk.zadn.vn/54/393299a6d410ac513dc0ff1675284287.jpg?key=koTZE3PzfUkcOx7ovWexiQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.096	2026-05-04 02:46:14.096
d6929b00-c2b3-4cc6-8133-869358feb623	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4674710980990436056	\N	\N	Nguyễn Duy Thắng	https://s120-25-ava-talk.zadn.vn/2/3475481e43644b83753687e9189bc13b.jpg?key=Yp1YcFUPvw7CiGZmrXAg5g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.104	2026-05-04 02:46:14.104
7d4a47e0-934c-4e9d-828f-6d648b03f17d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7057244415670324471	\N	\N	Jackie	https://s120-25-ava-talk.zadn.vn/18/9572a966315c623fe33252787844ef66.jpg?key=k3OSbjAxJBhB0BjfsZntoQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.113	2026-05-04 02:46:14.113
dd7f59ce-338e-49dd-8e6e-9d433ce2c6c0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5611606458481225959	84764390598	\N	Hồng Cẩm	https://s120-25-ava-talk.zadn.vn/1/721f4322f62b1a1407322b6c47e0f376.jpg?key=fn4rlJGy7iZhwvKY0dApvA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.125	2026-05-04 02:46:14.125
35542fad-3130-489b-aa7a-b1d74d100b9c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3429230737531381136	84385099660	\N	Nguyễn Nhật Tân	https://s120-25-ava-talk.zadn.vn/22/9c63e1ee30951fde9a97fa8a161d4f8a.jpg?key=0xusOdJCoiThL_YhXlrgMQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.131	2026-05-04 02:46:14.131
cdf8da9d-5ab7-47dc-bc02-6514b38d2d34	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8876243584966445097	\N	\N	Lê Hoàn Khôi	https://s120-25-ava-talk.zadn.vn/82/4bc99d7bc4326cb188f3fe348f36facc.jpg?key=qqn8X5L8yOobwdpjzH5Bcw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.136	2026-05-04 02:46:14.136
51e07482-0a66-4441-bee4-317f852259e8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5551645509194865420	\N	\N	Minh Hiêp Qwertyuiop	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.142	2026-05-04 02:46:14.142
7e02e7da-695e-4599-8d4e-c124c941b98e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	901340546993263493	\N	\N	Tú Tú	https://s120-25-ava-talk.zadn.vn/145/655eee16b34b7dfe6bdc8de4aba71061.jpg?key=_vfjNKEPHIllr0mlOa9lYA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.152	2026-05-04 02:46:14.152
4ffbb4be-3acc-4686-99e3-55e4849f2133	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5654813209257618046	\N	\N	Mạnh Dũng	https://s120-25-ava-talk.zadn.vn/6/4ad5ad1b223d1deb998f7727e0290405.jpg?key=Pp86zmh3GO7ukRilPIQFQA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.162	2026-05-04 02:46:14.162
87e72a63-c2a4-449b-b2eb-b1505361537b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6927341688400109349	\N	\N	Nguyễn Ngọc Thiên	https://s120-25-ava-talk.zadn.vn/4/5d252266f109e179b49a6fc989a90b4d.jpg?key=QiaFdLgaSNEI6ieXO24wSw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.171	2026-05-04 02:46:14.171
4b11736b-2761-4568-b529-5a7f357fc282	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4044237181756998951	\N	\N	Nguyễn Phước Thảo Prateek Dhavan Desai	https://s120-25-ava-talk.zadn.vn/83/246875e6df4d788016454091e08c54f7.jpg?key=_16jEQmAhxsVD-ZnAQ9Idw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.181	2026-05-04 02:46:14.181
b9cb44c8-2272-4e13-bd1a-af8888945994	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5952478041105487004	\N	\N	Phạm Thu Hà	https://s120-25-ava-talk.zadn.vn/9/f12b11659b403f48723c2bc8ba997e4f.jpg?key=FaHcJGKLG8a1TGl0WQH3Hw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.192	2026-05-04 02:46:14.192
2ed15bd3-bb66-4a70-97fe-cade0dd8611b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	275744278983921108	\N	\N	Lương Quỳnh Như	https://s120-25-ava-talk.zadn.vn/27/da0c2937489cff379e8883df17a731f8.jpg?key=fkyp0RFGnHzkqxpZld6MMw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.208	2026-05-04 02:46:14.208
292f34b3-c363-4d3e-ae9a-f013fddd87cf	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3910120434033879108	\N	\N	Phạm Quang Bảo	https://s120-25-ava-talk.zadn.vn/12/7ac29eab2b8dcee40e919b43c89c4cbe.jpg?key=GL8p9j_q0-ytE-6TuFwLkw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.221	2026-05-04 02:46:14.221
e1ec30eb-2c6c-44f6-9f1b-8036ab4885cc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5490717712440025909	\N	\N	Trần Ngọc Vân Anh	https://s120-25-ava-talk.zadn.vn/49/30981082c519f13477671964342451d8.jpg?key=KUEnMxA_NfbFWDP8r7DF_Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.225	2026-05-04 02:46:14.225
d57d5c0d-3518-44e5-abc6-2a8c135b89a0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6430549551320135994	\N	\N	Thu Dung	https://s120-25-ava-talk.zadn.vn/5/cd60de0b0f9595fe2c5e9a14add418aa.jpg?key=ktTcz0PBPsaudyoHQZLmrg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.231	2026-05-04 02:46:14.231
8351f2d5-11c0-4de2-9a2f-39e1f03624c4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8591273844798509117	\N	\N	Đặng Đức Minh Quang	https://s120-25-ava-talk.zadn.vn/14/571d1d240bfb31b814eb8880b2d76c66.jpg?key=p_wV5B5dCS6JnNgiL4yEKQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.235	2026-05-04 02:46:14.235
ae34b58c-9fdb-4a9c-9e65-0e122b9dff31	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7438063194402374462	\N	\N	Đào Ngọc Huy	https://s120-25-ava-talk.zadn.vn/13/7063441ea3f8f5e42d7b69b2bff858aa.jpg?key=hjbC27b-xgxgKsoIYLQXqA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.245	2026-05-04 02:46:14.245
b23f0485-9bf0-4cfa-8382-41c41130c263	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8342727054413244864	\N	\N	Trần Nguyễn Ngọc Quý	https://s120-25-ava-talk.zadn.vn/2/6fd61835f2f1207733488db75eec7a65.jpg?key=564V2c7bGxV8Me0wkz3WHg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.258	2026-05-04 02:46:14.258
69296328-5815-4a3f-bae0-f0bc3311191b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6491652595667357969	\N	\N	Triệu Hoàng Vinh	https://s120-25-ava-talk.zadn.vn/4/142786e2e28893f800bd68c5fd174cc5.jpg?key=wsejnMZ6A_wXbSGeekITVA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.274	2026-05-04 02:46:14.274
db42ee72-6b12-43c9-a38f-e95c3f91812f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7024021364864157309	\N	\N	Kim Tiền 阿銭	https://s120-25-ava-talk.zadn.vn/60/1ee3ebfbe6a912159ed4fa0cc1df90bd.jpg?key=6TVmTURyQnADt4xgKXZtTQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.279	2026-05-04 02:46:14.279
bb27d378-6492-4666-a783-d7e2f2c85844	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8489507024238786775	\N	\N	Lê Thị Khánh Ly	https://s120-25-ava-talk.zadn.vn/18/c85e9004e94778ffa4379bd46b2e292a.jpg?key=-R3OU1lbNtGW2bmK0fbuPw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.285	2026-05-04 02:46:14.285
e3e6fb31-48b6-450d-9a9b-cec9da93d1d0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3307485938597615329	\N	\N	Gạch men Tài Phát Lộc	https://s120-25-ava-talk.zadn.vn/7/0f19a7a96d742a8865aa35b726e02d71.jpg?key=d3g1HiKntCLaHLUwL8QkMg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.291	2026-05-04 02:46:14.291
4a49ef64-b46a-45a8-b5ed-890e9860fa51	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8574809374670427384	\N	\N	Hoàng Quốc Tú	https://s120-25-ava-talk.zadn.vn/5/deb324c989c197b41d04a2385801efd7.jpg?key=n7GYfrp4BI7ILgTDk94Ezg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.295	2026-05-04 02:46:14.295
f95e7ad4-4626-4abd-a290-de9a1e4e07e8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8222811147174081050	\N	\N	Thanh Trần	https://s120-25-ava-talk.zadn.vn/6/78ed14391a8ec8488e9d2026c8644c0e.jpg?key=vPMH3ViUhZ_3MGE8icNs6g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.303	2026-05-04 02:46:14.303
55f320f3-2ddf-49d9-89d6-074cf39b7f05	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8512023950613203751	\N	\N	Bích Ngọc	https://s120-25-ava-talk.zadn.vn/5/0c4b461d4d67106056d5c0787872024a.jpg?key=5qrJcQi1clH4TEaK11-l9w&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.311	2026-05-04 02:46:14.311
6ab896ff-244b-45f6-a521-27859d9cd818	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3617953891114654258	\N	\N	Mẫn Trần	https://s120-25-ava-talk.zadn.vn/44/f107b26f61e71aaa9a17e938bcc605eb.jpg?key=HRNhpsepu48Ftlb3K7ha0Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.323	2026-05-04 02:46:14.323
8a9c841e-91f0-4977-bbf9-77f27addc206	ecae3be0-2ff7-4547-bf7a-308be16a20ad	750600057280920941	\N	\N	Phạm Văn Trường Sơn	https://s120-25-ava-talk.zadn.vn/16/855f61583995956a091f3b2161cb740a.jpg?key=1xFfv3_tMSadEdGa-l9ryg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.33	2026-05-04 02:46:14.33
c91e0399-9185-43ec-80d1-e534098adf49	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5930664149914059338	\N	\N	Hải Huy	https://s120-25-ava-talk.zadn.vn/8/66389049cb0bc56f850c7d8826af856e.jpg?key=h0198efczJnzkst9TCVKTg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.341	2026-05-04 02:46:14.341
36543d4c-50b4-47a4-a429-ace3f6e76e67	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2880504870176932862	\N	\N	Hữu Toàn	https://s120-25-ava-talk.zadn.vn/51/6f9454a94f97fb371ec865e7f728b1bc.jpg?key=7dWBUbcm5p3oGjZNakMWuw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.346	2026-05-04 02:46:14.346
59bdc5ad-b68d-41cf-8ebc-b9501681e168	ecae3be0-2ff7-4547-bf7a-308be16a20ad	60130993113843922	\N	\N	Lam	https://s120-25-ava-talk.zadn.vn/13/08f26d1bd7e16d923ea1639160ccae6e.jpg?key=oj91Rb3pdb59NkUMR_rWHw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.353	2026-05-04 02:46:14.353
c519cd67-977c-4a55-b01f-e8973006c4e2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4149230829009219986	\N	\N	Lê Đức Huy	https://s120-25-ava-talk.zadn.vn/5/64bd5c2dc7c371a9d91c0c5396626472.jpg?key=wvWzHEMAsEUjP_4mYuDg8g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.356	2026-05-04 02:46:14.356
f2afd008-d38f-47a6-b3e2-b2a79652474b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6947579459661502317	\N	\N	Trương Luân	https://s120-25-ava-talk.zadn.vn/6/51d718484e2cc90f498c052d22b564b7.jpg?key=uaJ542VaGswwQqsiyJAnjQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.363	2026-05-04 02:46:14.363
fca685a6-2d69-4847-9294-23283f37a04d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3628368534594254173	\N	\N	Phạm Mỹ Cảnh	https://s120-25-ava-talk.zadn.vn/6/d5039db149b35bfc8432d84bb5f39a47.jpg?key=eKN1cbddaxXf_iK3xhJ0DA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.37	2026-05-04 02:46:14.37
abeb2b3b-361d-4cb0-af36-5e4345420761	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8361295753266978830	\N	\N	Ngo Bao	https://s120-25-ava-talk.zadn.vn/26/480d9313ae1b2883e6267996593a5608.jpg?key=dByjA7gJjCVKUb0HkaXQgQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.379	2026-05-04 02:46:14.379
efa05a56-d0c5-4380-bb36-65313ad46e7d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3670032301056967145	\N	\N	Y O U R S A L E S	https://s120-25-ava-talk.zadn.vn/22/89f4dbf88e23d24da6f241f0ff7b9164.jpg?key=wc_8vTXXuwvoOEk77thagQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.391	2026-05-04 02:46:14.391
73dd3460-980a-4a90-9ab9-0ac0035b53c3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1336769012085064330	\N	\N	Thanh Phong	https://s120-25-ava-talk.zadn.vn/14/c55d9c9b477810e72376159304a525e8.jpg?key=ipyJMd3RIyikXrKeLZkq0w&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.396	2026-05-04 02:46:14.396
6ca23cbf-6944-4417-a29d-6d1b18a8d7c2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9056702170060804008	\N	\N	Nhân Thăng	https://s120-25-ava-talk.zadn.vn/1/7c003b200e72b237e2587055f1d34f72.jpg?key=L97IE_rpFAFTVZ_7vyWWFw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.4	2026-05-04 02:46:14.4
690e664e-5852-433c-88ab-70c1ca02b133	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5899850777258929383	\N	\N	Hồng Phát - Mss Thảo	https://s120-25-ava-talk.zadn.vn/1/88bd263651189baef401eb8f8a522233.jpg?key=XXUJu_7imKTM6zozwGSj2g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.404	2026-05-04 02:46:14.404
c201b98e-c402-42ad-8bde-5b99ba7104ef	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1051917401023679134	\N	\N	Cung ứng việc làm DNTU 4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 02:54:42.583	2026-05-04 02:54:42.687
b4ca4af2-1778-448e-8426-e85e6fdb3b74	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1909286789282003064	\N	\N	CNTT_Khóa 17 (21DTH)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 06:14:57.559	2026-05-04 06:14:57.559
1d17d3c1-1fa9-4270-b074-e9332916f60e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7907981006912605881	\N	\N	ĐOÀN THANH NIÊN - KHOA -CNTT -TT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 07:57:45.758	2026-05-04 07:57:45.758
d7c3ebd4-46d4-4c4e-b02e-b633d8204c72	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1151566821602093564	\N	\N	Cung ứng việc làm DNTU 6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 09:24:02.898	2026-05-04 09:24:02.898
73f2a81e-4a8b-4704-89da-268f8b05d7fa	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5860025765213937237	\N	\N	Thi Tiếng Anh CDR- TTNN-TH	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 11:37:07.469	2026-05-04 11:37:07.469
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.conversations (id, org_id, zalo_account_id, contact_id, "threadType", external_thread_id, last_message_at, unread_count, is_replied, created_at) FROM stdin;
33da79ac-da04-4b3e-a667-48f8eca973c5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	3818c757-0a5c-4139-848f-1c8c94a9d267	group	4860181653371989109	2026-05-04 06:32:20.683	0	f	2026-05-02 07:09:03.208
16d891d4-a7d7-4236-803e-d0e4dcd931dd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	b4ca4af2-1778-448e-8426-e85e6fdb3b74	group	1909286789282003064	2026-05-04 07:55:47.069	4	f	2026-05-04 06:14:57.689
e85498a4-0ddc-4da8-9c9d-34ac7e63555b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	1d17d3c1-1fa9-4270-b074-e9332916f60e	group	7907981006912605881	2026-05-04 07:57:49.635	3	f	2026-05-04 07:57:45.789
f01396f5-2b28-454a-9f2c-6adcc4ee47d4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	d7c3ebd4-46d4-4c4e-b02e-b633d8204c72	group	1151566821602093564	2026-05-04 09:24:02.43	2	f	2026-05-04 09:24:02.968
3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	bd7af861-3466-4c49-bfbd-fcc12733f9ca	group	246336029840242028	2026-05-04 19:17:12.649	254	f	2026-05-02 04:58:31.45
b402e246-2b72-4bb2-a020-74694b771084	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	73f2a81e-4a8b-4704-89da-268f8b05d7fa	group	5860025765213937237	2026-05-04 11:37:17.683	3	f	2026-05-04 11:37:07.505
fc2b1261-c3eb-4d1e-9453-162126f5e2d9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	2f8c4bc5-fea1-4f9c-8f21-7bd4352de60e	group	8810000927059780676	2026-05-04 12:12:43.039	10	f	2026-05-02 14:14:26.594
b800d881-2d06-4a3b-bf2b-05fb95d86fb9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	c201b98e-c402-42ad-8bde-5b99ba7104ef	group	1051917401023679134	2026-05-04 09:56:32.565	6	f	2026-05-04 02:54:42.729
80aeb1ef-971d-47eb-87de-8ad84a21a04b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	f96ae4e7-af46-4ff3-b877-ce3c7537eed7	user	810978846930818886	2026-05-04 03:46:40.669	22	f	2026-05-04 02:50:08.403
\.


--
-- Data for Name: daily_message_stats; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.daily_message_stats (id, org_id, user_id, zalo_account_id, stat_date, messages_sent, messages_received, messages_unread, messages_unreplied, avg_response_time_seconds) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.messages (id, conversation_id, zalo_msg_id, sender_type, sender_uid, sender_name, content, content_type, attachments, is_deleted, deleted_at, sent_at, replied_by_user_id, created_at) FROM stdin;
2ff79707-e898-433a-8a76-bf01d81eee03	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783037129955	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-4.zdn.vn/gr/jpg/3e66859a9c0d5d53041c/633651562396063229.jpg","thumb":"https://photo-stal-4.zdn.vn/gr/jpg/3e66859a9c0d5d53041c/633651562396063229.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-02 04:58:30.876	\N	2026-05-02 04:58:31.47
a2fe14af-2cd2-4d25-a1f4-862a5eba20e8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783037253189	contact	7998210325808057592	Khang Nguyễn	Ngon :)))	text	[]	f	\N	2026-05-02 04:58:33.743	\N	2026-05-02 04:58:33.905
82bdc21d-d4f3-4330-b158-d3f77640c9bf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783040752159	contact	386507739282916698	Tuấn Peodethuong	Về top 2 là bú rồi, quá đã	text	[]	f	\N	2026-05-02 04:59:54.278	\N	2026-05-02 04:59:54.741
97fda415-db31-49a5-9d0d-a50bf65834a6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783042162656	contact	7998210325808057592	Khang Nguyễn	Đang có 10 mảnh. Đợt này thiếu đúng 2cổ	text	[]	f	\N	2026-05-02 05:00:26.584	\N	2026-05-02 05:00:26.819
191c6168-569e-46fb-98cf-279c6ea430e0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783042537453	contact	7998210325808057592	Khang Nguyễn	Full cổ lun 🤣🤣	text	[]	f	\N	2026-05-02 05:00:35.068	\N	2026-05-02 05:00:35.309
59b23335-199d-4cc0-b013-044c55a7103c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783047040279	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-24.zdn.vn/gr/jpg/54c3a708a99f68c1318e/152004283628605596.jpg","thumb":"https://photo-stal-24.zdn.vn/gr/jpg/54c3a708a99f68c1318e/152004283628605596.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-02 05:02:18.181	\N	2026-05-02 05:02:18.472
81e62ed0-1d8a-4758-b875-0d05376cf3a6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783048339578	contact	2191769504086747501	Văn Minh	Trắng 850 chưa sếp	text	[]	f	\N	2026-05-02 05:02:48.138	\N	2026-05-02 05:02:48.49
5bda0bb8-b70c-4406-aff4-cc9829477bc1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783050033648	contact	7998210325808057592	Khang Nguyễn	Ac dom2	text	[]	f	\N	2026-05-02 05:03:27.05	\N	2026-05-02 05:03:27.291
7140b055-5171-4c1c-a45c-389340c5747d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783050215737	contact	7998210325808057592	Khang Nguyễn	Có cái nịt	text	[]	f	\N	2026-05-02 05:03:31.237	\N	2026-05-02 05:03:31.602
395337ba-7087-433a-91a4-cae6ab3b94dd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783094091878	contact	3540842572674797348	Tạ Gia Long	@Huy	text	[]	f	\N	2026-05-02 05:20:51.837	\N	2026-05-02 05:20:52.355
fe45b939-1f68-4237-90bf-09256bfb35ba	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783094273996	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-35.zdn.vn/gr/jpg/73f109034b948acad385/667392811254466561.jpg","thumb":"https://photo-stal-35.zdn.vn/gr/jpg/73f109034b948acad385/667392811254466561.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-35.zdn.vn\\\\/gr\\\\/jpg\\\\/73f109034b948acad385\\\\/667392811254466561.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699254338,\\"id_in_group\\":1,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000014447\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:20:56.309	\N	2026-05-02 05:20:56.523
2c5a4f21-bae3-4641-85d3-51212a501bd4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783094275549	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-16.zdn.vn/gr/jpg/171f1cfa5e6d9f33c67c/1792132690915917282.jpg","thumb":"https://photo-stal-16.zdn.vn/gr/jpg/171f1cfa5e6d9f33c67c/1792132690915917282.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-16.zdn.vn\\\\/gr\\\\/jpg\\\\/171f1cfa5e6d9f33c67c\\\\/1792132690915917282.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699254338,\\"id_in_group\\":0,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000014448\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:20:56.335	\N	2026-05-02 05:20:56.57
5c744595-ca19-44bf-8cb0-80e592076a8a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783094625865	contact	3540842572674797348	Tạ Gia Long	Chỉ cách biến nó thành atk 70 đi fen	text	[]	f	\N	2026-05-02 05:21:04.799	\N	2026-05-02 05:21:05.113
d4603cb6-df88-429f-a05c-57319a59201a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783101591503	contact	2226503885650453985	Nguyễn Thành	Atk70 ăn ám tinh 28 cũng có tỉ lệ ra đó	text	[]	f	\N	2026-05-02 05:23:54.522	\N	2026-05-02 05:23:55.001
4ad67b03-2f7e-4d85-8196-609d05bec1d0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783106472320	contact	7916569348779191770	Kiều Quang Phúc	@Nguyễn Thành ra 50 thôi a	text	[]	f	\N	2026-05-02 05:25:54.643	\N	2026-05-02 05:25:55.053
c4ef5aa2-a490-4e5a-8140-cb0323190179	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783107442989	contact	3874537684008431042	Trang Thành Lộc	50 thôi 🙄	text	[]	f	\N	2026-05-02 05:26:18.546	\N	2026-05-02 05:26:18.869
2813b60e-d59b-4aef-a583-cc80ed30639c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783108282027	contact	2408615132830093674	Dang Tran	{"title":"","description":"","href":"https://photo-stal-26.zdn.vn/gr/jpg/eaeeca5cfccb3d9564da/317269121305226406.jpg","thumb":"https://photo-stal-26.zdn.vn/gr/jpg/eaeeca5cfccb3d9564da/317269121305226406.jpg","childnumber":0,"action":"","params":"{\\"width\\":2772,\\"height\\":1280,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-26.zdn.vn\\\\/gr\\\\/jpg\\\\/eaeeca5cfccb3d9564da\\\\/317269121305226406.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"3232\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:26:39.209	\N	2026-05-02 05:26:39.523
3ea9564a-ad87-41eb-b102-0c816d144c53	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783108759604	contact	2408615132830093674	Dang Tran	Từng rương làm j cứ full mà mở cho lẹ :> :>	text	[]	f	\N	2026-05-02 05:26:50.934	\N	2026-05-02 05:26:51.205
f1048ee0-d09c-4219-962c-6c13d7319e27	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109302423	contact	7498720695294354711	Nguyễn Quốc Hữu	@Dang Tran ngonn	text	[]	f	\N	2026-05-02 05:27:04.369	\N	2026-05-02 05:27:04.802
df0372f9-bdcf-43c2-9833-c08a1681be67	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109837620	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-16.zdn.vn/gr/jpg/171f1cfa5e6d9f33c67c/1792132690915917282.jpg","thumb":"https://photo-stal-16.zdn.vn/gr/jpg/171f1cfa5e6d9f33c67c/1792132690915917282.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-16.zdn.vn\\\\/gr\\\\/jpg\\\\/171f1cfa5e6d9f33c67c\\\\/1792132690915917282.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699636472,\\"id_in_group\\":0,\\"total_item_in_group\\":3,\\"contentId\\":\\"1000014448\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:27:17.53	\N	2026-05-02 05:27:17.92
46de031f-21e1-4a67-be47-8e8925f735ce	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109878050	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-30.zdn.vn/gr/jpg/51821cd06147a019f956/4238697784177133835.jpg","thumb":"https://photo-stal-30.zdn.vn/gr/jpg/51821cd06147a019f956/4238697784177133835.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-30.zdn.vn\\\\/gr\\\\/jpg\\\\/51821cd06147a019f956\\\\/4238697784177133835.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699636472,\\"id_in_group\\":1,\\"total_item_in_group\\":3,\\"contentId\\":\\"1000014449\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:27:18.563	\N	2026-05-02 05:27:18.691
20764e63-c588-4f1e-84a3-3b0a36944801	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109878912	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-35.zdn.vn/gr/jpg/73f109034b948acad385/667392811254466561.jpg","thumb":"https://photo-stal-35.zdn.vn/gr/jpg/73f109034b948acad385/667392811254466561.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-35.zdn.vn\\\\/gr\\\\/jpg\\\\/73f109034b948acad385\\\\/667392811254466561.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699636472,\\"id_in_group\\":2,\\"total_item_in_group\\":3,\\"contentId\\":\\"1000014447\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:27:18.588	\N	2026-05-02 05:27:18.831
5bba8a15-64ab-47f3-b756-9aa8ff2cc990	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109922292	contact	3540842572674797348	Tạ Gia Long	{"id":43517,"catId":11786,"type":3}	sticker	[]	f	\N	2026-05-02 05:27:19.649	\N	2026-05-02 05:27:19.772
e2c9a17b-1226-4470-af29-cc77050e807c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783110197789	contact	3540842572674797348	Tạ Gia Long	4 acc tạch cả r	text	[]	f	\N	2026-05-02 05:27:26.461	\N	2026-05-02 05:27:26.691
832ce8ca-e64f-49a6-aa4f-b16ea66f2f7b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783139352819	contact	5552626581457264137	Nguyễn Hoài Sơn	{"title":"","description":"","href":"https://photo-stal-22.zdn.vn/gr/jpg/8c57ef126885a9dbf094/1078175464054840850.jpg","thumb":"https://photo-stal-22.zdn.vn/gr/jpg/8c57ef126885a9dbf094/1078175464054840850.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-22.zdn.vn\\\\/gr\\\\/jpg\\\\/8c57ef126885a9dbf094\\\\/1078175464054840850.jpg\\",\\"width\\":2778,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-02 05:39:46.27	\N	2026-05-02 05:39:46.735
ad4dbec7-4633-4bc9-a324-81fa71912760	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783139584219	contact	5552626581457264137	Nguyễn Hoài Sơn	Z là lời hay lỗ	text	[]	f	\N	2026-05-02 05:39:52.288	\N	2026-05-02 05:39:52.629
7003ab83-0878-4195-a91e-9f46bc401ee5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783142177547	contact	7133099385971049210	Phạm Đức Tiến	Lời cám ơn	text	[]	f	\N	2026-05-02 05:40:59.915	\N	2026-05-02 05:41:00.332
53ec7951-05b6-41f1-b02e-ea8dcda692a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783145572766	contact	2191769504086747501	Văn Minh	{"title":"","description":"","href":"https://photo-stal-37.zdn.vn/gr/jpg/1e1119969601575f0e10/1199703692766986882.jpg","thumb":"https://photo-stal-37.zdn.vn/gr/jpg/1e1119969601575f0e10/1199703692766986882.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"height\\":1284,\\"thumb_width\\":778}","type":""}	image	[]	f	\N	2026-05-02 05:42:29.07	\N	2026-05-02 05:42:29.454
5cf4786a-304b-4125-ac8e-149cba3b1e86	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783145721080	contact	2191769504086747501	Văn Minh	Vậy mới lời nè	text	[]	f	\N	2026-05-02 05:42:32.917	\N	2026-05-02 05:42:33.062
c8ccee2f-abcf-4cdc-a405-5887065a3a2e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783145767871	contact	2191769504086747501	Văn Minh	{"id":1105,"catId":50,"type":3}	sticker	[]	f	\N	2026-05-02 05:42:34.146	\N	2026-05-02 05:42:34.279
a48c6df2-16b9-4080-8c41-5c09df7f262c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184249610	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-9.zdn.vn/gr/jpg/a1a8be3917aed6f08fbf/4083059782671533844.jpg","thumb":"https://photo-stal-9.zdn.vn/gr/jpg/a1a8be3917aed6f08fbf/4083059782671533844.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":1,\\"group_layout_id\\":1777701587445,\\"id_in_group\\":0,\\"total_item_in_group\\":4,\\"contentId\\":\\"99244\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:59:49.028	\N	2026-05-02 05:59:49.411
c83a88b1-317d-4cc4-8a02-f622dd930b9c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184259252	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-24.zdn.vn/gr/jpg/0af90b72a2e563bb3af4/585545276540625646.jpg","thumb":"https://photo-stal-24.zdn.vn/gr/jpg/0af90b72a2e563bb3af4/585545276540625646.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":1,\\"group_layout_id\\":1777701587445,\\"id_in_group\\":1,\\"total_item_in_group\\":4,\\"contentId\\":\\"99245\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:59:49.263	\N	2026-05-02 05:59:49.527
177defb5-70bb-493a-b54f-4a2aa22b8b83	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184274483	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-20.zdn.vn/gr/jpg/dddd5025f9b238ec61a3/4082635243753428268.jpg","thumb":"https://photo-stal-20.zdn.vn/gr/jpg/dddd5025f9b238ec61a3/4082635243753428268.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":1,\\"group_layout_id\\":1777701587445,\\"id_in_group\\":2,\\"total_item_in_group\\":4,\\"contentId\\":\\"99246\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:59:49.751	\N	2026-05-02 05:59:49.879
737ce3aa-f135-4329-83a0-3dcf5c0050ad	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184274496	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-19.zdn.vn/gr/jpg/0df8d20c7b9bbac5e38a/4082635243753428268.jpg","thumb":"https://photo-stal-19.zdn.vn/gr/jpg/0df8d20c7b9bbac5e38a/4082635243753428268.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":1,\\"group_layout_id\\":1777701587445,\\"id_in_group\\":3,\\"total_item_in_group\\":4,\\"contentId\\":\\"99247\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:59:49.77	\N	2026-05-02 05:59:49.886
c1c2746a-e3be-4f90-881a-9ff681ca312f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184374906	contact	2936642097806243014	Mthuan	Cũng cũng đi	text	[]	f	\N	2026-05-02 05:59:52.475	\N	2026-05-02 05:59:52.583
79fd701e-4bb0-451c-9970-b3acd299c9fd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184753491	contact	2936642097806243014	Mthuan	@Văn Minh 2 atk70	text	[]	f	\N	2026-05-02 06:00:02.802	\N	2026-05-02 06:00:03.034
51e95f70-4b6d-4c52-8d00-932e743d0dbf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184827324	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-12.zdn.vn/gr/4ec9a13cee4b2f15765a/790503755819622518.jpg","thumb":"https://photo-stal-12.zdn.vn/gr/4ec9a13cee4b2f15765a/790503755819622518.jpg","childnumber":0,"action":"","params":"{\\"width\\":720,\\"height\\":720,\\"is_group_layout\\":0,\\"tracking\\":\\"{\\\\\\"source\\\\\\":7,\\\\\\"keyword\\\\\\":\\\\\\"\\\\\\",\\\\\\"contentID\\\\\\":\\\\\\"5a0969affe9eadeabbe8b92a19292595\\\\\\",\\\\\\"send_method\\\\\\":0}\\",\\"contentId\\":\\"5a0969affe9eadeabbe8b92a19292595\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 06:00:04.792	\N	2026-05-02 06:00:04.925
438a58c2-8252-4ba2-86b4-50c5c26d3c15	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783187991741	contact	8087701766132846650	Vũ Lộc	Cái kia def 70 mà :)))	text	[]	f	\N	2026-05-02 06:01:29.943	\N	2026-05-02 06:01:30.337
697c1472-71d1-49a0-b94d-34a3fe75b72d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783192154780	contact	3540842572674797348	Tạ Gia Long	của ô khác	text	[]	f	\N	2026-05-02 06:03:23.684	\N	2026-05-02 06:03:24.093
8d5e0188-bb70-42e5-8189-a21cbc87a51b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783192414534	contact	3540842572674797348	Tạ Gia Long	lướt lên đi	text	[]	f	\N	2026-05-02 06:03:30.963	\N	2026-05-02 06:03:31.147
9268b4af-65a5-4ede-b4e8-5d8f1a0a0494	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783192917622	contact	8087701766132846650	Vũ Lộc	À	text	[]	f	\N	2026-05-02 06:03:44.486	\N	2026-05-02 06:03:44.723
fc4542a6-2677-4708-b423-b82766afe72b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783202653768	contact	3900706176857508133	Trần Thái Thiên	{"title":"","description":"","href":"https://photo-stal-10.zdn.vn/gr/jpg/94aee05a24cde593bcdc/2160892849330236103.jpg","thumb":"https://photo-stal-10.zdn.vn/gr/jpg/94aee05a24cde593bcdc/2160892849330236103.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":0,\\"contentId\\":\\"1000027471\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 06:08:12.653	\N	2026-05-02 06:08:13.06
3e03f9f5-11d8-4e1a-9b24-7a6f03240fa0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783202895562	contact	3900706176857508133	Trần Thái Thiên	Buồn của đớ	text	[]	f	\N	2026-05-02 06:08:19.398	\N	2026-05-02 06:08:19.612
d183d6e8-1b10-4911-b29b-23423e207c36	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225472933	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-5.zdn.vn/gr/jpg/9cc343cf52599307ca48/464541618954580023.jpg","thumb":"https://photo-stal-5.zdn.vn/gr/jpg/9cc343cf52599307ca48/464541618954580023.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":2,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:49.981	\N	2026-05-02 06:18:50.419
c9d00cff-ee73-49c6-aa2c-e42a35e350a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225482660	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-23.zdn.vn/gr/jpg/c6b48bba9a2c5b72023d/464541618954580023.jpg","thumb":"https://photo-stal-23.zdn.vn/gr/jpg/c6b48bba9a2c5b72023d/464541618954580023.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":0,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:50.221	\N	2026-05-02 06:18:50.459
4dddc099-ab2e-45c8-a4dc-f45839b37a2b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225479600	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-33.zdn.vn/gr/jpg/8355e25af3cc32926bdd/464541618954580023.jpg","thumb":"https://photo-stal-33.zdn.vn/gr/jpg/8355e25af3cc32926bdd/464541618954580023.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":1,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:50.133	\N	2026-05-02 06:18:50.496
f0df8b06-01b3-47e2-9ea7-ea7290159d88	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225521786	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-2.zdn.vn/gr/jpg/639cf013e38522db7b94/720456045978797076.jpg","thumb":"https://photo-stal-2.zdn.vn/gr/jpg/639cf013e38522db7b94/720456045978797076.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":4,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:51.364	\N	2026-05-02 06:18:51.472
ab6f015d-6142-415f-bf71-17bdaa4428fb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225530514	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-3.zdn.vn/gr/jpg/1887dd09ce9f0fc1568e/720456045978797076.jpg","thumb":"https://photo-stal-3.zdn.vn/gr/jpg/1887dd09ce9f0fc1568e/720456045978797076.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":3,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:51.623	\N	2026-05-02 06:18:51.738
c41a370c-e81f-423b-89fe-322ab28730ff	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225681203	contact	7215567985167948581	Nguyễn Tài	Chào ae OTT Đang ở K1364 Tuyển thành viên bao RSS all sk bang đang thiếu key mời ae key về sẽ được chăm sóc đặt biệt bang vv hoà đồng war nhẹ	text	[]	f	\N	2026-05-02 06:18:55.874	\N	2026-05-02 06:18:56.11
35cd8084-156a-4507-b8d6-abe027211612	33da79ac-da04-4b3e-a667-48f8eca973c5	7783334288377	contact	843064466021066164	Đặng Minh Quang	chỉ cần như vậy thôi đúng k cô? Niên khóa thì e bỏ trống ạ	text	[]	f	\N	2026-05-02 07:09:02.818	\N	2026-05-02 07:09:03.218
d82689fe-5862-497f-a979-f3b0ed25fcab	33da79ac-da04-4b3e-a667-48f8eca973c5	7783334326736	contact	843064466021066164	Đặng Minh Quang	{"title":"","description":"","href":"https://photo-stal-20.zdn.vn/gr/jpg/14fba07d2bebeab5b3fa/3285038049309946119.jpg","thumb":"https://photo-stal-20.zdn.vn/gr/jpg/14fba07d2bebeab5b3fa/3285038049309946119.jpg","childnumber":0,"action":"","params":"{\\"id_in_group\\":0,\\"is_group_layout\\":1,\\"width\\":1919,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-20.zdn.vn\\\\/gr\\\\/jpg\\\\/14fba07d2bebeab5b3fa\\\\/3285038049309946119.jpg\\",\\"group_layout_id\\":1777705742149,\\"height\\":386,\\"total_item_in_group\\":2}","type":""}	image	[]	f	\N	2026-05-02 07:09:03.842	\N	2026-05-02 07:09:03.99
ac5f82ad-d76e-4907-9f1b-c0b60a874338	33da79ac-da04-4b3e-a667-48f8eca973c5	7783334326735	contact	843064466021066164	Đặng Minh Quang	{"title":"","description":"","href":"https://photo-stal-2.zdn.vn/gr/jpg/a0c8124d99db588501ca/3285038049309946119.jpg","thumb":"https://photo-stal-2.zdn.vn/gr/jpg/a0c8124d99db588501ca/3285038049309946119.jpg","childnumber":0,"action":"","params":"{\\"id_in_group\\":1,\\"is_group_layout\\":1,\\"width\\":709,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-2.zdn.vn\\\\/gr\\\\/jpg\\\\/a0c8124d99db588501ca\\\\/3285038049309946119.jpg\\",\\"group_layout_id\\":1777705742149,\\"height\\":298,\\"total_item_in_group\\":2}","type":""}	image	[]	f	\N	2026-05-02 07:09:03.842	\N	2026-05-02 07:09:04.062
5fed3a22-8704-4c98-af93-165352ab8af3	33da79ac-da04-4b3e-a667-48f8eca973c5	7783334500205	contact	843064466021066164	Đặng Minh Quang	@Quách Thị Bích Nhường	text	[]	f	\N	2026-05-02 07:09:08.859	\N	2026-05-02 07:09:09.007
d9a1bbe6-2d90-4a04-ba47-d245506f2613	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783390758172	contact	4579632439414729865	Tungthanh	{"title":"","description":"","href":"https://photo-stal-11.zdn.vn/gr/jpg/6b166b04939252cc0b83/4579207177238629541.jpg","thumb":"https://photo-stal-11.zdn.vn/gr/jpg/6b166b04939252cc0b83/4579207177238629541.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1158,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-11.zdn.vn\\\\/gr\\\\/jpg\\\\/6b166b04939252cc0b83\\\\/4579207177238629541.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000010168\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 07:33:25.901	\N	2026-05-02 07:33:26.416
1e5ad963-fc13-4915-b33f-b50e299f2874	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783391072641	contact	4579632439414729865	Tungthanh	này cần nhiêu sách nữa vậy ae	text	[]	f	\N	2026-05-02 07:33:33.903	\N	2026-05-02 07:33:34.148
0b4a7609-1153-4e50-9ba1-6ec5c471ef0e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783393373999	contact	2760596411766142024	Nguyễn Đạt	@Tungthanh 2k	text	[]	f	\N	2026-05-02 07:34:32.077	\N	2026-05-02 07:34:32.47
6d9fdbe3-2dab-45c0-a93d-e7163b19bc92	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783393619604	contact	4579632439414729865	Tungthanh	{"id":16786,"catId":10052,"type":3}	sticker	[]	f	\N	2026-05-02 07:34:38.27	\N	2026-05-02 07:34:38.494
59ea3d55-ff67-452f-98b5-658b8d9ea75e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783393813353	contact	4579632439414729865	Tungthanh	adu nhiều z	text	[]	f	\N	2026-05-02 07:34:43.103	\N	2026-05-02 07:34:43.298
e69ebfc6-c0c8-4bc7-bf1a-593a5156bc18	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783394389633	contact	2760596411766142024	Nguyễn Đạt	Cái mbd là 1k3	text	[]	f	\N	2026-05-02 07:34:57.711	\N	2026-05-02 07:34:57.953
682fbb18-db89-4bc9-9f57-27dd1593727f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783394616048	contact	2760596411766142024	Nguyễn Đạt	Cái ô cuối xấp xỉ 700	text	[]	f	\N	2026-05-02 07:35:03.471	\N	2026-05-02 07:35:03.679
556b5dec-67c8-4778-b436-e2f465df56eb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783394733236	contact	2760596411766142024	Nguyễn Đạt	{"id":27449,"catId":10739,"type":3}	sticker	[]	f	\N	2026-05-02 07:35:06.393	\N	2026-05-02 07:35:06.53
f9095962-f432-43ab-b0d3-34f98d9dcfa0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783451915970	contact	6562854816970626324	Đức Bình	Kiếm acc đi k13xx	text	[]	f	\N	2026-05-02 07:58:43.616	\N	2026-05-02 07:58:44.029
0f1e5358-7bfd-4456-b40d-247160962da5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783460531910	contact	7673666916021537145	ĐỨC lưu	@Đức Bình ib	text	[]	f	\N	2026-05-02 08:02:00.376	\N	2026-05-02 08:02:00.809
b7c78d9b-e22a-465d-b406-4df98becc09f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783591744967	contact	7496477430098754831	Kenny Đại	Sk 120% ra ít gem all lực giá mềm & bán ac 21 nuôi đá ATK\n- Còn 2 ac nhà 21 đang nc và rèn lính săn đá ATK tt 1200d,a c tạo 1843 gem đủ lên HV 25, đồ 6x nl lên xanh tím ( đá vàng gần 5 viên )\n- Trap rally t5 lính 50m ( 2 chén vàng, áo-chân-găng cam ) \nAnh em đam mê nuôi tiếp pmm	text	[]	f	\N	2026-05-02 08:49:18.475	\N	2026-05-02 08:49:18.924
951c1522-1b55-4c76-b108-d233f8fd9d5e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783605014334	contact	1532676259223031106	Nguyễn Thuỳ Dung	{"title":"","description":"","href":"https://photo-stal-6.zdn.vn/gr/jpg/85e3f4f5e865293b7074/3597491818672983719.jpg","thumb":"https://photo-stal-6.zdn.vn/gr/jpg/85e3f4f5e865293b7074/3597491818672983719.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":780,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":1290,\\"height\\":2796,\\"thumb_width\\":360}","type":""}	image	[]	f	\N	2026-05-02 08:53:55.411	\N	2026-05-02 08:53:55.82
c9c60de4-1134-4d76-bdb1-038d1eca00da	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783613855293	contact	8335543682305672106	Ma Văn Vương	cần 3m gems - 2.278m	text	[]	f	\N	2026-05-02 08:57:04.946	\N	2026-05-02 08:57:05.456
c5e6eb79-3b3b-4c41-9073-1b07df375954	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783620906730	contact	8335543682305672106	Ma Văn Vương	done	text	[]	f	\N	2026-05-02 08:59:37.404	\N	2026-05-02 08:59:37.728
7d9e6162-260a-4ae8-ade0-3ae5c58a0328	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783762023069	contact	4835990816698319387	Minh Nguyễn	{"title":"","description":"","href":"https://photo-stal-5.zdn.vn/gr/jpg/f32ac0ae083ec960902f/3040130261441955514.jpg","thumb":"https://photo-stal-5.zdn.vn/gr/jpg/f32ac0ae083ec960902f/3040130261441955514.jpg","childnumber":0,"action":"","params":"{\\"width\\":858,\\"height\\":1908,\\"is_group_layout\\":0,\\"contentId\\":\\"1000052986\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 09:51:34.577	\N	2026-05-02 09:51:35.069
fabbd7d9-d5f5-4ae6-a7b7-e487a10415dc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783764298885	contact	4835990816698319387	Minh Nguyễn	Game nào khứa kia cũng spam bài đăng tặng acc	text	[]	f	\N	2026-05-02 09:52:24.475	\N	2026-05-02 09:52:24.789
670f22b4-0b29-4466-8de2-ef05479d8a3c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783765710109	contact	4835990816698319387	Minh Nguyễn	Trốn lord mobile sang game khác cũng ko thoát	text	[]	f	\N	2026-05-02 09:52:55.466	\N	2026-05-02 09:52:55.74
9d61d972-ceff-455f-a501-794acd8275d4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783770171259	contact	7193756553000496082	Ht Mr Minh	Hot boy Phú Yên	text	[]	f	\N	2026-05-02 09:54:33.721	\N	2026-05-02 09:54:34.147
b6e29a79-b7fe-4c4d-be06-1db91c793479	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783771474717	contact	7496477430098754831	Kenny Đại	@Minh Nguyễn chắc nghề rồi	text	[]	f	\N	2026-05-02 09:55:02.018	\N	2026-05-02 09:55:02.385
69b42e5b-63af-4e4e-a07b-e88657dcb6c1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783774711164	contact	7193756553000496082	Ht Mr Minh	game nào chả có nó, ăn dễ quá mà	text	[]	f	\N	2026-05-02 09:56:13.646	\N	2026-05-02 09:56:13.842
bbd812b9-516d-43ee-8cc5-ae04c7269507	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783781867113	contact	4835990816698319387	Minh Nguyễn	{"title":"","description":"","href":"https://photo-stal-22.zdn.vn/gr/jpg/bdf351e7b27773292a66/2235515486796704769.jpg","thumb":"https://photo-stal-22.zdn.vn/gr/jpg/bdf351e7b27773292a66/2235515486796704769.jpg","childnumber":0,"action":"","params":"{\\"width\\":858,\\"height\\":1908,\\"is_group_layout\\":0,\\"contentId\\":\\"1000052987\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 09:58:50.002	\N	2026-05-02 09:58:50.498
5f09bdc4-5686-4b1b-8c45-feb11c9f349a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783784166613	contact	4835990816698319387	Minh Nguyễn	Thì ra đây là lý do mà nó có cả đống acc fb	text	[]	f	\N	2026-05-02 09:59:40.433	\N	2026-05-02 09:59:40.666
76a73afe-f99d-4244-9675-d95ad9105f7b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783862187970	contact	585801465063846950	Võ Vũ Nam 武武南	{"id":45356,"catId":11901,"type":3}	sticker	[]	f	\N	2026-05-02 10:28:49.608	\N	2026-05-02 10:28:50.069
1eb0ed8f-9d5d-46b3-b772-30cd65aa00be	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783884163868	contact	8395788325665172100	Lê Quang Long	Mn cho hỏi acc ng ta lk gc nma mình k có sài ip vâyh khi trao đổi tt , chèn sdt mình vô gc đó chỉ vâyj thôi thì có ảnh hưởng j k mn, ổn k mn	text	[]	f	\N	2026-05-02 10:36:57.186	\N	2026-05-02 10:36:57.701
09f69ac4-1bc2-4171-8e2b-47bfd72d9324	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783890712645	contact	4881617662073102521	Nguyễn Minh Tuan	{"title":"","description":"","href":"https://photo-stal-24.zdn.vn/gr/jpg/20aaacd63c45fd1ba454/1017820025811179161.jpg","thumb":"https://photo-stal-24.zdn.vn/gr/jpg/20aaacd63c45fd1ba454/1017820025811179161.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-24.zdn.vn\\\\/gr\\\\/jpg\\\\/20aaacd63c45fd1ba454\\\\/1017820025811179161.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"83728\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 10:39:21.946	\N	2026-05-02 10:39:22.361
62b621f9-3a57-4782-91ca-fff3634b950e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783890902409	contact	4881617662073102521	Nguyễn Minh Tuan	Chợ thốn quá	text	[]	f	\N	2026-05-02 10:39:26.045	\N	2026-05-02 10:39:26.184
033e1c90-314c-43fd-9bab-ac2eacd0957b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783890942614	contact	3540842572674797348	Tạ Gia Long	{"id":43523,"catId":11786,"type":7}	sticker	[]	f	\N	2026-05-02 10:39:26.984	\N	2026-05-02 10:39:27.211
934c5f5c-68fa-4edd-b060-9866e38caaa8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783891034561	contact	3540842572674797348	Tạ Gia Long	giàu	text	[]	f	\N	2026-05-02 10:39:29.147	\N	2026-05-02 10:39:29.261
40f5efd9-4cce-452d-b8de-f8796d39ba8d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783891813729	contact	3540842572674797348	Tạ Gia Long	t dám mua mỗi não nhện vs cuộn sao kèm rương quyền lực	text	[]	f	\N	2026-05-02 10:39:46.471	\N	2026-05-02 10:39:46.686
dd753da7-4ba4-4520-8daa-0ce75d6bde0a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783892055126	contact	4881617662073102521	Nguyễn Minh Tuan	Nghèo r	text	[]	f	\N	2026-05-02 10:39:51.555	\N	2026-05-02 10:39:51.761
5a7d6dda-b96c-41d9-99f6-6b22062ba430	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783892452199	contact	3540842572674797348	Tạ Gia Long	3d mà tiêu z gf chỉ đi đánh ám	text	[]	f	\N	2026-05-02 10:40:00.6	\N	2026-05-02 10:40:00.779
f782b518-e055-4f62-a72d-44373e1ddcff	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783892774414	contact	3540842572674797348	Tạ Gia Long	{"id":45356,"catId":11901,"type":7}	sticker	[]	f	\N	2026-05-02 10:40:07.822	\N	2026-05-02 10:40:08.026
8a2e7c12-fb04-46bc-a08a-89f9118d8b83	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783892948634	contact	4881617662073102521	Nguyễn Minh Tuan	@Tạ Gia Long acc trap lỏ nên j cũng cần á ông	text	[]	f	\N	2026-05-02 10:40:11.317	\N	2026-05-02 10:40:11.41
24cccc3b-b73f-47e2-b843-0511a45c66e2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783893993494	contact	4881617662073102521	Nguyễn Minh Tuan	Bộ thầy tế lên j ngon nhỉ	text	[]	f	\N	2026-05-02 10:40:34.292	\N	2026-05-02 10:40:34.589
c7e8e8bd-afef-489c-ba81-9ed55c5185f2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783894028510	contact	3540842572674797348	Tạ Gia Long	@Nguyễn Minh Tuan k nạp lấy đâu ra lắm nl phụ mà lên	text	[]	f	\N	2026-05-02 10:40:35.042	\N	2026-05-02 10:40:35.258
8f513fda-4d25-4498-95c8-31ad3c9d4b5e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783894556577	contact	4881617662073102521	Nguyễn Minh Tuan	@Tạ Gia Long tích sẵn thôi ôg	text	[]	f	\N	2026-05-02 10:40:46.792	\N	2026-05-02 10:40:47.036
734fb9d3-fc8b-49a6-a56e-f54fa3a09590	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783895090213	contact	4881617662073102521	Nguyễn Minh Tuan	Đập hộp dần	text	[]	f	\N	2026-05-02 10:40:58.547	\N	2026-05-02 10:40:58.862
ed5adbad-acdf-4016-a3df-4f68ae2143d7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783896011714	contact	4881617662073102521	Nguyễn Minh Tuan	Như cái kiếm rồng đủ nl phụ mà đợt k mua giờ k lên đc:))	text	[]	f	\N	2026-05-02 10:41:18.895	\N	2026-05-02 10:41:19.145
54b3d261-2b74-4955-9544-ed9e0e757f09	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783898714368	contact	3540842572674797348	Tạ Gia Long	t chơi hóa cốt chê kiếm rồng :)))	text	[]	f	\N	2026-05-02 10:42:18.982	\N	2026-05-02 10:42:19.29
2f5a4a65-b0e2-4757-a976-c86f746a4273	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783899240412	contact	3540842572674797348	Tạ Gia Long	hết chợ đc 35/36 tím ms lên vàng	text	[]	f	\N	2026-05-02 10:42:30.478	\N	2026-05-02 10:42:30.684
d94210ec-fdbb-4c44-a9eb-6008d700a5d4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783899378379	contact	3540842572674797348	Tạ Gia Long	{"id":45342,"catId":11901,"type":7}	sticker	[]	f	\N	2026-05-02 10:42:33.525	\N	2026-05-02 10:42:33.642
173a50d4-1830-4620-887f-333d61714cb3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783908881274	contact	4881617662073102521	Nguyễn Minh Tuan	Cố gồng v	text	[]	f	\N	2026-05-02 10:46:02.15	\N	2026-05-02 10:46:02.608
fc158b60-2534-434e-a49a-32a9c17560a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783910234390	contact	4881617662073102521	Nguyễn Minh Tuan	Mai khỏi mua búp bê quỷ	text	[]	f	\N	2026-05-02 10:46:31.698	\N	2026-05-02 10:46:31.982
b0581135-a97b-4824-8c35-5e76331270ec	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783940536411	contact	3540842572674797348	Tạ Gia Long	@Nguyễn Minh Tuan mua làm quái j	text	[]	f	\N	2026-05-02 10:57:32.289	\N	2026-05-02 10:57:32.68
1e3ffdc9-3309-4e9c-ad49-fba25d1ddd72	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783940819445	contact	3540842572674797348	Tạ Gia Long	đồ pet lam đủ dùng r	text	[]	f	\N	2026-05-02 10:57:38.439	\N	2026-05-02 10:57:38.642
486f7900-9bf2-43c0-91cb-04eeb8f07fcb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783962783819	contact	3391365375455109655	Huy	@Nguyễn Minh Tuan mua phí gem d ông:)	text	[]	f	\N	2026-05-02 11:05:28.705	\N	2026-05-02 11:05:29.135
9ec341c9-b71b-4d6f-a061-b9e601f30749	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783977054564	contact	7496477430098754831	Kenny Đại	@Nguyễn Minh Tuan ghê vậy	text	[]	f	\N	2026-05-02 11:10:37.756	\N	2026-05-02 11:10:38.18
bebd5d6b-4839-4059-8a5d-0b860f49930c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783977378415	contact	7496477430098754831	Kenny Đại	Búp bê mua chi	text	[]	f	\N	2026-05-02 11:10:44.75	\N	2026-05-02 11:10:44.954
ebb66d8d-3a4c-411a-b6af-740e62b96d34	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783984762620	contact	3540842572674797348	Tạ Gia Long	ngta giàu thì kệ đi	text	[]	f	\N	2026-05-02 11:13:26.573	\N	2026-05-02 11:13:26.992
6ea8d160-1ad6-403d-a4d3-f086f7fe395a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783985318918	contact	3540842572674797348	Tạ Gia Long	mình nghèo chưa đến chợ đã hết gem	text	[]	f	\N	2026-05-02 11:13:39.369	\N	2026-05-02 11:13:39.643
41e69475-e28d-4c6d-9af5-c64b96cac917	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783985775189	contact	3540842572674797348	Tạ Gia Long	kia đi sạch chợ túi vẫn rủng rỉnh	text	[]	f	\N	2026-05-02 11:13:48.901	\N	2026-05-02 11:13:49.12
52f693e0-9db5-4d42-b737-224ea26b9293	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783987135220	contact	8087701766132846650	Vũ Lộc	Từng kia gem mai là cạn	text	[]	f	\N	2026-05-02 11:14:18.276	\N	2026-05-02 11:14:18.725
99c22772-140f-4b3b-be6a-ba59ef2eb6f4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783988561117	contact	3540842572674797348	Tạ Gia Long	@Vũ Lộc mua nửa chợ hết tiền :)))	text	[]	f	\N	2026-05-02 11:14:50.079	\N	2026-05-02 11:14:50.338
343746bf-d10c-4926-a21c-6a63b2f9f8a2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784014777402	contact	3343804879378568288	Ndh	Vậy mai vs mốt	text	[]	f	\N	2026-05-02 11:24:35.749	\N	2026-05-02 11:24:36.239
efafb009-3b2d-4e4c-9d56-f83acfca97f1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784015441815	contact	3343804879378568288	Ndh	Nạp gói quà phát triển để đổi đồ à anh trai	text	[]	f	\N	2026-05-02 11:24:50.54	\N	2026-05-02 11:24:50.798
9fa39a2c-cf65-4ebd-917b-cd321a6fd527	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784015570608	contact	3343804879378568288	Ndh	{"id":34839,"catId":11190,"type":3}	sticker	[]	f	\N	2026-05-02 11:24:53.431	\N	2026-05-02 11:24:53.57
3c014eb3-d1c6-4f06-8316-651896d4b8dc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784016558316	contact	3540842572674797348	Tạ Gia Long	hỏi ngta chứ t có gem đâu mà mua :))	text	[]	f	\N	2026-05-02 11:25:16.305	\N	2026-05-02 11:25:16.845
945d10e1-51c9-4986-89bb-7ed8edb185bb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784034422536	contact	4881617662073102521	Nguyễn Minh Tuan	@Vũ Lộc mua mớ đó gần 100k r:))	text	[]	f	\N	2026-05-02 11:31:43.607	\N	2026-05-02 11:31:44.084
bd7413c5-37c5-457b-b1e1-55132c18fd86	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784042175563	contact	3391365375455109655	Huy	@Nguyễn Minh Tuan r mai vs mốt lấy gì mua ông:)	text	[]	f	\N	2026-05-02 11:34:25.824	\N	2026-05-02 11:34:26.234
6d0f361e-4147-48d7-ac8b-ed3cbd40c815	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784091608961	contact	2226503885650453985	Nguyễn Thành	@Tạ Gia Long ko mua ấn sói à	text	[]	f	\N	2026-05-02 11:51:52.181	\N	2026-05-02 11:51:52.633
2e6de27c-257d-408d-83c9-ea14c0216673	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784095787594	contact	4881617662073102521	Nguyễn Minh Tuan	@Huy tính toán mua nguyên liệu chính	text	[]	f	\N	2026-05-02 11:53:21.232	\N	2026-05-02 11:53:21.778
51269659-8247-4e9c-a173-d8d6a231094d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784099177563	contact	3391365375455109655	Huy	@Nguyễn Minh Tuan tập trung 1 set mix thôi:) r mua hết đống rương quyền lực là đẹp	text	[]	f	\N	2026-05-02 11:54:33.686	\N	2026-05-02 11:54:34.12
eb609024-2d56-4c3f-a4f9-7e7cf5466477	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784100166983	contact	3391365375455109655	Huy	Set khế hay gì nó tự lên tím vàng hết:) k cần phải mua ở chợ đâu	text	[]	f	\N	2026-05-02 11:54:54.847	\N	2026-05-02 11:54:55.085
0eebbf91-abc8-4ccf-a297-65fe7df9f524	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784122316436	contact	442684109737541411	Cường Tạ	{"title":"","description":"","href":"https://video-stal-4.dlmd.me/gr/15b339108c824ddc1493/pWF2AmF0GwAAAZ3okILPYWYAYXUCYXMaAFAlDA","thumb":"https://photo-stal-25.zdn.vn/gr/606bbda50837c9699026/2819132692122377283.jpg","childnumber":0,"action":"","params":"{\\"duration\\":32000,\\"is_group_layout\\":0,\\"video_original_width\\":480,\\"video_original_height\\":854,\\"video_width\\":480,\\"video_height\\":854,\\"video_rotation\\":0,\\"fileSize\\":5252364,\\"isHD\\":0}","type":""}	video	[]	f	\N	2026-05-02 12:02:41.906	\N	2026-05-02 12:02:42.338
8748de89-c1f8-45c4-bb26-31b53b8217d8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784297065928	contact	6562854816970626324	Đức Bình	Kiếm acc bay 13xx ae nhé	text	[]	f	\N	2026-05-02 13:02:20.938	\N	2026-05-02 13:02:21.375
4ba6d259-2e81-4149-8bae-82293dc2c652	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784306221119	contact	3874537684008431042	Trang Thành Lộc	;xx ;xx	text	[]	f	\N	2026-05-02 13:05:19.297	\N	2026-05-02 13:05:29.438
c32ab8f0-bd8d-4292-beee-7ec71b2d9fc3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784126786158	contact	7498720695294354711	Nguyễn Quốc Hữu	{"title":"","description":"","href":"https://photo-stal-25.zdn.vn/gr/jpg/887fbc5904cbc5959cda/3734726208909873930.jpg","thumb":"https://photo-stal-25.zdn.vn/gr/jpg/887fbc5904cbc5959cda/3734726208909873930.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-25.zdn.vn\\\\/gr\\\\/jpg\\\\/887fbc5904cbc5959cda\\\\/3734726208909873930.jpg\\",\\"width\\":2778,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-02 12:04:15.7	\N	2026-05-02 12:04:16.083
a323d1f6-bec5-4ab5-b4c6-f288cb2b4655	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784128708586	contact	7498720695294354711	Nguyễn Quốc Hữu	Chắc botcheck của khứa nào	text	[]	f	\N	2026-05-02 12:04:56.062	\N	2026-05-02 12:04:56.312
936a2d89-dec1-45ed-82b2-fdce499fafd8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784141283156	contact	3540842572674797348	Tạ Gia Long	@Nguyễn Thành tiền đâu	text	[]	f	\N	2026-05-02 12:09:20.767	\N	2026-05-02 12:09:21.14
c27da2c6-0815-4b6a-89a9-e70d8b6179cd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784141379140	contact	3540842572674797348	Tạ Gia Long	{"id":45356,"catId":11901,"type":3}	sticker	[]	f	\N	2026-05-02 12:09:22.784	\N	2026-05-02 12:09:22.895
b0105f3c-5f5d-4f34-81c9-34c48501da37	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784147859855	contact	4384990568718728157	Khủng Long Đỏ	@All  xe ONG CHÚA  1q5=2q4=1q4+3q3=6q3 out guil cũ và nộp đơn lên xe nhé ae	text	[]	f	\N	2026-05-02 12:11:39.584	\N	2026-05-02 12:11:40.132
fc5865b4-a09e-4ed2-a778-9a7178d96dde	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784149323222	contact	7998210325808057592	Khang Nguyễn	@Khủng Long Đỏ xe nào :)))	text	[]	f	\N	2026-05-02 12:12:10.623	\N	2026-05-02 12:12:11.075
ec0f1b3a-7000-4c6b-80b6-1838e9b1be23	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784150085276	contact	4384990568718728157	Khủng Long Đỏ	@Khang Nguyễn fom:)	text	[]	f	\N	2026-05-02 12:12:26.717	\N	2026-05-02 12:12:26.968
eeb132fe-bb2f-4a66-a50d-362e91c6d1c4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784150323426	contact	6554538239607812593	Triết	Xe ong chúa	text	[]	f	\N	2026-05-02 12:12:31.777	\N	2026-05-02 12:12:32.128
64189cb9-8e18-4faf-99d8-b6e1819e7f76	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784154917247	contact	2226503885650453985	Nguyễn Thành	@Tạ Gia Long Ko có tiền mới phải mua đó, ko có ấn sói kiếm điểm hỗn độn khó	text	[]	f	\N	2026-05-02 12:14:08.605	\N	2026-05-02 12:14:09.041
d7287aa1-5ffc-44a8-b5bd-ed7cf634e7df	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784185787570	contact	3534643548480446730	Trương Đức Tính	{"title":"","description":"","href":"https://f64-zpg-r.zdn.vn/jpg/1768760787802137247/1843e6700473852ddc62.jpg","thumb":"https://f64-zpg-r.zdn.vn/jpg/1768760787802137247/1843e6700473852ddc62.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":693,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":1170,\\"height\\":2532,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-02 12:24:57.172	\N	2026-05-02 12:24:57.692
5c64ef49-964d-4f2f-a113-0017bcd608fe	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784186210302	contact	2032429908843083059	Yangb	{"title":"","description":"","href":"https://photo-stal-28.zdn.vn/gr/jpg/d69e9e907f02be5ce713/173196396795747578.jpg","thumb":"https://photo-stal-28.zdn.vn/gr/jpg/d69e9e907f02be5ce713/173196396795747578.jpg","childnumber":0,"action":"","params":"{\\"width\\":2400,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-28.zdn.vn\\\\/gr\\\\/jpg\\\\/d69e9e907f02be5ce713\\\\/173196396795747578.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000375502\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 12:25:05.964	\N	2026-05-02 12:25:06.358
fdf7ed6a-e2e5-49d1-aac9-e1adbf9d857c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784186376365	contact	2032429908843083059	Yangb	1379	text	[]	f	\N	2026-05-02 12:25:09.383	\N	2026-05-02 12:25:09.505
a1ab7168-3a38-42cf-9d03-6473c96a1927	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784197866359	contact	1851864074683856820	Đxn	{"title":"","description":"","href":"https://photo-stal-35.zdn.vn/gr/jpg/017d34ec2371e22fbb60/1879285424321135016.jpg","thumb":"https://photo-stal-35.zdn.vn/gr/jpg/017d34ec2371e22fbb60/1879285424321135016.jpg","childnumber":0,"action":"","params":"{\\"width\\":2316,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-35.zdn.vn\\\\/gr\\\\/jpg\\\\/017d34ec2371e22fbb60\\\\/1879285424321135016.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000005859\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 12:29:08.924	\N	2026-05-02 12:29:09.374
cca2c1de-6c08-4c62-8b4b-4332017b7ce4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784198162421	contact	1851864074683856820	Đxn	Bú hehe	text	[]	f	\N	2026-05-02 12:29:15.15	\N	2026-05-02 12:29:15.336
a5f6526e-0f81-4502-9753-fe34da974de8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784198364242	contact	7498720695294354711	Nguyễn Quốc Hữu	@Đxn xứng đáng zero	text	[]	f	\N	2026-05-02 12:29:19.314	\N	2026-05-02 12:29:19.759
87960500-0d68-4650-9a8e-d12818da3a49	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784213095567	contact	262937886851184801	Thu Phan	{"title":"","description":"","href":"https://photo-stal-9.zdn.vn/gr/jpg/6900a14fa3d2628c3bc3/676090054508309556.jpg","thumb":"https://photo-stal-9.zdn.vn/gr/jpg/6900a14fa3d2628c3bc3/676090054508309556.jpg","childnumber":0,"action":"","params":"{\\"width\\":1908,\\"height\\":858,\\"is_group_layout\\":0,\\"contentId\\":\\"26297\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 12:34:23.827	\N	2026-05-02 12:34:24.288
e6dce54e-c478-403b-a0c9-700a00ee0ede	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784213848671	contact	262937886851184801	Thu Phan	Off mấy h mà nó solo t luôn	text	[]	f	\N	2026-05-02 12:34:39.347	\N	2026-05-02 12:34:39.585
c280cfaa-b257-4148-93b3-0399393d4441	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784222437936	contact	7387240757415509891	Trần Thoại	A zai chịu đau dữ quá	text	[]	f	\N	2026-05-02 12:37:35.834	\N	2026-05-02 12:37:36.232
2e850735-d1f8-4391-8a88-2d7507129535	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784250020371	contact	3540842572674797348	Tạ Gia Long	@Thu Phan zero r à	text	[]	f	\N	2026-05-02 12:46:53.082	\N	2026-05-02 12:46:53.544
c9ce2155-8d46-4d16-8411-4ea635720ffa	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784266802396	contact	8087701766132846650	Vũ Lộc	@Thu Phan might bao nhiêu mà nó solo vậy	text	[]	f	\N	2026-05-02 12:52:27.317	\N	2026-05-02 12:52:27.749
ce9e480e-2e9c-4d6a-be8d-28c5b25dadd9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784281760250	contact	585801465063846950	Võ Vũ Nam 武武南	Kiếm rồng 12	text	[]	f	\N	2026-05-02 12:57:22.716	\N	2026-05-02 12:57:23.101
7f332fef-39a3-460c-ac61-2ef8b0fdf0c7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784281960839	contact	585801465063846950	Võ Vũ Nam 武武南	H mũ cốt mới vàng	text	[]	f	\N	2026-05-02 12:57:26.741	\N	2026-05-02 12:57:26.856
2ed7f6b9-16c5-4d40-906b-8e68e5fb9e75	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784282051063	contact	585801465063846950	Võ Vũ Nam 武武南	Cmn :))	text	[]	f	\N	2026-05-02 12:57:28.467	\N	2026-05-02 12:57:28.618
d9b94bb8-07f3-4c46-94d4-1cbc04ae90cd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784283278827	contact	4881617662073102521	Nguyễn Minh Tuan	Ghê	text	[]	f	\N	2026-05-02 12:57:52.631	\N	2026-05-02 12:57:53.082
43acbb76-72b9-415a-8904-0a69ff3fd069	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784284606605	contact	585801465063846950	Võ Vũ Nam 武武南	Mũ ong sắp vàng tới	text	[]	f	\N	2026-05-02 12:58:18.701	\N	2026-05-02 12:58:18.977
99fe0d15-7233-417e-bd20-da02bd520121	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784285848805	contact	585801465063846950	Võ Vũ Nam 武武南	Xog chợ 1 vàng nx lên vàng luôn	text	[]	f	\N	2026-05-02 12:58:43.123	\N	2026-05-02 12:58:43.463
58e7947c-c45c-4ca9-bf39-c7d78653eee3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784309926851	contact	7387240757415509891	Trần Thoại	@Đức Bình tìm như nào	text	[]	f	\N	2026-05-02 13:06:31.613	\N	2026-05-02 13:06:32.021
53f8fe3f-2bff-47a8-ab7b-e58cd4043e64	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784310152522	contact	7387240757415509891	Trần Thoại	Acc join t5 đc k	text	[]	f	\N	2026-05-02 13:06:36.01	\N	2026-05-02 13:06:36.263
c76ab268-7bfe-4a8a-9739-eb45da8fe042	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784315518144	contact	7387240757415509891	Trần Thoại	{"title":"","description":"","href":"https://photo-stal-2.zdn.vn/gr/jpg/9cad14e6967b57250e6a/2550380592467220280.jpg","thumb":"https://photo-stal-2.zdn.vn/gr/jpg/9cad14e6967b57250e6a/2550380592467220280.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":1,\\"group_layout_id\\":1777727300443,\\"id_in_group\\":0,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000054737\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 13:08:20.955	\N	2026-05-02 13:08:21.204
13e16aae-0ea2-4af6-8b39-80fa3df4f178	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784315531468	contact	7387240757415509891	Trần Thoại	{"title":"","description":"","href":"https://photo-stal-19.zdn.vn/gr/jpg/331f0d528fcf4e9117de/1395661825709217845.jpg","thumb":"https://photo-stal-19.zdn.vn/gr/jpg/331f0d528fcf4e9117de/1395661825709217845.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":1,\\"group_layout_id\\":1777727300443,\\"id_in_group\\":1,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000054738\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 13:08:21.187	\N	2026-05-02 13:08:21.305
b64c53d8-f72f-4c39-a5cb-552b651fed2e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784316117842	contact	7387240757415509891	Trần Thoại	Bay đc 1k47x 150k	text	[]	f	\N	2026-05-02 13:08:32.665	\N	2026-05-02 13:08:32.929
5538da4d-8726-498c-9f0f-b40adddf6da6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784411969029	contact	305746081800824633	Thịnh	ai bán mấy con clone nhiều gem ko	text	[]	f	\N	2026-05-02 13:39:47.709	\N	2026-05-02 13:39:48.169
ad281ba5-6088-4a1e-b273-10c7627ce1cf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784421441753	contact	7387240757415509891	Trần Thoại	Mua mấy acc bot 150k ông tính kìa	text	[]	f	\N	2026-05-02 13:42:54.419	\N	2026-05-02 13:42:54.863
5caf9012-2cb8-4a98-bae4-d15210ad6019	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784425262965	contact	792834338766427655	Lưu Văn Duy	@Thịnh acc 600-700k gems dc k	text	[]	f	\N	2026-05-02 13:44:09.969	\N	2026-05-02 13:44:10.434
619e95c9-507b-4125-8220-a878c3ec737f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784428471693	contact	3534643548480446730	Trương Đức Tính	@Trần Thoại đúng đúng , quá ngon :))	text	[]	f	\N	2026-05-02 13:45:13.6	\N	2026-05-02 13:45:13.986
175e1601-7caa-4e57-aee9-805b83e27255	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784431423855	contact	7387240757415509891	Trần Thoại	{"id":46953,"catId":12002,"type":3}	sticker	[]	f	\N	2026-05-02 13:46:11.455	\N	2026-05-02 13:46:11.751
cacb1f02-8ae7-4374-9977-5dfe481ac18c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784466158804	contact	3564335989560761200	Phạm Anh	Nếu bị tấn công 947 thì thủ tỷ lệ nào được mn nhỉ? Cho xin ý kiến với	text	[]	f	\N	2026-05-02 13:57:38.08	\N	2026-05-02 13:57:38.504
2f9b24db-ef99-4304-bed4-432a6a3f40f9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784472808493	contact	4881617662073102521	Nguyễn Minh Tuan	ct bộ luôn:D	text	[]	f	\N	2026-05-02 13:59:50.105	\N	2026-05-02 13:59:50.553
e8571c69-8f11-457d-a1f4-6385d2bba683	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784473141247	contact	585801465063846950	Võ Vũ Nam 武武南	Khó	text	[]	f	\N	2026-05-02 13:59:55.937	\N	2026-05-02 13:59:56.286
715b03f1-3899-482c-b6bf-799f6925f3ef	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784473346971	contact	585801465063846950	Võ Vũ Nam 武武南	Trừ khi nó k chống	text	[]	f	\N	2026-05-02 13:59:59.997	\N	2026-05-02 14:00:00.147
85311912-3d6d-44bd-b354-19fd2ecbd187	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784474379989	contact	585801465063846950	Võ Vũ Nam 武武南	Bác hỏi z chỉ khi có spy báo tỉ lệ bác khắc tỉ lệ đó th	text	[]	f	\N	2026-05-02 14:00:20.056	\N	2026-05-02 14:00:20.317
3028a94a-23d9-4858-b95f-ed203d7688c8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784477124775	contact	3564335989560761200	Phạm Anh	Hihi mình ko rành thật, 947 mới def đi gần hết dàn bộ	text	[]	f	\N	2026-05-02 14:01:13.228	\N	2026-05-02 14:01:13.758
2e96665a-ce14-4312-a696-6095bee997a2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784477951053	contact	3564335989560761200	Phạm Anh	Hỏi để kinh nghiệm lần tới	text	[]	f	\N	2026-05-02 14:01:29.447	\N	2026-05-02 14:01:29.73
c296c521-f3bd-4374-8bd7-d56c15ad85e7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784482650518	contact	7387240757415509891	Trần Thoại	Pt cung	text	[]	f	\N	2026-05-02 14:03:01.7	\N	2026-05-02 14:03:02.163
f8929d8f-438f-4a63-a07e-e6a3932e5850	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784482977999	contact	7387240757415509891	Trần Thoại	Hay ct cung cx đc:))	text	[]	f	\N	2026-05-02 14:03:08.143	\N	2026-05-02 14:03:08.37
9b063719-27b7-4973-b42e-3da0672fcc56	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784483193144	contact	7387240757415509891	Trần Thoại	Nhưng hơi đau	text	[]	f	\N	2026-05-02 14:03:12.426	\N	2026-05-02 14:03:12.623
408a8536-f12e-4ca4-9054-bd4afed7578c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784490505912	contact	4881617662073102521	Nguyễn Minh Tuan	@Phạm Anh nó đi trận j bác	text	[]	f	\N	2026-05-02 14:05:37.314	\N	2026-05-02 14:05:37.697
314e3f55-4965-427d-9083-38bb2d4da646	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784492274450	contact	4881617662073102521	Nguyễn Minh Tuan	lên dày bộ cung def ct bộ thôi:D	text	[]	f	\N	2026-05-02 14:06:11.712	\N	2026-05-02 14:06:11.952
42561b41-67f7-4050-bccd-442fd94199ec	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784507951077	contact	3564335989560761200	Phạm Anh	@Nguyễn Minh Tuan bộ bác	text	[]	f	\N	2026-05-02 14:11:22.984	\N	2026-05-02 14:11:23.418
d43cb4d5-36b6-43b3-96f2-def6daccc883	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784509252831	contact	3564335989560761200	Phạm Anh	Ct bộ	text	[]	f	\N	2026-05-02 14:11:48.99	\N	2026-05-02 14:11:49.215
ef52d257-a4d5-49c4-a07a-48356abb012b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784510714349	contact	3564335989560761200	Phạm Anh	@Nguyễn Minh Tuan nếu quay def trận kỵ	text	[]	f	\N	2026-05-02 14:12:18.214	\N	2026-05-02 14:12:18.523
27386d81-6ee1-4a44-ac48-0766f423c396	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784511104077	contact	3564335989560761200	Phạm Anh	Thì ntn bác nhỉ	text	[]	f	\N	2026-05-02 14:12:25.995	\N	2026-05-02 14:12:26.308
3d8bbe3b-65ed-46d7-b43d-4ab082dc0e80	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784512087222	contact	3564335989560761200	Phạm Anh	@Nguyễn Minh Tuan vậy chỉ có lên dầy bộ cung thôi hả bác	text	[]	f	\N	2026-05-02 14:12:45.725	\N	2026-05-02 14:12:45.976
de6b5b3b-1f33-4f51-81d1-362f8d6d378c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784512913972	contact	4881617662073102521	Nguyễn Minh Tuan	@Phạm Anh có điều kiện cứ nhiều lính là tốt:))	text	[]	f	\N	2026-05-02 14:13:02.847	\N	2026-05-02 14:13:03.29
75f5abf3-b339-4047-9c85-7855b76ae6e8	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784517114055	contact	3429230737531381136	Nguyễn Nhật Tân	Stt nhóm tên đề tài giang viên hướng dẫn nếu t nhớ ko lầm	text	[]	f	\N	2026-05-02 14:14:26.169	\N	2026-05-02 14:14:26.602
fdf34123-0c5a-4a13-a51d-0ac1f6335f9a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784517168011	contact	3564335989560761200	Phạm Anh	@Nguyễn Minh Tuan nhiều tầm bn bác nhỉ? T4 mỗi loại tầm bn và t2	text	[]	f	\N	2026-05-02 14:14:27.246	\N	2026-05-02 14:14:27.395
ff124b9b-9a26-46e6-b800-6c8e1cf8ed97	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790389756620	contact	4769288754303725608	Hiếu	Hè hé	text	[]	f	\N	2026-05-04 11:52:26.418	\N	2026-05-04 11:52:26.533
b9b2708c-ba0f-4502-9b5e-b7f827957fab	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784519862933	contact	3429230737531381136	Nguyễn Nhật Tân	M coi xem tụi nó nộp file tên gì ko hỏi bả lun cho chắc hỏi lun mình làm đơn tốt nghiệp lấy ở đâu nộp ở đâu lun	text	[]	f	\N	2026-05-02 14:15:21.098	\N	2026-05-02 14:15:21.312
9ddc5e0c-bcee-4462-9063-18d5dfd75cda	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784521277597	contact	4881617662073102521	Nguyễn Minh Tuan	mấy idol trap rally đâu rùi, vô tư vấn nè @@	text	[]	f	\N	2026-05-02 14:15:49.649	\N	2026-05-02 14:15:49.924
a83b2e07-0640-4445-b590-db6710655d73	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784522840691	contact	4579632439414729865	Tungthanh	{"id":46953,"catId":12002,"type":3}	sticker	[]	f	\N	2026-05-02 14:16:20.49	\N	2026-05-02 14:16:20.928
a9eb04ac-ab8b-4f62-a11e-cd5ccbfeaaab	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784523490755	contact	4579632439414729865	Tungthanh	chưa bị đấm nên chưa tư vấn đc	text	[]	f	\N	2026-05-02 14:16:33.585	\N	2026-05-02 14:16:33.859
65516abc-86a8-4019-825d-b53fcbff22c6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784523690616	contact	4579632439414729865	Tungthanh	kêu nó đấm t phát	text	[]	f	\N	2026-05-02 14:16:37.621	\N	2026-05-02 14:16:37.754
710057d5-ad97-43c9-8e34-aeae3d029ed0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784524001903	contact	4579632439414729865	Tungthanh	def xong tư vấn cho	text	[]	f	\N	2026-05-02 14:16:43.882	\N	2026-05-02 14:16:44.121
07c7f7d4-4918-40f8-baec-d35a275bbdf4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784527157069	contact	3391365375455109655	Huy	@Phạm Anh cung	text	[]	f	\N	2026-05-02 14:17:47.466	\N	2026-05-02 14:17:47.923
66ccf2f1-5198-4b89-b66e-2a04e79d4db1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784527990257	contact	3391365375455109655	Huy	Cubg ngon nhất	text	[]	f	\N	2026-05-02 14:18:04.25	\N	2026-05-02 14:18:04.453
ca384037-d762-4057-923d-0fd154eb4077	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784528537334	contact	3429230737531381136	Nguyễn Nhật Tân	Thì đó sst nhóm tên đề tài giảng viên hướng dẫn t nhớ mang máng thôi nha	text	[]	f	\N	2026-05-02 14:18:15.339	\N	2026-05-02 14:18:15.547
406a3034-3d06-4ac1-98a6-f5ed84d1e1b9	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784530557393	contact	3429230737531381136	Nguyễn Nhật Tân	Sao lại là t	text	[]	f	\N	2026-05-02 14:18:56.216	\N	2026-05-02 14:18:56.4
a84a775d-387e-4f92-b78a-bb584f096e16	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784531486586	contact	3429230737531381136	Nguyễn Nhật Tân	Cả 3 tk chịu	text	[]	f	\N	2026-05-02 14:19:14.896	\N	2026-05-02 14:19:15.142
ec614d1a-c701-4158-bee3-97b09898a6d0	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784533440983	contact	3429230737531381136	Nguyễn Nhật Tân	T có kêu đâu m hỏi t trl mà	text	[]	f	\N	2026-05-02 14:19:54.363	\N	2026-05-02 14:19:54.734
b437d7a3-ecf7-44cb-82f0-9bb5ae7cd921	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784534426130	contact	3429230737531381136	Nguyễn Nhật Tân	Hỏi bà nhường đi bả trl à sẵn hỏi này lun	text	[]	f	\N	2026-05-02 14:20:14.22	\N	2026-05-02 14:20:14.422
426e0aab-4aa0-449b-8078-f4a614d9d11e	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784538066210	contact	3429230737531381136	Nguyễn Nhật Tân	Sợ chứ chưa ra mà khi nào ra rồi muốn làm gì làm	text	[]	f	\N	2026-05-02 14:21:27.911	\N	2026-05-02 14:21:28.111
9219e8c9-eb2c-4f79-aace-508cea508f50	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784541510385	contact	3429230737531381136	Nguyễn Nhật Tân	Thì nộp phải đàng hoàng chứ m mik có biết điểm bao nhiêu đâu nó trừ sao mình biết đc	text	[]	f	\N	2026-05-02 14:22:37.821	\N	2026-05-02 14:22:38.029
3c4aef73-c521-472d-8144-94fdff24f850	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784544084651	contact	3429230737531381136	Nguyễn Nhật Tân	Nhét đc 100 trang ko hiệp:))	text	[]	f	\N	2026-05-02 14:23:30.032	\N	2026-05-02 14:23:30.244
17d2ec2c-1ef7-42dc-b3fc-c3dff4acdc16	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784546217356	contact	3429230737531381136	Nguyễn Nhật Tân	Thôi qua chỉ tiêu đc rồi	text	[]	f	\N	2026-05-02 14:24:13.405	\N	2026-05-02 14:24:13.626
c3caf84f-75e6-4440-a282-3158fd6795aa	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784549217018	contact	3429230737531381136	Nguyễn Nhật Tân	Ủa ổng gửi hả tưởng mình gửi zo file gì của bà nhường chứ	text	[]	f	\N	2026-05-02 14:25:14.291	\N	2026-05-02 14:25:14.695
f3751b86-aad8-430a-a1a0-24462cd4fe8b	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784552781061	contact	3429230737531381136	Nguyễn Nhật Tân	{"title":"Agentic_AI_Supply_Chain_Risk_Analysis_(6).pptx","description":"","href":"https://file-stal-1006.dlfl.vn/gr/0dc578e2d37e12204b6f/4279214103631374125","thumb":"","childnumber":0,"action":"","params":"{\\"fileSize\\":\\"165309456\\", \\"checksum\\":\\"1378024f5d9cfc69a61e4b5922b97b5b\\", \\"checksumSha\\":\\"null\\", \\"fileExt\\":\\"pptx\\", \\"fdata\\":\\"{}\\", \\"fType\\":1}","type":""}	file	[]	f	\N	2026-05-02 14:26:27.562	\N	2026-05-02 14:26:27.733
b53a971f-3432-4148-bbd5-5d231d6bdc61	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784554267024	contact	3429230737531381136	Nguyễn Nhật Tân	@Trần Nghĩa Hiệp m cũng phải kêu ổng nhận xét lun để ổng gửi ko	text	[]	f	\N	2026-05-02 14:26:57.766	\N	2026-05-02 14:26:57.92
66658150-8379-47a2-81ff-cd7c7b8801fd	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784555412700	contact	3429230737531381136	Nguyễn Nhật Tân	ủa có kêu z hả ta ko nhớ gì hết lun á	text	[]	f	\N	2026-05-02 14:27:21.529	\N	2026-05-02 14:27:21.794
4f27272a-1b70-4493-8c13-df744d5eb472	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784683444817	contact	2320230736563113524	Lương Minh Khoa	bác cứ bộ cho em	text	[]	f	\N	2026-05-02 15:13:20.096	\N	2026-05-02 15:13:20.503
af833a9f-fd86-4c3c-938d-46f9156acaaf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784684257382	contact	7498720695294354711	Nguyễn Quốc Hữu	Atk cung cao thì lợi mà	text	[]	f	\N	2026-05-02 15:13:38.532	\N	2026-05-02 15:13:38.873
c6a81830-a7bb-4b90-8f5b-180ccef16367	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784684893796	contact	7498720695294354711	Nguyễn Quốc Hữu	Bộ thì dễ bị về	text	[]	f	\N	2026-05-02 15:13:53.127	\N	2026-05-02 15:13:53.408
37b426a0-3e28-464b-b4d9-4a23f8462da9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784734982102	contact	826306325505433968	Nana	{"title":"","description":"","href":"https://photo-stal-29.zdn.vn/gr/jpg/ddadb310338ff2d1ab9e/2185210549462401121.jpg","thumb":"https://photo-stal-29.zdn.vn/gr/jpg/ddadb310338ff2d1ab9e/2185210549462401121.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":0,\\"contentId\\":\\"24174\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 15:34:24.126	\N	2026-05-02 15:34:24.56
2e29a717-3307-429a-af9a-3c7c1198640e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784735807673	contact	826306325505433968	Nana	K có nhà ở mn ai cho e tá túc với	text	[]	f	\N	2026-05-02 15:34:46.472	\N	2026-05-02 15:34:46.758
b9018cd6-c141-4eaa-bf27-be9c3e24dbbe	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784737649918	contact	826306325505433968	Nana	{"title":"","description":"","href":"https://photo-stal-15.zdn.vn/gr/jpg/1d54b7b23a2dfb73a23c/1765781565298146756.jpg","thumb":"https://photo-stal-15.zdn.vn/gr/jpg/1d54b7b23a2dfb73a23c/1765781565298146756.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":0,\\"contentId\\":\\"24172\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 15:35:36.449	\N	2026-05-02 15:35:36.692
5ad82c0d-e51b-42ce-b9d1-710b578270e2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784737986479	contact	826306325505433968	Nana	Bị khóa tiếng	text	[]	f	\N	2026-05-02 15:35:45.675	\N	2026-05-02 15:35:45.919
334ce25f-528b-4ed2-bab5-44c5be5134ea	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784738369719	contact	826306325505433968	Nana	😢	text	[]	f	\N	2026-05-02 15:35:56.178	\N	2026-05-02 15:35:56.379
1e079979-57d3-4733-bf0a-e5b256a351a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784739516098	contact	386507739282916698	Tuấn Peodethuong	Thì ibox bọn cskh, bọn nó mở lại cho	text	[]	f	\N	2026-05-02 15:36:27.369	\N	2026-05-02 15:36:27.811
29aa5778-c842-4f12-8d1b-ba30a0b9a6d8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784743572082	contact	8395788325665172100	Lê Quang Long	Thấy cũng bị khóa, r ibox kêu mở nma 2 lần r, đều k dc, chán chả thèm nt, nó khóa 5 ngày xg mở lại bt thôi @@	text	[]	f	\N	2026-05-02 15:38:18.598	\N	2026-05-02 15:38:19.031
02863aac-50d0-465c-ba41-899f60e3f530	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784743894187	contact	386507739282916698	Tuấn Peodethuong	Bần đạo còn spam hoàng sa trường sa lên game, xong còn bị báo cấm mõm vĩnh viễn cơ mà	text	[]	f	\N	2026-05-02 15:38:27.497	\N	2026-05-02 15:38:27.778
bb788ee1-24a0-44a7-898b-1eb75a66f42e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784745071883	contact	386507739282916698	Tuấn Peodethuong	Bị ban mồm, xong nt spam mãi, nó mới mở	text	[]	f	\N	2026-05-02 15:39:00.173	\N	2026-05-02 15:39:00.414
db63bd55-36a2-471e-b5cc-0cd8cbb7ddf9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784745549469	contact	386507739282916698	Tuấn Peodethuong	Bắt cam kết ko chính trị các kiểu	text	[]	f	\N	2026-05-02 15:39:13.402	\N	2026-05-02 15:39:13.611
44c70ad5-d125-413b-9856-949889924b12	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784750773250	contact	8395788325665172100	Lê Quang Long	À là cứ lì mặt scam là mở cho t, nhiều lần là dc hả, +1 kiến thức kk	text	[]	f	\N	2026-05-02 15:41:39.234	\N	2026-05-02 15:41:39.537
998ac56a-2ce8-4ef4-bfdf-6c4c3951e8ad	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784752507649	contact	2320230736563113524	Lương Minh Khoa	@Nana  bang nông dân bb5 nhé bác,ko cần di trú	text	[]	f	\N	2026-05-02 15:42:27.535	\N	2026-05-02 15:42:27.943
054641f9-1ec6-4a5b-aff3-6298b47fe406	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784752933381	contact	2320230736563113524	Lương Minh Khoa	nhắn r5 cho em	text	[]	f	\N	2026-05-02 15:42:39.745	\N	2026-05-02 15:42:39.974
bfe25516-d3e2-4d39-b485-69dfc3335e58	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784759684606	contact	826306325505433968	Nana	@Lương Minh Khoa có ngừi nt rùi	text	[]	f	\N	2026-05-02 15:45:50.962	\N	2026-05-02 15:45:51.358
6eadd6d8-2292-4226-9e50-d2b8ff94955f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784760082428	contact	826306325505433968	Nana	{"title":"","description":"","href":"https://photo-stal-35.zdn.vn/gr/jpg/a76b6168d8f719a940e6/948763708029986763.jpg","thumb":"https://photo-stal-35.zdn.vn/gr/jpg/a76b6168d8f719a940e6/948763708029986763.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":0,\\"contentId\\":\\"24178\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 15:46:02.219	\N	2026-05-02 15:46:02.591
b305d5f3-db71-41dc-88c2-5d8d8b1d0087	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784760557846	contact	826306325505433968	Nana	Đồ hơi cùi may ngừi ta nhận	text	[]	f	\N	2026-05-02 15:46:15.828	\N	2026-05-02 15:46:16.09
f7f794a4-9750-467e-8e03-9e0a78fcb7f6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784771134591	contact	826306325505433968	Nana	@Lương Minh Khoa cảm ơn nhớ mốt bị đủi em wa	text	[]	f	\N	2026-05-02 15:51:23.957	\N	2026-05-02 15:51:24.426
a454f073-00d7-4bfc-9837-d9d4901dcebf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784771651519	contact	2320230736563113524	Lương Minh Khoa	Đồ này trâu quá	text	[]	f	\N	2026-05-02 15:51:39.196	\N	2026-05-02 15:51:39.58
af72d175-def3-4e9f-8083-ed2b9b8f02a2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784775847605	contact	826306325505433968	Nana	@Lương Minh Khoa tại ở mấy bang khác r4 nt riêng mà acc e bị khóa sao rep đc	text	[]	f	\N	2026-05-02 15:53:43.802	\N	2026-05-02 15:53:44.076
408b9817-d29d-42d1-94b3-b3d990b40487	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784776222798	contact	3391365375455109655	Huy	@Nana king nào d b	text	[]	f	\N	2026-05-02 15:53:55.061	\N	2026-05-02 15:53:55.486
f1b3cdbe-8f94-4b45-9659-712f49b37ead	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784776236428	contact	826306325505433968	Nana	Z là họ đủi	text	[]	f	\N	2026-05-02 15:53:55.518	\N	2026-05-02 15:53:55.649
60d6c90d-98d4-41db-a8fa-260dcf85a7b0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784776733921	contact	826306325505433968	Nana	@Huy 1631 thì phải	text	[]	f	\N	2026-05-02 15:54:10.403	\N	2026-05-02 15:54:10.627
a4ab04c1-c6d4-458b-8c7b-24259f214cf4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784776973403	contact	826306325505433968	Nana	Mới di trú xuống	text	[]	f	\N	2026-05-02 15:54:17.494	\N	2026-05-02 15:54:17.728
85fbaa80-770d-4c38-aeab-7fe5c9c87d29	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784777792650	contact	826306325505433968	Nana	Acc e bị khóa tiếng nên on mà mn hỏi k trả lời	text	[]	f	\N	2026-05-02 15:54:42.001	\N	2026-05-02 15:54:42.244
6d0437f5-3b27-44a2-ade6-814266c92d80	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784778061443	contact	826306325505433968	Nana	Họ kích liền á	text	[]	f	\N	2026-05-02 15:54:50.036	\N	2026-05-02 15:54:50.41
85b80827-3a5f-43bd-9144-df7d8f376d5f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784781245709	contact	4881617662073102521	Nguyễn Minh Tuan	@Nana xịn thế mà	text	[]	f	\N	2026-05-02 15:56:25.105	\N	2026-05-02 15:56:25.54
b987ea5b-d6ce-4cb5-a050-708a861a5588	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784781638537	contact	826306325505433968	Nana	@Nguyễn Minh Tuan nhưng k chát đc	text	[]	f	\N	2026-05-02 15:56:36.926	\N	2026-05-02 15:56:37.26
888cdb94-c4cc-4daf-b6c7-f30e9103a7d5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784782441799	contact	826306325505433968	Nana	Ở bang nào cũng bị đủi tại vì k trả lời	text	[]	f	\N	2026-05-02 15:57:00.86	\N	2026-05-02 15:57:01.111
f575c5f5-9e1e-475f-9745-440e9d3edc4e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784783165485	contact	826306325505433968	Nana	Acc e trap nữa	text	[]	f	\N	2026-05-02 15:57:22.751	\N	2026-05-02 15:57:23.03
f9e8c52d-316a-4186-bd98-d17e7c2c4e27	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784783450949	contact	826306325505433968	Nana	Chỉ def vs join lính	text	[]	f	\N	2026-05-02 15:57:31.292	\N	2026-05-02 15:57:31.5
e634ad0c-1eec-4db8-99e5-91642d506936	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784784260297	contact	826306325505433968	Nana	Từ 17xx đi xuống 16xx	text	[]	f	\N	2026-05-02 15:57:55.769	\N	2026-05-02 15:57:56.05
cb8b97ff-0e3e-4fa4-b5e6-ac3a37337f04	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784784375971	contact	4881617662073102521	Nguyễn Minh Tuan	K nhắn đỡ bị bot check	text	[]	f	\N	2026-05-02 15:57:59.317	\N	2026-05-02 15:57:59.46
7b362d16-c0f6-4021-afba-89a25e40a449	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784784809084	contact	2320230736563113524	Lương Minh Khoa	mục đích chính	text	[]	f	\N	2026-05-02 15:58:12.443	\N	2026-05-02 15:58:12.839
b317efdf-fda1-4d7a-92e3-e0157ca9cef0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784784926756	contact	4881617662073102521	Nguyễn Minh Tuan	Gửi thư riêng thì có đc k	text	[]	f	\N	2026-05-02 15:58:15.915	\N	2026-05-02 15:58:16.058
96c49bf5-9825-4033-8e22-29968fb05345	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784785250369	contact	826306325505433968	Nana	K chat đc	text	[]	f	\N	2026-05-02 15:58:25.841	\N	2026-05-02 15:58:26.124
8edfc28e-6ece-4dd5-b177-a1d352c27672	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784785299243	contact	2320230736563113524	Lương Minh Khoa	chắc nhắn riêng zalo dx	text	[]	f	\N	2026-05-02 15:58:27.467	\N	2026-05-02 15:58:27.577
a735c304-ee79-4609-91d1-9715780343aa	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784785574253	contact	826306325505433968	Nana	@Lương Minh Khoa đr	text	[]	f	\N	2026-05-02 15:58:35.677	\N	2026-05-02 15:58:35.897
c98dd455-0e07-4533-a979-75701e8ffa93	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784785597970	contact	2320230736563113524	Lương Minh Khoa	chỉ sợ vợ thôi	text	[]	f	\N	2026-05-02 15:58:36.704	\N	2026-05-02 15:58:36.822
27d8779c-d9fe-4d29-8826-861581e89bd2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784786864153	contact	826306325505433968	Nana	E nhìu nhóm nên k tiện vào nhóm bang	text	[]	f	\N	2026-05-02 15:59:15.126	\N	2026-05-02 15:59:15.356
313e2fd0-f595-4c02-846a-b9b5971457fb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784786910104	contact	2320230736563113524	Lương Minh Khoa	như vậy, sẽ cần 1 acc khác cùng kênh, để biết ?	text	[]	f	\N	2026-05-02 15:59:16.715	\N	2026-05-02 15:59:16.835
77a82013-617d-428c-868b-9a4e095c6e5b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784803124364	contact	386507739282916698	Tuấn Peodethuong	@Nana đồ này là ổn rồi, nhưng kể cả có là đế mà ko mở mồm đc thì cũng bye bye	text	[]	f	\N	2026-05-02 16:07:45.68	\N	2026-05-02 16:07:46.147
028fdf46-f1a5-4e82-a6cd-ce47b1f281fc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784803301766	contact	386507739282916698	Tuấn Peodethuong	{"id":30809,"catId":10961,"type":3}	sticker	[]	f	\N	2026-05-02 16:07:51.39	\N	2026-05-02 16:07:51.609
b63638e5-88da-4aa6-9c43-8462b210e99f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784804154341	contact	1453308858166125100	Phú Nguyễn	{"title":"","description":"","href":"https://photo-stal-3.zdn.vn/gr/jpg/b76234ac6733a66dff22/211260925237182644.jpg","thumb":"https://photo-stal-3.zdn.vn/gr/jpg/b76234ac6733a66dff22/211260925237182644.jpg","childnumber":0,"action":"","params":"{\\"width\\":2460,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-3.zdn.vn\\\\/gr\\\\/jpg\\\\/b76234ac6733a66dff22\\\\/211260925237182644.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777738098670,\\"id_in_group\\":1,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000007851\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 16:08:19.266	\N	2026-05-02 16:08:19.64
14b1cdc6-ca39-438d-afa3-5c0bd0e2bfc1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784804154537	contact	1453308858166125100	Phú Nguyễn	{"title":"","description":"","href":"https://photo-stal-37.zdn.vn/gr/jpg/61caf615a58a64d43d9b/4221256544153036868.jpg","thumb":"https://photo-stal-37.zdn.vn/gr/jpg/61caf615a58a64d43d9b/4221256544153036868.jpg","childnumber":0,"action":"","params":"{\\"width\\":2460,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-37.zdn.vn\\\\/gr\\\\/jpg\\\\/61caf615a58a64d43d9b\\\\/4221256544153036868.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777738098670,\\"id_in_group\\":0,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000007850\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 16:08:19.216	\N	2026-05-02 16:08:19.67
c15a6165-dfb0-432e-be5d-92908526c499	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784804531673	contact	386507739282916698	Tuấn Peodethuong	Cấm chat này đã bị cầm đến mức kể cả  lên làm r4 r5 cũng ko ghim đc chưa	text	[]	f	\N	2026-05-02 16:08:31.541	\N	2026-05-02 16:08:31.827
12ef9ea6-3310-42ac-8b60-552f3bca0210	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784804560150	contact	1453308858166125100	Phú Nguyễn	7/11/2 def 569 :)	text	[]	f	\N	2026-05-02 16:08:32.45	\N	2026-05-02 16:08:32.577
de16816a-09b0-4634-afd2-7fbafc1b1afb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784805073222	contact	386507739282916698	Tuấn Peodethuong	Hay vẫn xài ghim pin để thay chat	text	[]	f	\N	2026-05-02 16:08:49.33	\N	2026-05-02 16:08:49.646
5c3f5048-1151-4f08-bb72-f0e085805bdc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784805243444	contact	3874537684008431042	Trang Thành Lộc	{"title":"","description":"","href":"https://photo-stal-20.zdn.vn/gr/jpg/195a6bbc9a2c5b72023d/1736839623870036428.jpg","thumb":"https://photo-stal-20.zdn.vn/gr/jpg/195a6bbc9a2c5b72023d/1736839623870036428.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-20.zdn.vn\\\\/gr\\\\/jpg\\\\/195a6bbc9a2c5b72023d\\\\/1736839623870036428.jpg\\",\\"width\\":2778,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-02 16:08:54.901	\N	2026-05-02 16:08:55.277
5c5931b4-14ee-4651-8ef9-c439a221631a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784805671328	contact	3874537684008431042	Trang Thành Lộc	Acc 600m out được được 7 cái zero	text	[]	f	\N	2026-05-02 16:09:08.988	\N	2026-05-02 16:09:09.299
baa3844a-a418-43fd-940f-4b83e00321d2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784806444007	contact	3874537684008431042	Trang Thành Lộc	Offline mà trâu vl	text	[]	f	\N	2026-05-02 16:09:34.551	\N	2026-05-02 16:09:34.793
533adfc1-263b-41a6-9603-021be29052da	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784807047096	contact	4881617662073102521	Nguyễn Minh Tuan	Build lên 1b3, online def phê ấy chứ	text	[]	f	\N	2026-05-02 16:09:54.656	\N	2026-05-02 16:09:55.069
5d07f62e-181e-42b6-8a73-00a0e885f8af	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784808947953	contact	3874537684008431042	Trang Thành Lộc	Xác 130m	text	[]	f	\N	2026-05-02 16:10:58.383	\N	2026-05-02 16:10:58.595
80b4c425-0a7c-4a82-a0ba-5311cfc1216e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784809043069	contact	3874537684008431042	Trang Thành Lộc	:~ :~	text	[]	f	\N	2026-05-02 16:11:01.582	\N	2026-05-02 16:11:01.735
5b01c7bc-05bc-4de3-bbdf-1d2ad27798e3	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788343814816	contact	810978846930818886	Larry Nguyễn Hà	phía google app có thông tin gì k e	text	[]	f	\N	2026-05-04 02:50:07.067	\N	2026-05-04 02:50:08.514
7e167639-f1fd-4cb5-969b-d14aa275d4cd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788345406371	contact	3874537684008431042	Trang Thành Lộc	Game không báo hả ae chơi game bị rally toàn để người khác gọi mới biết 🤧	text	[]	f	\N	2026-05-04 02:50:27.188	\N	2026-05-04 02:50:27.829
5f130bb6-9937-42b4-a578-ffaae2ca1746	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788353623020	contact	4579632439414729865	Tungthanh	@Trang Thành Lộc đen thôi đỏ vẫn thế 😌	text	[]	f	\N	2026-05-04 02:52:11.558	\N	2026-05-04 02:52:12.245
5f48326f-e0f0-42b7-943c-b4a67498408a	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788357734821	contact	810978846930818886	Larry Nguyễn Hà	G-039850 là mã xác minh Google của bạn. Đừng chia sẻ với bất kỳ ai.	text	[]	f	\N	2026-05-04 02:53:03.985	\N	2026-05-04 02:53:04.258
60337351-d58b-473a-8508-b5f98adc4e8a	b800d881-2d06-4a3b-bf2b-05fb95d86fb9	7788365473816	contact	6333022014931839460	Đại Thắng	{"title":"","description":"","href":"https://photo-stal-21.zdn.vn/gr/jpg/dd90c4e03a4efb10a25f/432066326889096914.jpg","thumb":"https://photo-stal-21.zdn.vn/gr/jpg/dd90c4e03a4efb10a25f/432066326889096914.jpg","childnumber":0,"action":"","params":"{\\"height\\":1486,\\"thumb_width\\":323,\\"thumb_height\\":448,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-21.zdn.vn\\\\/gr\\\\/jpg\\\\/dd90c4e03a4efb10a25f\\\\/432066326889096914.jpg\\",\\"width\\":1070,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-04 02:54:42.35	\N	2026-05-04 02:54:42.746
f7bcb29b-63d8-4df9-9350-cde8fd7491a0	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788589168638	contact	810978846930818886	Larry Nguyễn Hà	{"title":"","description":"","href":"https://f19-zpc.zdn.vn/2884110435942011729/ce00511df910784e2101.jpg","thumb":"https://f19-zpc.zdn.vn/2884110435942011729/ce00511df910784e2101.jpg","childnumber":0,"action":"","params":"{\\"sendSource\\":302,\\"rawUrl\\":\\"https:\\\\/\\\\/f19-zpc.zdn.vn\\\\/2884110435942011729\\\\/ce00511df910784e2101.jpg\\",\\"is_original\\":1,\\"width\\":2048,\\"hd\\":\\"https:\\\\/\\\\/f19-zpc.zdn.vn\\\\/2884110435942011729\\\\/ce00511df910784e2101.jpg\\",\\"hdSize\\":120572,\\"height\\":2048}","type":""}	image	[]	f	\N	2026-05-04 03:45:31.542	\N	2026-05-04 03:45:31.772
6a34d532-ecc1-47ad-823d-b2b9cfb47be3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789078246281	contact	8911995138211367850	Đăng	Nghe đâu máy xách tay có mis tb á	text	[]	f	\N	2026-05-04 05:59:45.953	\N	2026-05-04 05:59:46.22
dc6efdf3-bec7-4ddc-8490-68c6fb4d67cf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789078469057	contact	8911995138211367850	Đăng	Ko bt game có bị ko	text	[]	f	\N	2026-05-04 05:59:51.261	\N	2026-05-04 05:59:51.513
9e0c1870-a607-453a-a3c3-df38bef7b4cd	b800d881-2d06-4a3b-bf2b-05fb95d86fb9	7788365450128	contact	6333022014931839460	Đại Thắng	📢 [TUYỂN DỤNG GẤP] - SHINHAN FINANCE\n\n🎯 CẦN TUYỂN GẤP 5 NHÂN VIÊN KINH DOANH\n\n📌 Mô tả công việc:\n • Tư vấn các gói vay tín chấp tiêu dùng cho khách hàng cá nhân.\n • Chăm sóc khách hàng trước và sau khi giải ngân.\n • Không yêu cầu kinh nghiệm – Được đào tạo bài bản.\n\n💰 Thu nhập hấp dẫn:\n • Lương cơ bản + hoa hồng + thưởng năng suất.\n • Thu nhập trung bình từ 10–20 triệu/tháng, không giới hạn mức trần!\n\n🕘 Thời gian làm việc:\n • Giờ hành chính (T2 - T6), T7 làm nữa buổi nghỉ CN.\n • Môi trường chuyên nghiệp – cơ hội thăng tiến rõ ràng.\n\n📍 Làm việc tại: Văn phòng Shinhan chi nhánh \nToà nhà pegasus tầng 14 biên hoà đồng nai.\n\n✅ Yêu cầu:\n • Nam/Nữ từ 20–35 tuổi.\n • Tốt nghiệp THPT trở lên.\n • Nhiệt huyết, siêng năng, đam mê kinh doanh.\n\n📲 Liên hệ/Zalo: 0966606055\n\n📩 Gửi CV về: ledaithang1105@gmail.com\n\n🧡 Gia nhập đội ngũ Shinhan – Nơi bạn xây dựng sự nghiệp vững chắc từ hôm nay!	text	[]	f	\N	2026-05-04 02:54:42.034	\N	2026-05-04 02:54:42.81
1cfa53dc-3a98-4610-aac1-e461b6458315	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788377073882	contact	810978846930818886	Larry Nguyễn Hà	vậy kiểm tra lại app	text	[]	f	\N	2026-05-04 02:57:09.492	\N	2026-05-04 02:57:09.577
67783451-117b-475b-8d41-396deb84068f	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788377456442	contact	810978846930818886	Larry Nguyễn Hà	rồi đưa lên đi e	text	[]	f	\N	2026-05-04 02:57:14.226	\N	2026-05-04 02:57:14.267
6f724384-e1a3-4056-b5ed-ab3fc674f324	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788378475576	contact	810978846930818886	Larry Nguyễn Hà	thay logo	text	[]	f	\N	2026-05-04 02:57:27.108	\N	2026-05-04 02:57:27.206
1634d390-b50b-4a8d-9639-67f601990d2f	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788378909412	contact	810978846930818886	Larry Nguyễn Hà	thông tin chính xác	text	[]	f	\N	2026-05-04 02:57:32.624	\N	2026-05-04 02:57:32.668
27a9d947-8994-488c-9bd5-ef892f0e7676	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788380432015	contact	810978846930818886	Larry Nguyễn Hà	thông tin điều khoản sử dụng và bảo mật	text	[]	f	\N	2026-05-04 02:57:51.859	\N	2026-05-04 02:57:51.951
726bdd3d-5a41-40a5-9b0a-77b952d64b28	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788381469323	contact	810978846930818886	Larry Nguyễn Hà	ưu tiên app	text	[]	f	\N	2026-05-04 02:58:05.159	\N	2026-05-04 02:58:05.406
4e39df4a-a72b-4102-bf04-2805d0392068	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788382652302	contact	810978846930818886	Larry Nguyễn Hà	để xong việc đó đưa vào sử dụng	text	[]	f	\N	2026-05-04 02:58:20.118	\N	2026-05-04 02:58:20.18
0b9a6118-e3fc-40c7-a52f-3f897cfb34c0	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788384854501	contact	810978846930818886	Larry Nguyễn Hà	chỗ máy MAC để test	text	[]	f	\N	2026-05-04 02:58:47.958	\N	2026-05-04 02:58:48.082
882d94fa-23b5-4d8b-b225-6b2f2d555df3	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788385607688	contact	810978846930818886	Larry Nguyễn Hà	thì có cần dùng lâu k e	text	[]	f	\N	2026-05-04 02:58:57.449	\N	2026-05-04 02:58:57.495
14eb3a17-65ff-465d-bc0d-eaffa2365376	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788386223296	contact	810978846930818886	Larry Nguyễn Hà	tron công ty có chị TÚ dùng MÁC	text	[]	f	\N	2026-05-04 02:59:05.332	\N	2026-05-04 02:59:05.37
220f11cf-ef02-4c53-b623-82bf8fee508e	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788412170223	contact	810978846930818886	Larry Nguyễn Hà	làm trước bản Android đi e	text	[]	f	\N	2026-05-04 03:04:28.361	\N	2026-05-04 03:04:28.629
a6c090ab-f350-4a26-ad3b-555720f287b8	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788412758870	contact	810978846930818886	Larry Nguyễn Hà	xong a u7a9 ipad	text	[]	f	\N	2026-05-04 03:04:35.66	\N	2026-05-04 03:04:35.715
f41b2382-1fff-4fc7-bdb7-5ef91e754a4b	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788413348079	contact	810978846930818886	Larry Nguyễn Hà	anh đưa IPAD	text	[]	f	\N	2026-05-04 03:04:42.86	\N	2026-05-04 03:04:42.898
0b249a2c-fe67-484b-9614-5026b3f45749	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788414097901	contact	810978846930818886	Larry Nguyễn Hà	dùng ipad làm cũng dc	text	[]	f	\N	2026-05-04 03:04:52.243	\N	2026-05-04 03:04:52.399
6d9049a1-a8a5-47c0-ae3a-b805fff8e559	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788417812784	contact	810978846930818886	Larry Nguyễn Hà	{"title":"","description":"","href":"https://f19-zpc.zdn.vn/607824758523179319/e1da7957f15a7004294b.jpg","thumb":"https://f19-zpc.zdn.vn/607824758523179319/e1da7957f15a7004294b.jpg","childnumber":0,"action":"","params":"{\\"rawUrl\\":\\"https:\\\\/\\\\/f19-zpc.zdn.vn\\\\/607824758523179319\\\\/e1da7957f15a7004294b.jpg\\",\\"is_original\\":1,\\"width\\":65,\\"hd\\":\\"https:\\\\/\\\\/f19-zpc.zdn.vn\\\\/607824758523179319\\\\/e1da7957f15a7004294b.jpg\\",\\"hdSize\\":1225,\\"height\\":56}","type":""}	image	[]	f	\N	2026-05-04 03:05:38.8	\N	2026-05-04 03:05:38.894
29e2392f-f00f-4716-b630-69cebc8177a1	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788419079510	contact	810978846930818886	Larry Nguyễn Hà	thay icon cho app thành logo công  ty	text	[]	f	\N	2026-05-04 03:05:56.061	\N	2026-05-04 03:05:56.161
6f00ae5f-8a76-4bbd-ba2a-0730f76a43b9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788476305317	contact	2351865102237605540	Trần Minh Quang	@Trang Thành Lộc hahaa	text	[]	f	\N	2026-05-04 03:19:13.735	\N	2026-05-04 03:19:14.163
9f244249-c2eb-4206-a8d9-30b9a90156cb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788480130549	contact	7387240757415509891	Trần Thoại	Uh bị vụ này nhiều lần vch	text	[]	f	\N	2026-05-04 03:20:07.407	\N	2026-05-04 03:20:07.964
75244133-ea43-4dea-9357-73810350f586	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788481512394	contact	7387240757415509891	Trần Thoại	May mà 2 acc trong 1 bang nên 1 trong 2 cái lord nó lên tb	text	[]	f	\N	2026-05-04 03:20:26.677	\N	2026-05-04 03:20:26.96
a9591622-cf47-4af7-872a-dae3cb0c6fb6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788489005530	contact	2351865102237605540	Trần Minh Quang	T bị suốt	text	[]	f	\N	2026-05-04 03:22:11.422	\N	2026-05-04 03:22:11.709
eb2a158b-e35c-4d50-b427-616569711cb5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788492940650	contact	2191769504086747501	Văn Minh	Mình chơi ở máy android thì bị chậm thông báo, chuyển qua iphone thì nó báo nhanh	text	[]	f	\N	2026-05-04 03:23:06.486	\N	2026-05-04 03:23:07.008
f2478e95-6916-4b44-adc9-fc43edcdf1c4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788493073711	contact	2191769504086747501	Văn Minh	{"id":50627,"catId":12658,"type":3}	sticker	[]	f	\N	2026-05-04 03:23:08.336	\N	2026-05-04 03:23:08.501
4a7684fc-e9bf-4468-bc12-b860cd29fb32	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788498035708	contact	262937886851184801	Thu Phan	@Trang Thành Lộc  83m cg về	text	[]	f	\N	2026-05-04 03:24:17.767	\N	2026-05-04 03:24:18.37
5fc6f423-22c6-4e0e-898d-184224310df4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788498466797	contact	262937886851184801	Thu Phan	Trap t1 àh	text	[]	f	\N	2026-05-04 03:24:23.82	\N	2026-05-04 03:24:24.12
fa08afed-fd49-478c-b75f-e9ddd56e728d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788509358923	contact	3874537684008431042	Trang Thành Lộc	@Thu Phan tí đấm thử về là biết mà 🙄	text	[]	f	\N	2026-05-04 03:26:55.992	\N	2026-05-04 03:26:56.4
8c033890-dc7f-4712-b11e-fe55dda9a330	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789076948778	contact	8911995138211367850	Đăng	@Võ Vũ Nam 武武南 dùng dt gì	text	[]	f	\N	2026-05-04 05:59:14.709	\N	2026-05-04 05:59:15.165
e71021dd-93c4-4d32-a907-9e67aba44cb0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789083262224	contact	7403855231521506488	Ng Quốc Khánh	ái nhiệm vụ mua gói đặc biệt là mua gói nào cũng được à ae . hay phải từ gói bao nhiêu trở đi vậy ae	text	[]	f	\N	2026-05-04 06:01:44.797	\N	2026-05-04 06:01:45.226
7dbaa554-6d79-4833-abc2-4b8496522602	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788593576879	contact	810978846930818886	Larry Nguyễn Hà	{"title":"","description":"","href":"https://f20-zpc.zdn.vn/6122478887197000926/a8cf6dfec4f345ad1ce2.jpg","thumb":"https://f20-zpc.zdn.vn/6122478887197000926/a8cf6dfec4f345ad1ce2.jpg","childnumber":0,"action":"","params":"{\\"sendSource\\":302,\\"rawUrl\\":\\"https:\\\\/\\\\/f20-zpc.zdn.vn\\\\/6122478887197000926\\\\/a8cf6dfec4f345ad1ce2.jpg\\",\\"is_original\\":1,\\"width\\":2048,\\"hd\\":\\"https:\\\\/\\\\/f20-zpc.zdn.vn\\\\/6122478887197000926\\\\/a8cf6dfec4f345ad1ce2.jpg\\",\\"hdSize\\":119768,\\"height\\":2048}","type":""}	image	[]	f	\N	2026-05-04 03:46:33.052	\N	2026-05-04 03:46:33.109
efb61f73-b331-43f6-aeca-dee12e3c82a2	80aeb1ef-971d-47eb-87de-8ad84a21a04b	7788594121986	contact	810978846930818886	Larry Nguyễn Hà	DÙNG CÁI NÀY NHA E	text	[]	f	\N	2026-05-04 03:46:40.669	\N	2026-05-04 03:46:40.708
036ca69c-d7ff-4efc-a214-3e5d15a4ffa6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788803564013	contact	4835990816698319387	Minh Nguyễn	@Trang Thành Lộc game chờ tới rally thứ 3 mới thông báo	text	[]	f	\N	2026-05-04 04:35:32.706	\N	2026-05-04 04:35:33.17
0c5d9079-8adb-4d6e-947a-8a8fbd72a8b8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788827115299	contact	7496477430098754831	Kenny Đại	@Minh Nguyễn mạng yếu	text	[]	f	\N	2026-05-04 04:41:25.174	\N	2026-05-04 04:41:25.708
02b6882e-8def-42c9-a987-79e8afd725cc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788830159627	contact	645466130707505394	Lan Hân	{"title":"","description":"","href":"https://photo-stal-17.zdn.vn/gr/f62e172f9730566e0f21/476382881014840016.jpg","thumb":"","childnumber":0,"action":"","params":"{\\"thumb_height\\":320,\\"contentId\\":\\"C9B800BE-A23D-4792-800F-DD5FE8FCD0540\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":320,\\"height\\":320,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-04 04:42:10.941	\N	2026-05-04 04:42:11.349
80627468-a6ac-431a-9572-7758260eac21	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788831180866	contact	3391365375455109655	Huy	@Minh Nguyễn dùng Android nó hay d	text	[]	f	\N	2026-05-04 04:42:26.262	\N	2026-05-04 04:42:26.627
772e11cd-a0f7-4f33-a9e6-4bcdd76eb039	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788831501437	contact	4835990816698319387	Minh Nguyễn	Mạng wifi nhà	text	[]	f	\N	2026-05-04 04:42:31.117	\N	2026-05-04 04:42:31.475
676f4d9a-2f52-4035-ae09-d0a027981db2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788831559900	contact	3391365375455109655	Huy	Đen thì chịu :)))	text	[]	f	\N	2026-05-04 04:42:32.008	\N	2026-05-04 04:42:32.16
a0ce3b4a-869a-4712-96c9-6a439561b791	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788849081950	contact	3874537684008431042	Trang Thành Lộc	Má sáng giờ ăn 4 cái rally toàn không online được 🌝	text	[]	f	\N	2026-05-04 04:46:55.982	\N	2026-05-04 04:46:56.424
4c4eb60c-f4da-489c-9f94-d7b1d5993e05	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788851716939	contact	4835990816698319387	Minh Nguyễn	Off sâu thì đóng khiên đi	text	[]	f	\N	2026-05-04 04:47:35.9	\N	2026-05-04 04:47:36.347
405457c7-3941-4539-9838-dc8e433af2f3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788853485897	contact	3874537684008431042	Trang Thành Lộc	🥲 game không thông báo ấy	text	[]	f	\N	2026-05-04 04:48:02.619	\N	2026-05-04 04:48:02.899
99d1ea58-c0ea-4fa9-aeef-3fcd50a0beac	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788854491371	contact	3874537684008431042	Trang Thành Lộc	Đang chơi liên quân luôn mà	text	[]	f	\N	2026-05-04 04:48:17.83	\N	2026-05-04 04:48:18.101
c40dfab8-6700-4f7d-a366-8f9a6a8d8d4a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788892592050	contact	2320230736563113524	Lương Minh Khoa	Bác dùng 5g vịt teo đi	text	[]	f	\N	2026-05-04 04:58:00.177	\N	2026-05-04 04:58:00.639
4980f41e-f579-4adf-9c9c-aa642eb224b6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788900791077	contact	4881617662073102521	Nguyễn Minh Tuan	@Minh Nguyễn game cập nhật cái là miss liên tụcf	text	[]	f	\N	2026-05-04 05:00:08.651	\N	2026-05-04 05:00:09.057
1bcfe233-e92f-4233-93d5-4dbf7280a44c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788901311277	contact	4881617662073102521	Nguyễn Minh Tuan	rớt khiên zero r,vô game mới báo	text	[]	f	\N	2026-05-04 05:00:16.925	\N	2026-05-04 05:00:17.142
074a9e63-c847-40a5-a39b-31dc745e20f2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788904080614	contact	2320230736563113524	Lương Minh Khoa	Nói chung là igg rất để ý đến sự cân bằng của game.ai cũng có lúc zero	text	[]	f	\N	2026-05-04 05:01:00.724	\N	2026-05-04 05:01:00.98
fc51d460-b3bd-4d0e-bf65-301e71e034e2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788912626203	contact	4064673509712448879	Tất Đại	Mé trong túi toàn khiên 1d 3d.mà bật 1d canh h vô thay thế nào vô bị cháy xem lịch sử khiên nó hiện khiên 12h vãi thật	text	[]	f	\N	2026-05-04 05:03:20.209	\N	2026-05-04 05:03:20.65
100e41db-a0b5-4619-bf80-d7622108bf03	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788915751186	contact	2320230736563113524	Lương Minh Khoa	Em cũng bị 1 lần thế.đang mê ngủ.	text	[]	f	\N	2026-05-04 05:04:12.33	\N	2026-05-04 05:04:12.782
159ca389-2ed4-4581-9629-ff56b8fe9b24	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788917705688	contact	2320230736563113524	Lương Minh Khoa	Nhấp nhầm.tưởng khiên. Hoá ra dùng đồ gì khác	text	[]	f	\N	2026-05-04 05:04:45.384	\N	2026-05-04 05:04:45.685
4636d47a-c5ff-49fd-be94-4b7ee1ec36b5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788962776048	contact	3874537684008431042	Trang Thành Lộc	Không bị ai đấm thì báo 🤧	text	[]	f	\N	2026-05-04 05:18:21.043	\N	2026-05-04 05:18:21.488
da6f3694-ab06-4011-a483-ec8a27663f29	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788966463088	contact	4064673509712448879	Tất Đại	Bị zéo thì im re	text	[]	f	\N	2026-05-04 05:19:29.965	\N	2026-05-04 05:19:30.398
f4c0bdde-80f8-4f32-9ce3-16c6ad3a871e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788989661736	contact	2936642097806243014	Mthuan	Alo mấy chế ơi	text	[]	f	\N	2026-05-04 05:26:53.962	\N	2026-05-04 05:26:54.346
037fde2a-80f0-4412-817c-86a55552792c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7788990398737	contact	2936642097806243014	Mthuan	Cái gf h mình săn quái 5 có tính của cải huyền thoại ko đó	text	[]	f	\N	2026-05-04 05:27:08.46	\N	2026-05-04 05:27:08.689
b7cc461a-6c6e-441b-8145-a07d87590a0d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789018637190	contact	386507739282916698	Tuấn Peodethuong	@Mthuan nó ko tính săn hay ko. Nó tính nhận đc hộp huyền thoại	text	[]	f	\N	2026-05-04 05:36:46.14	\N	2026-05-04 05:36:46.671
e3e7c597-f84c-4e9a-a6d1-b0ebeef7d02f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789020082829	contact	386507739282916698	Tuấn Peodethuong	Miễn là bạn nhận đc 1 hộp vàng, là nó tính 1 của cải	text	[]	f	\N	2026-05-04 05:37:17.15	\N	2026-05-04 05:37:17.427
4bb76568-bf4e-4ac2-911b-a303c889cc07	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789060992774	contact	585801465063846950	Võ Vũ Nam 武武南	Vãi, tắt đt cái méo tb	text	[]	f	\N	2026-05-04 05:52:50.996	\N	2026-05-04 05:52:51.518
f21582f6-758b-40cf-8ffe-143e4e4c3f8c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789061456278	contact	585801465063846950	Võ Vũ Nam 武武南	Bật lên k thấy tắt màn hình cái	text	[]	f	\N	2026-05-04 05:53:02.06	\N	2026-05-04 05:53:02.324
65e84bc2-4730-4ab2-9726-7aed8cd4b4d6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789061759046	contact	585801465063846950	Võ Vũ Nam 武武南	Nhảy tb lia lịa	text	[]	f	\N	2026-05-04 05:53:09.34	\N	2026-05-04 05:53:09.554
74387c23-e8b4-4b47-a532-e96809078d00	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789062440164	contact	585801465063846950	Võ Vũ Nam 武武南	Này mà acc trap nó tb là zero mẹ r	text	[]	f	\N	2026-05-04 05:53:25.685	\N	2026-05-04 05:53:25.886
b9545fef-ff5a-4fb1-a10d-c191274fd89c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789071601002	contact	7387240757415509891	Trần Thoại	{"id":45341,"catId":11901,"type":3}	sticker	[]	f	\N	2026-05-04 05:57:05.67	\N	2026-05-04 05:57:06.045
77a7dacd-f3d7-4d5a-a50a-ccc2950a073a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789099486031	contact	2760596411766142024	Nguyễn Đạt	@Ng Quốc Khánh từ 99-9999 có hộp là dc	text	[]	f	\N	2026-05-04 06:07:57.437	\N	2026-05-04 06:07:57.862
8f2209ae-2cec-46da-bd02-1783d22f5972	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789099602778	contact	2760596411766142024	Nguyễn Đạt	{"id":45356,"catId":11901,"type":3}	sticker	[]	f	\N	2026-05-04 06:08:00.091	\N	2026-05-04 06:08:00.229
0faa5a0b-7965-4536-9b79-d79ac955a776	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789100261165	contact	7403855231521506488	Ng Quốc Khánh	@Nguyễn Đạt thank bác nhé	text	[]	f	\N	2026-05-04 06:08:15.285	\N	2026-05-04 06:08:15.66
6936e137-0c9c-4d34-8af7-68986f3f8f70	16d891d4-a7d7-4236-803e-d0e4dcd931dd	7789118254928	contact	6212974401618113343	Thanh Ngọc	Thiếu bất kỳ thông tin nào khoa không tiếp nhận, cô đã ghi rõ rồi, vẫn còn có bạn điền sai/thiếu. \nCác bạn đều năm cuối cả rồi, phải xem đơn và điền đúng thông tin đi chứ.	text	[]	f	\N	2026-05-04 06:14:57.109	\N	2026-05-04 06:14:57.697
6e6c9108-d153-4dba-ac64-1fc6b2d516c2	16d891d4-a7d7-4236-803e-d0e4dcd931dd	7789118315138	contact	6212974401618113343	Thanh Ngọc	{"title":"","description":"","href":"https://photo-stal-23.zdn.vn/gr/jpg/713fdc8e6024a17af835/3285979661813305592.jpg","thumb":"https://photo-stal-23.zdn.vn/gr/jpg/713fdc8e6024a17af835/3285979661813305592.jpg","childnumber":0,"action":"","params":"{\\"width\\":829,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-23.zdn.vn\\\\/gr\\\\/jpg\\\\/713fdc8e6024a17af835\\\\/3285979661813305592.jpg\\",\\"height\\":802}","type":""}	image	[]	f	\N	2026-05-04 06:14:58.359	\N	2026-05-04 06:14:58.449
dd5d5e4c-93fc-40b9-93af-ac33117a7485	33da79ac-da04-4b3e-a667-48f8eca973c5	7789157241868	contact	2919054366868027269	Quách Thị Bích Nhường	{"title":"057018704 - Khoa luan tot nghiep ky su (21DTH1)-24-04-2026-034122_NhapDiemTK_DanhSachSinhVienDuThiCuoiKy.pdf","description":"","href":"https://fg43.dlfl.vn/70d50c97fc425c1c0553/6811638394302941572","thumb":"","childnumber":0,"action":"","params":"{\\"fileSize\\":\\"108825\\", \\"checksum\\":\\"aab07eb68e8b06eaed3e03b4a8464b77\\", \\"checksumSha\\":\\"null\\", \\"fileExt\\":\\"pdf\\", \\"fdata\\":\\"{}\\", \\"fType\\":1}","type":""}	file	[]	f	\N	2026-05-04 06:28:48.6	\N	2026-05-04 06:28:49.007
804b3c64-de2d-47e7-8acf-4360448219d1	33da79ac-da04-4b3e-a667-48f8eca973c5	7789162676068	contact	2919054366868027269	Quách Thị Bích Nhường	@All Chào các bạn, Cô gửi các bạn bảng điểm khóa luận tốt nghiệp nhé. Đến 15g30 cô sẽ nhập điểm lên hệ thống để các bạn xét tốt nghiệp nhé.\nCác bạn kiểm tra thật kỹ nhé	text	[]	f	\N	2026-05-04 06:30:38.64	\N	2026-05-04 06:30:38.877
ba304404-61e7-4f19-a0d7-194fce50775a	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789167112033	contact	3429230737531381136	Nguyễn Nhật Tân	@All 8,6 điểm vl	text	[]	f	\N	2026-05-04 06:32:06.95	\N	2026-05-04 06:32:07.305
7d66d471-10fa-447e-b589-5883ef5abe45	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789167338729	contact	3429230737531381136	Nguyễn Nhật Tân	Ngon mấy em ơi	text	[]	f	\N	2026-05-04 06:32:11.464	\N	2026-05-04 06:32:11.695
7d254e69-b0fc-49de-b66a-407404ec6612	33da79ac-da04-4b3e-a667-48f8eca973c5	7789167797958	contact	2919054366868027269	Quách Thị Bích Nhường	@All Có chút nhầm cô gửi lại sua nhé	text	[]	f	\N	2026-05-04 06:32:20.683	\N	2026-05-04 06:32:20.867
9af92ce4-0f30-4bce-9c97-7aacab4806a2	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789168248156	contact	3429230737531381136	Nguyễn Nhật Tân	Ơ đm	text	[]	f	\N	2026-05-04 06:32:29.461	\N	2026-05-04 06:32:29.669
f6088844-1bcb-43f8-bdb0-2fa8c3439f22	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789168449422	contact	3429230737531381136	Nguyễn Nhật Tân	Sao lại nhầm	text	[]	f	\N	2026-05-04 06:32:33.473	\N	2026-05-04 06:32:33.57
7a7d0d6c-1dcc-43be-b822-7bd50367f4aa	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789168452963	contact	3115939052991645753	Phạm Huy Hoàng	Cứt	text	[]	f	\N	2026-05-04 06:32:33.505	\N	2026-05-04 06:32:33.736
f7b29039-4375-48e3-84a5-b52248dd87ba	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789168701439	contact	3115939052991645753	Phạm Huy Hoàng	Cô sửa ròi	text	[]	f	\N	2026-05-04 06:32:38.442	\N	2026-05-04 06:32:38.626
3c41d9ab-6222-4b1e-a1cb-cc7111547f3b	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789168802850	contact	3115939052991645753	Phạm Huy Hoàng	Huhu	text	[]	f	\N	2026-05-04 06:32:40.415	\N	2026-05-04 06:32:40.523
58f71cbb-d5d2-407f-ad50-ac139af07356	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789168834739	contact	3429230737531381136	Nguyễn Nhật Tân	Đúng rồi đm bà nhường	text	[]	f	\N	2026-05-04 06:32:41.023	\N	2026-05-04 06:32:41.143
38474b23-bd3c-4953-bcb7-a78b624009c8	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789168850849	contact	3115939052991645753	Phạm Huy Hoàng	{"id":2,"catId":0,"type":2}	sticker	[]	f	\N	2026-05-04 06:32:41.329	\N	2026-05-04 06:32:41.442
f7533522-935b-4289-881c-da4fa47f7c4e	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789169980671	contact	3429230737531381136	Nguyễn Nhật Tân	Clm	text	[]	f	\N	2026-05-04 06:33:03.655	\N	2026-05-04 06:33:03.837
555ac685-1643-4680-b48a-9e178d3980da	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789172642881	contact	3115939052991645753	Phạm Huy Hoàng	Chắc nhầm tên hoặc gì thôi	text	[]	f	\N	2026-05-04 06:33:55.95	\N	2026-05-04 06:33:56.238
63680d82-7782-404c-933d-3411c8e6b5ee	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789173082457	contact	3115939052991645753	Phạm Huy Hoàng	Chứ mới gửi đã thu hồi rồi mà	text	[]	f	\N	2026-05-04 06:34:04.509	\N	2026-05-04 06:34:04.685
fc32af55-5319-4f23-978e-35865cf77fa9	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789173743837	contact	3429230737531381136	Nguyễn Nhật Tân	Nhầm file sao m	text	[]	f	\N	2026-05-04 06:34:17.363	\N	2026-05-04 06:34:17.585
36886116-8467-4db3-9c33-158eee2f5051	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789174326471	contact	3115939052991645753	Phạm Huy Hoàng	@@	text	[]	f	\N	2026-05-04 06:34:28.768	\N	2026-05-04 06:34:28.956
822145e1-bbb7-4d63-b4a5-5f560227cf89	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789174894872	contact	3115939052991645753	Phạm Huy Hoàng	Nãy m xem là tên nhóm hả	text	[]	f	\N	2026-05-04 06:34:39.754	\N	2026-05-04 06:34:39.965
e740f77a-5c91-403e-823d-e294660966d9	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789174999232	contact	3429230737531381136	Nguyễn Nhật Tân	File đó chưa final:))))	text	[]	f	\N	2026-05-04 06:34:41.775	\N	2026-05-04 06:34:41.888
5bc77439-408c-4efc-b23b-e7f4351ca6b1	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789175633783	contact	3115939052991645753	Phạm Huy Hoàng	Niệm phật	text	[]	f	\N	2026-05-04 06:34:54.114	\N	2026-05-04 06:34:54.367
a46a45d9-e3b0-47fd-a63a-8c4aca26ca1e	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789175796248	contact	3115939052991645753	Phạm Huy Hoàng	Nam mô	text	[]	f	\N	2026-05-04 06:34:57.261	\N	2026-05-04 06:34:57.338
2173641a-f845-4e7c-baff-ece44dcf30be	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789176088071	contact	3429230737531381136	Nguyễn Nhật Tân	Điểm từng đứa	text	[]	f	\N	2026-05-04 06:35:02.943	\N	2026-05-04 06:35:03.11
0fefa126-e964-4863-b4f5-a4b39e50c9e1	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789176684289	contact	3429230737531381136	Nguyễn Nhật Tân	Má minh 8,6 lun	text	[]	f	\N	2026-05-04 06:35:14.401	\N	2026-05-04 06:35:14.614
011cc2ed-53b1-4ea4-91b2-e1bae007a759	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789177388586	contact	3115939052991645753	Phạm Huy Hoàng	À	text	[]	f	\N	2026-05-04 06:35:27.9	\N	2026-05-04 06:35:28.101
134eef79-29f8-4561-a9de-0c2914b7b702	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789177729244	contact	3115939052991645753	Phạm Huy Hoàng	Thg minh làm gì làm đồ án	text	[]	f	\N	2026-05-04 06:35:34.407	\N	2026-05-04 06:35:34.65
3dec1cf5-de89-40f2-97bf-e68db4e30d72	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789178138699	contact	3115939052991645753	Phạm Huy Hoàng	Vậy là sai r	text	[]	f	\N	2026-05-04 06:35:42.294	\N	2026-05-04 06:35:42.528
1a82dd13-289d-4feb-a8f9-c7a64109a7c7	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789179424099	contact	3429230737531381136	Nguyễn Nhật Tân	@Phạm Huy Hoàng Là sao ba liên qua gì tới mình	text	[]	f	\N	2026-05-04 06:36:06.77	\N	2026-05-04 06:36:07.019
1094d256-79fe-491c-9f7e-9df1476dbbe4	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789182293412	contact	3115939052991645753	Phạm Huy Hoàng	M kêu thg minh 8.6	text	[]	f	\N	2026-05-04 06:37:01.502	\N	2026-05-04 06:37:01.729
d19cf610-6141-442e-98b7-fba056b22f07	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789182904790	contact	3115939052991645753	Phạm Huy Hoàng	Nma thg minh có làm đồ án đâu	text	[]	f	\N	2026-05-04 06:37:13.1	\N	2026-05-04 06:37:13.302
78081030-8c15-4aed-965e-6e5435518a66	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789183304098	contact	3429230737531381136	Nguyễn Nhật Tân	Tụi mình 8,6 hết	text	[]	f	\N	2026-05-04 06:37:20.675	\N	2026-05-04 06:37:20.96
a57f7b44-8d76-434a-9ce3-edfffb1eeec5	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789183988098	contact	3115939052991645753	Phạm Huy Hoàng	:v	text	[]	f	\N	2026-05-04 06:37:33.606	\N	2026-05-04 06:37:33.969
6e079b48-dc45-47c5-a82e-51bce75910f6	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789184049004	contact	3115939052991645753	Phạm Huy Hoàng	Ồ	text	[]	f	\N	2026-05-04 06:37:34.746	\N	2026-05-04 06:37:34.821
d797098d-84b1-4a61-8d73-211498e144ac	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789184143489	contact	3115939052991645753	Phạm Huy Hoàng	Heheh	text	[]	f	\N	2026-05-04 06:37:36.52	\N	2026-05-04 06:37:36.596
61413774-b3d9-48e4-8d36-c6c8fa273691	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789184332243	contact	3115939052991645753	Phạm Huy Hoàng	My bad	text	[]	f	\N	2026-05-04 06:37:40.087	\N	2026-05-04 06:37:40.185
865b1209-36f4-4a5d-a75a-c3c1eb9016c0	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789184814270	contact	3429230737531381136	Nguyễn Nhật Tân	@Phạm Huy Hoàng ngáo à	text	[]	f	\N	2026-05-04 06:37:49.242	\N	2026-05-04 06:37:49.484
62d3bd2a-0bc7-40be-bb14-0423d53a25d4	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789186107778	contact	3429230737531381136	Nguyễn Nhật Tân	Hao hao là tháy ghét rồi	text	[]	f	\N	2026-05-04 06:38:13.625	\N	2026-05-04 06:38:13.893
990b3d7d-97f4-4401-9182-3f204dab4352	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789198611782	contact	585801465063846950	Võ Vũ Nam 武武南	@Đăng redmi bác	text	[]	f	\N	2026-05-04 06:42:04.865	\N	2026-05-04 06:42:05.424
1b576963-2be0-4ba4-ab61-abc5ec8da2f4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789270007062	contact	2320230736563113524	Lương Minh Khoa	@Mthuan  phải bang mình giết chết mới tính	text	[]	f	\N	2026-05-04 07:02:29.252	\N	2026-05-04 07:02:29.726
4b54a1d6-6153-45d3-a10a-166c04fc7c31	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7789275385474	contact	3429230737531381136	Nguyễn Nhật Tân	Hok có đứa 9 lun m	text	[]	f	\N	2026-05-04 07:03:56.372	\N	2026-05-04 07:03:56.751
9ce0f3dd-e474-4443-ab0e-c83538b5f255	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789367910217	contact	2226503885650453985	Nguyễn Thành	Nv q5 ae làm vất vả nhỉ, guild tôi ngày nào cũng 4-5 hộp q5, riêng gf ngày 10 hộp là ít	text	[]	f	\N	2026-05-04 07:28:09.284	\N	2026-05-04 07:28:09.833
b7bb62f9-56af-465f-8f8a-f1c1aea60526	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789369468178	contact	4381049269168369099	Ngọc Hướng	@Nguyễn Thành chắc thuê săn à	text	[]	f	\N	2026-05-04 07:28:33.272	\N	2026-05-04 07:28:33.675
3d78aee4-bdce-4804-81f0-19fc5c32f49e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789369910214	contact	2226503885650453985	Nguyễn Thành	@Ngọc Hướng guild đại đế	text	[]	f	\N	2026-05-04 07:28:39.948	\N	2026-05-04 07:28:40.22
70362159-ab37-4c6b-a859-ba7cd448f613	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789371126361	contact	4381049269168369099	Ngọc Hướng	@Nguyễn Thành lạy bố	text	[]	f	\N	2026-05-04 07:28:58.656	\N	2026-05-04 07:28:58.893
0a2efef7-80e0-4637-b9d6-94ae9d11e190	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789372599030	contact	2226503885650453985	Nguyễn Thành	Nhưng phải chịu khó join lính mới ở đc	text	[]	f	\N	2026-05-04 07:29:21.197	\N	2026-05-04 07:29:21.446
e5a693c8-7763-4539-8559-b6d07147b067	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789377148136	contact	2226503885650453985	Nguyễn Thành	Thưởng top1 300k gem	text	[]	f	\N	2026-05-04 07:30:30.271	\N	2026-05-04 07:30:30.595
53d87c20-269e-4fa1-9679-bef0af3bff3b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789381919133	contact	3011092580170595790	Nguyễn Quang Trường	@Ngọc Hướng khó thậc	text	[]	f	\N	2026-05-04 07:31:42.23	\N	2026-05-04 07:31:42.658
8bf8a965-0254-41bd-9f09-67e295d4d568	16d891d4-a7d7-4236-803e-d0e4dcd931dd	7789478614429	contact	6212974401618113343	Thanh Ngọc	{"title":"@All  Hoạt động tính CTXH\\n1. Sinh viên tham gia lễ ra mắt và ký kết \\"Kết nghĩa trường học - Đồng hành vùng biên\\"\\n- Thời gian: 16h00 - 17h30 ngày 06/5/2026\\n- Địa điểm: Hội trường - Nhà A\\n- Quyền lợi: 4 giờ CTXH\\n- Trang phục: Đồng phục Khoa, quần tây sẫm màu, giày/dép quai hậu\\n- Link đăng ký: https://docs.google.com/spreadsheets/d/1hrrob3ckGALVEBvcuIrEeXRMK9MgTCMS1XCUNi_OE_8/edit?gid=0#gid=0\\n\\n2. Workshop với chủ đề “Sinh viên Trường Đại học Công nghệ Đồng Nai học tập và làm theo tư tưởng, đạo đức, phong cách Hồ Chí Minh” năm học 2025 – 2026\\n- Thời gian: 07h45 – 11h00, Thứ Bảy ngày 09/5/2026\\n- Địa điểm: Hội trường Nhà A\\n- Quyền lợi: 4 giờ CTXH\\n- Trang phục: Đồng phục Khoa, quần tây sẫm màu, giày/dép quai hậu\\n- Số lượng: 180 sinh viên (số lượng phân bổ trong link)\\n- Link đăng ký: https://docs.google.com/spreadsheets/d/1awTssgRN210mKCseFPiLVZSG7vgauUvJ57Kg-zpfk8A/edit?usp=sharing","description":"","href":"","thumb":"","childnumber":0,"action":"rtf","params":"{\\"styles\\":[{\\"start\\":0,\\"len\\":4,\\"st\\":\\"b\\"},{\\"start\\":4,\\"len\\":2,\\"st\\":\\"b\\"},{\\"start\\":6,\\"len\\":19,\\"st\\":\\"f_18,b,c_db342e\\"},{\\"start\\":26,\\"len\\":86,\\"st\\":\\"b\\"},{\\"start\\":113,\\"len\\":13,\\"st\\":\\"b\\"},{\\"start\\":126,\\"len\\":28,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":155,\\"len\\":11,\\"st\\":\\"b\\"},{\\"start\\":166,\\"len\\":19,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":186,\\"len\\":13,\\"st\\":\\"b\\"},{\\"start\\":199,\\"len\\":10,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":210,\\"len\\":14,\\"st\\":\\"b\\"},{\\"start\\":224,\\"len\\":51,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":276,\\"len\\":16,\\"st\\":\\"b\\"},{\\"start\\":394,\\"len\\":150,\\"st\\":\\"b\\"},{\\"start\\":545,\\"len\\":13,\\"st\\":\\"b\\"},{\\"start\\":558,\\"len\\":37,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":596,\\"len\\":12,\\"st\\":\\"b\\"},{\\"start\\":608,\\"len\\":16,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":625,\\"len\\":13,\\"st\\":\\"b\\"},{\\"start\\":638,\\"len\\":10,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":649,\\"len\\":14,\\"st\\":\\"b\\"},{\\"start\\":663,\\"len\\":51,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":715,\\"len\\":12,\\"st\\":\\"b\\"},{\\"start\\":727,\\"len\\":43,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":771,\\"len\\":16,\\"st\\":\\"b\\"}],\\"ver\\":0}","type":""}	rich	[]	f	\N	2026-05-04 07:55:47.069	\N	2026-05-04 07:55:47.488
b6442764-c0f4-4ca6-99d1-f604606a3e8b	e85498a4-0ddc-4da8-9c9d-34ac7e63555b	7789486674731	contact	4043393198066219034	Nguyễn Thành Nhân	Lễ ra mắt và ký kết "Kết nghĩa trường học - Đồng hành vùng biên"\n⏰ Thời gian: 16h00 - 17h30 ngày 06/5/2026\n📍 Địa điểm: Hội trường - Nhà A\n👕 Trang phục / SL: Đồng phục Khoa, quần tây sẫm màu, giày/dép quai hậu • Không giới hạn\n💎 Quyền lợi: 4 giờ CTXH\n🏢 Đơn vị: P.CTSV\nLink đăng ký: https://docs.google.com/spreadsheets/d/1hrrob3ckGALVEBvcuIrEeXRMK9MgTCMS1XCUNi_OE_8/edit?gid=0#gid=0\n👉 Xem thêm hoạt động: https://zinnodntu.github.io/hoatdongsukien/	text	[]	f	\N	2026-05-04 07:57:45.244	\N	2026-05-04 07:57:45.798
53b29774-cbe8-4e22-9b26-19e10927c2ea	e85498a4-0ddc-4da8-9c9d-34ac7e63555b	7789486975531	contact	4043393198066219034	Nguyễn Thành Nhân	Workshop với chủ đề “Sinh viên Trường Đại học học Công nghệ Đồng Nai học tập và làm theo tư tưởng, đạo đức, phong cách Hồ Chí Minh” năm học 2025 – 2026\n⏰ Thời gian: 07h45 – 11h00, Thứ Bảy ngày 09/5/2026\n📍 Địa điểm: Hội trường Nhà A\n👕 Trang phục / SL: Đồng phục Khoa, quần tây sẫm màu, giày/dép quai hậu • 180 sinh viên (số lượng phân bổ trong link)\n💎 Quyền lợi: 4 giờ CTXH\n🏢 Đơn vị: P.CTSV\nLink đăng ký: https://docs.google.com/spreadsheets/d/1awTssgRN210mKCseFPiLVZSG7vgauUvJ57Kg-zpfk8A/edit?usp=sharing\n👉 Xem thêm hoạt động: https://zinnodntu.github.io/hoatdongsukien/	text	[]	f	\N	2026-05-04 07:57:49.635	\N	2026-05-04 07:57:49.938
e45b395c-03ab-4062-9b16-5a0ef0323f4e	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790094318292	contact	3429230737531381136	Nguyễn Nhật Tân	Ê cái dụ làm đơn giờ sao bây	text	[]	f	\N	2026-05-04 10:23:29.205	\N	2026-05-04 10:23:29.564
c7aa09a5-a443-4b3d-b27c-1356bc7236ed	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790105036366	contact	8911995138211367850	Đăng	Cao tí thì ngon	text	[]	f	\N	2026-05-04 10:26:31.918	\N	2026-05-04 10:26:32.133
202ebc91-22f3-49d5-8e50-2b2400fb2d37	b800d881-2d06-4a3b-bf2b-05fb95d86fb9	7789859324544	contact	6913728217060061429	Nguyễn Quang Minh	{"title":"🎯 ĐĂNG KÝ THI CHỨNG CHỈ NGHIỆP VỤ HƯỚNG DẪN DU LỊCH NỘI ĐỊA VÀ QUỐC TẾ ĐỢT 1 - 2026\\nBạn đang chưa có thẻ hoặc thẻ đã hết hạn để được hành nghề hướng dẫn viên du lịch theo quy định của Cục Du lịch Quốc gia Việt Nam.\\n📌 Trường Đại học Công nghệ Đồng Nai (DNTU) chính thức mở đăng ký kỳ thi cấp chứng chỉ đợt 1 - năm 2026 với thông tin như sau:\\n⏳ Thời hạn đăng ký: đến hết ngày 15/05/2026\\n🗓 Thời gian thi: Thứ Ba, ngày 09/06/2026\\n📍 Địa điểm thi:\\nTrường Đại học Công nghệ Đồng Nai\\n(Số 206, Nguyễn Khuyến, KP5, P. Trảng Dài, Thành phố Đồng Nai)\\n📚 Quyền lợi khi tham gia:\\n✔️ Ôn tập miễn phí Online trước kỳ thi\\n✔️ Chứng chỉ cấp giá trị toàn quốc\\n💰 Lệ phí:\\n•\\tSV/cựu SV DNTU ngành Quản trị Dịch vụ Du lịch và Lữ hành: 1.000.000đ/người\\n•\\tSV, CB-GV-NV DNTU: 1.200.000đ/người\\n•\\tĐối tượng khác: 1.400.000đ/người\\n👉 Đăng ký ngay: https://forms.gle/Azt9vkR3rhAUBZHX8\\n📞 Hỗ trợ ngay: 0977 197 340 (Thầy Minh)\\n________________________________________\\n🚀 Cơ hội có thẻ hướng dẫn viên du lịch để hành nghề du lịch đang chờ bạn!\\nSố lượng có hạn – đăng ký sớm để được hỗ trợ ôn tập tốt nhất.\\n#DNTU #HuongDanVienDuLich #ChungChiDuLich #TuyenSinh2026 #CareerOpportunity","description":"","href":"https://photo-stal-13.zdn.vn/gr/jpg/1a74458b9f3c5e62072d/38759931906485915.jpg","thumb":"https://photo-stal-13.zdn.vn/gr/jpg/1a74458b9f3c5e62072d/38759931906485915.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-13.zdn.vn\\\\/gr\\\\/jpg\\\\/1a74458b9f3c5e62072d\\\\/38759931906485915.jpg\\",\\"height\\":2146}","type":""}	image	[]	f	\N	2026-05-04 09:24:02.428	\N	2026-05-04 09:24:02.937
77843026-f3dd-47d8-bef2-1f1fe4afd841	f01396f5-2b28-454a-9f2c-6adcc4ee47d4	7789859324548	contact	6913728217060061429	Nguyễn Quang Minh	{"title":"🎯 ĐĂNG KÝ THI CHỨNG CHỈ NGHIỆP VỤ HƯỚNG DẪN DU LỊCH NỘI ĐỊA VÀ QUỐC TẾ ĐỢT 1 - 2026\\nBạn đang chưa có thẻ hoặc thẻ đã hết hạn để được hành nghề hướng dẫn viên du lịch theo quy định của Cục Du lịch Quốc gia Việt Nam.\\n📌 Trường Đại học Công nghệ Đồng Nai (DNTU) chính thức mở đăng ký kỳ thi cấp chứng chỉ đợt 1 - năm 2026 với thông tin như sau:\\n⏳ Thời hạn đăng ký: đến hết ngày 15/05/2026\\n🗓 Thời gian thi: Thứ Ba, ngày 09/06/2026\\n📍 Địa điểm thi:\\nTrường Đại học Công nghệ Đồng Nai\\n(Số 206, Nguyễn Khuyến, KP5, P. Trảng Dài, Thành phố Đồng Nai)\\n📚 Quyền lợi khi tham gia:\\n✔️ Ôn tập miễn phí Online trước kỳ thi\\n✔️ Chứng chỉ cấp giá trị toàn quốc\\n💰 Lệ phí:\\n•\\tSV/cựu SV DNTU ngành Quản trị Dịch vụ Du lịch và Lữ hành: 1.000.000đ/người\\n•\\tSV, CB-GV-NV DNTU: 1.200.000đ/người\\n•\\tĐối tượng khác: 1.400.000đ/người\\n👉 Đăng ký ngay: https://forms.gle/Azt9vkR3rhAUBZHX8\\n📞 Hỗ trợ ngay: 0977 197 340 (Thầy Minh)\\n________________________________________\\n🚀 Cơ hội có thẻ hướng dẫn viên du lịch để hành nghề du lịch đang chờ bạn!\\nSố lượng có hạn – đăng ký sớm để được hỗ trợ ôn tập tốt nhất.\\n#DNTU #HuongDanVienDuLich #ChungChiDuLich #TuyenSinh2026 #CareerOpportunity","description":"","href":"https://photo-stal-13.zdn.vn/gr/jpg/1a74458b9f3c5e62072d/38759931906485915.jpg","thumb":"https://photo-stal-13.zdn.vn/gr/jpg/1a74458b9f3c5e62072d/38759931906485915.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-13.zdn.vn\\\\/gr\\\\/jpg\\\\/1a74458b9f3c5e62072d\\\\/38759931906485915.jpg\\",\\"height\\":2146}","type":""}	image	[]	f	\N	2026-05-04 09:24:02.43	\N	2026-05-04 09:24:02.978
3ce334d4-6e8e-45cb-9c87-b0a6a4048869	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789959660121	contact	6224515148523678310	Dương Xuân Nghiệp	{"title":"","description":"","href":"https://photo-stal-4.zdn.vn/gr/jpg/c28ac55933eff2b1abfe/1676857112506142594.jpg","thumb":"https://photo-stal-4.zdn.vn/gr/jpg/c28ac55933eff2b1abfe/1676857112506142594.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":0,\\"contentId\\":\\"1000030071\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 09:48:30.434	\N	2026-05-04 09:48:30.905
6edc9dea-ccce-463a-a98d-83097deaf448	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789959856170	contact	6224515148523678310	Dương Xuân Nghiệp	😅😅😅	text	[]	f	\N	2026-05-04 09:48:33.336	\N	2026-05-04 09:48:33.53
089777c0-bffe-4b6a-ad82-adc7ae2b8011	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789963985537	contact	4381049269168369099	Ngọc Hướng	{"title":"","description":"","href":"https://photo-stal-7.zdn.vn/gr/jpg/16d1841976afb7f1eebe/1554788059272543993.jpg","thumb":"https://photo-stal-7.zdn.vn/gr/jpg/16d1841976afb7f1eebe/1554788059272543993.jpg","childnumber":0,"action":"","params":"{\\"id_in_group\\":1,\\"is_group_layout\\":1,\\"width\\":913,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-7.zdn.vn\\\\/gr\\\\/jpg\\\\/16d1841976afb7f1eebe\\\\/1554788059272543993.jpg\\",\\"group_layout_id\\":1777888173302,\\"height\\":531,\\"total_item_in_group\\":2}","type":""}	image	[]	f	\N	2026-05-04 09:49:33.965	\N	2026-05-04 09:49:34.406
fc4aff28-4d72-4aa0-b202-799b76003fa9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789964001275	contact	4381049269168369099	Ngọc Hướng	{"title":"","description":"","href":"https://photo-stal-28.zdn.vn/gr/jpg/bce2b531478786d9df96/1554788059272543993.jpg","thumb":"https://photo-stal-28.zdn.vn/gr/jpg/bce2b531478786d9df96/1554788059272543993.jpg","childnumber":0,"action":"","params":"{\\"id_in_group\\":0,\\"is_group_layout\\":1,\\"width\\":869,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-28.zdn.vn\\\\/gr\\\\/jpg\\\\/bce2b531478786d9df96\\\\/1554788059272543993.jpg\\",\\"group_layout_id\\":1777888173302,\\"height\\":1884,\\"total_item_in_group\\":2}","type":""}	image	[]	f	\N	2026-05-04 09:49:34.289	\N	2026-05-04 09:49:34.534
9295133c-5d73-48dc-b2ac-671bde73d531	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7789964028230	contact	4381049269168369099	Ngọc Hướng	@All  Thân gửi ô anh Tùng Bèng:\n- Chưa từng nhắn tin và cũng chẳng biết ai.\n- Dấn thân vô làm lords cũng 4 5 năm nay từ cày cho buôn tới tự đứng kiếm  bạc lẻ và tự nhận chưa lừa đảo ai bao giờ. \n- Không rõ ông anh này cầm key bạc nào đó đi check mình scam này kia.\n- Không rõ đã tranh cướp đơn nào để phải bị gán mác scam để mất khách.\n- Có khách từng gd họ quý sau họ quay lại ủng hộ thêm nhiều.\nThôi tậm sự vậy, thật ra muốn chửi mả mẹ đứa nào độc ác tố cáo lung tung. Nhiều câu nói quá không muốn nói, nhưng làm người đâu phải làm chó mà ăn bậy nói bậy. Giờ kêu bằng chứng lại lôi lâu rồi ko có, scam đi đòi bằng chứng @@ nên thôi chẳng tranh co. Nói luôn là thằng nào tố bẩn scam thì cả nhà nó làm chó nhé.	text	[]	f	\N	2026-05-04 09:49:34.807	\N	2026-05-04 09:49:34.989
77903cb0-8417-4b39-aab7-c28c59e1123a	b800d881-2d06-4a3b-bf2b-05fb95d86fb9	7789992325158	contact	3057967982860420983	Thanh Phạm	{"title":"𝑻𝒓𝒖̛𝒐̛̀𝒏𝒈 𝑻𝒓𝒖𝒏𝒈 𝑻𝒊𝒆̂̉𝒖 𝑯𝒐̣𝒄 𝑽𝒊𝒆̣̂𝒕 𝑨𝒏𝒉 2 #Tuyểndụng\\n🙆 𝗩𝗶̣ 𝘁𝗿𝗶́ 𝘁𝘂𝘆𝗲̂̉𝗻 𝗱𝘂̣𝗻𝗴:\\n- Giáo viên Tiểu học\\n- Giáo viên Tiếng anh\\n- Giáo viên Toán\\n- Giáo viên Tin học\\n- Giáo viên Mỹ thuật\\n- Giáo viên môn Khoa học tự nhiên\\n- Nhân viên Sales (𝑼̛𝒖 𝒕𝒊𝒆̂𝒏 𝒖̛́𝒏𝒈 𝒗𝒊𝒆̂𝒏 𝒄𝒐́ 𝒕𝒖̛ 𝒅𝒖𝒚 𝑺𝒂𝒍𝒆𝒔 𝒎𝒂̣𝒏𝒉 𝒎𝒆̃, 𝒅𝒂̀𝒚 𝒅𝒂̣̆𝒏 𝒌𝒊𝒏𝒉 𝒏𝒈𝒉𝒊𝒆̣̂𝒎 𝒕𝒓𝒐𝒏𝒈 𝒍𝒊̃𝒏𝒉 𝒗𝒖̛̣𝒄 𝒕𝒖̛ 𝒗𝒂̂́𝒏 𝒗𝒂̀ 𝒄𝒐́ 𝒌𝒚̃ 𝒏𝒂̆𝒏𝒈 𝒄𝒉𝒐̂́𝒕 𝒌𝒉𝒂́𝒄𝒉 𝒉𝒂̀𝒏𝒈 (𝒄𝒍𝒐𝒔𝒊𝒏𝒈) 𝒙𝒖𝒂̂́𝒕 𝒔𝒂̆́𝒄)\\n- Nhân viên Nhân sự.\\n📌 Đ𝒊̣𝒂 𝒄𝒉𝒊̉ 𝒍𝒂̀𝒎 𝒗𝒊𝒆̣̂𝒄: Đường số 13, khu Trung tâm hành chính Dĩ An, Khu phố Nhị Đồng 2, Phường Dĩ An, Tp. Hồ Chí Minh\\n✍𝑪𝒂́𝒄𝒉 𝑻𝒉𝒖̛́𝒄 𝒏𝒐̣̂𝒑 𝒉𝒐̂̀ 𝒔𝒐̛:\\n1️⃣ 𝐋𝐢𝐧𝐤 ứng tuyển: https://bit.ly/tuyendungnhansuvietanh2\\n2️⃣ 𝐌𝐚𝐢𝐥: nhansuvietanh2@vietanhschool.edu.vn\\n3️⃣ 𝐏𝐡𝐨̀𝐧𝐠 𝐧𝐡𝐚̂𝐧 𝐬𝐮̛̣ : 0973304467 (Ms. Vy) / 0937159113 (Ms. Huệ)/  0389994177 (Ms. Thư)\\n𝑻𝒉𝒐̛̀𝒊 𝒉𝒂̣𝒏 𝒏𝒐̣̂𝒑 𝒉𝒐̂̀ 𝒔𝒐̛: 30/05/2026","description":"","href":"https://f64-zpg-r.zdn.vn/jpg/2798275702069117454/f373f1554159c0079948.jpg","thumb":"https://f64-zpg-r.zdn.vn/jpg/2798275702069117454/f373f1554159c0079948.jpg","childnumber":0,"action":"","params":"{\\"fileSize\\":73454,\\"width\\":1280,\\"convertible\\":\\"jxl\\",\\"height\\":720}","type":""}	image	[]	f	\N	2026-05-04 09:56:30.309	\N	2026-05-04 09:56:30.782
90b5ab62-c082-4dfa-bdd0-463a0293b9c8	b800d881-2d06-4a3b-bf2b-05fb95d86fb9	7789992485403	contact	3057967982860420983	Thanh Phạm	𝑻𝒓𝒖̛𝒐̛̀𝒏𝒈 𝑻𝒓𝒖𝒏𝒈 𝑻𝒊𝒆̂̉𝒖 𝑯𝒐̣𝒄 𝑽𝒊𝒆̣̂𝒕 𝑨𝒏𝒉 2 #Tuyểndụng\n🙆 𝗩𝗶̣ 𝘁𝗿𝗶́ 𝘁𝘂𝘆𝗲̂̉𝗻 𝗱𝘂̣𝗻𝗴:\n- Giáo viên Tiểu học\n- Giáo viên Tiếng anh\n- Giáo viên Toán\n- Giáo viên Tin học\n- Giáo viên Mỹ thuật\n- Giáo viên môn Khoa học tự nhiên\n- Nhân viên Sales (𝑼̛𝒖 𝒕𝒊𝒆̂𝒏 𝒖̛́𝒏𝒈 𝒗𝒊𝒆̂𝒏 𝒄𝒐́ 𝒕𝒖̛ 𝒅𝒖𝒚 𝑺𝒂𝒍𝒆𝒔 𝒎𝒂̣𝒏𝒉 𝒎𝒆̃, 𝒅𝒂̀𝒚 𝒅𝒂̣̆𝒏 𝒌𝒊𝒏𝒉 𝒏𝒈𝒉𝒊𝒆̣̂𝒎 𝒕𝒓𝒐𝒏𝒈 𝒍𝒊̃𝒏𝒉 𝒗𝒖̛̣𝒄 𝒕𝒖̛ 𝒗𝒂̂́𝒏 𝒗𝒂̀ 𝒄𝒐́ 𝒌𝒚̃ 𝒏𝒂̆𝒏𝒈 𝒄𝒉𝒐̂́𝒕 𝒌𝒉𝒂́𝒄𝒉 𝒉𝒂̀𝒏𝒈 (𝒄𝒍𝒐𝒔𝒊𝒏𝒈) 𝒙𝒖𝒂̂́𝒕 𝒔𝒂̆́𝒄)\n- Nhân viên Nhân sự.\n📌 Đ𝒊̣𝒂 𝒄𝒉𝒊̉ 𝒍𝒂̀𝒎 𝒗𝒊𝒆̣̂𝒄: Đường số 13, khu Trung tâm hành chính Dĩ An, Khu phố Nhị Đồng 2, Phường Dĩ An, Tp. Hồ Chí Minh\n✍𝑪𝒂́𝒄𝒉 𝑻𝒉𝒖̛́𝒄 𝒏𝒐̣̂𝒑 𝒉𝒐̂̀ 𝒔𝒐̛:\n1️⃣ 𝐋𝐢𝐧𝐤 ứng tuyển: https://bit.ly/tuyendungnhansuvietanh2\n2️⃣ 𝐌𝐚𝐢𝐥: nhansuvietanh2@vietanhschool.edu.vn\n3️⃣ 𝐏𝐡𝐨̀𝐧𝐠 𝐧𝐡𝐚̂𝐧 𝐬𝐮̛̣ : 0973304467 (Ms. Vy) / 0937159113 (Ms. Huệ)/  0389994177 (Ms. Thư)\n𝑻𝒉𝒐̛̀𝒊 𝒉𝒂̣𝒏 𝒏𝒐̣̂𝒑 𝒉𝒐̂̀ 𝒔𝒐̛: 30/05/2026	text	[]	f	\N	2026-05-04 09:56:32.565	\N	2026-05-04 09:56:32.965
2f0c8be1-505a-4de1-8f9f-fed267aa56c4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790067588331	contact	7998210325808057592	Khang Nguyễn	@Ngọc Hướng phải chi làm cho a là ngon rồi :)))	text	[]	f	\N	2026-05-04 10:16:00.163	\N	2026-05-04 10:16:00.652
749bec6f-f9a0-4044-bac4-68e0af03718e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790067880978	contact	7998210325808057592	Khang Nguyễn	{"id":22148,"catId":10340,"type":3}	sticker	[]	f	\N	2026-05-04 10:16:05.059	\N	2026-05-04 10:16:05.342
156d7b95-d04f-4571-9c34-ee2aa1a1508b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790068544285	contact	7998210325808057592	Khang Nguyễn	Trùm scam đây	text	[]	f	\N	2026-05-04 10:16:16.024	\N	2026-05-04 10:16:16.243
39aab90d-8d4f-4cf5-8e77-f10fc4baa7f4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790068922097	contact	8911995138211367850	Đăng	@Khang Nguyễn hóng	text	[]	f	\N	2026-05-04 10:16:22.341	\N	2026-05-04 10:16:22.671
b09633fa-d2aa-4079-ace7-2ad72385a52b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790069186746	contact	8911995138211367850	Đăng	{"title":"","description":"","href":"https://photo-stal-26.zdn.vn/no/f21262deee2f2f71763e/4049268632032793117.jpg","thumb":"","childnumber":0,"action":"","params":"{\\"thumb_height\\":320,\\"contentId\\":\\"41B5AA6D-51F5-4DE1-BB64-4F6F4499082C1\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":320,\\"height\\":320,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-04 10:16:26.774	\N	2026-05-04 10:16:27.101
e010d1bd-b8a4-4eca-ba38-a0f0f41aefc2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790071394902	contact	7998210325808057592	Khang Nguyễn	Có guil nào full pháo ké chụp hình tý ae	text	[]	f	\N	2026-05-04 10:17:03.564	\N	2026-05-04 10:17:03.827
2a6dcc61-5143-406e-bd6c-0d409650b1e6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790071811749	contact	7998210325808057592	Khang Nguyễn	Guil leo lỏ. Đúng lỏ lun	text	[]	f	\N	2026-05-04 10:17:10.503	\N	2026-05-04 10:17:10.785
264de0e4-e2b0-450c-9cf5-05357dee517a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790071936097	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-11.zdn.vn/gr/jpg/7db39d81e730266e7f21/377172596686855412.jpg","thumb":"https://photo-stal-11.zdn.vn/gr/jpg/7db39d81e730266e7f21/377172596686855412.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-04 10:17:12.583	\N	2026-05-04 10:17:12.745
daf720ea-d58c-4bbd-a5ec-0b9114267084	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790072545194	contact	7998210325808057592	Khang Nguyễn	Guil méo gì ko pháo	text	[]	f	\N	2026-05-04 10:17:22.792	\N	2026-05-04 10:17:23.013
85bceb5a-f610-42e2-b37c-e0ee2c272bbb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790073158320	contact	5336474073727949065	Trịnh Tiến	@Khang Nguyễn sang kh. Sếp	text	[]	f	\N	2026-05-04 10:17:33.041	\N	2026-05-04 10:17:33.48
0a3ba126-5770-4752-a6f8-81ad4d0e405b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790073585709	contact	5336474073727949065	Trịnh Tiến	Nhanh em duyệt	text	[]	f	\N	2026-05-04 10:17:40.118	\N	2026-05-04 10:17:40.316
cd4042e2-7419-424e-9f26-442aa4e7d1df	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790073908646	contact	7998210325808057592	Khang Nguyễn	@Trịnh Tiến xin 5-10p nha	text	[]	f	\N	2026-05-04 10:17:45.496	\N	2026-05-04 10:17:45.71
131b8949-339b-47f2-8f8b-13997b9a8d61	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790074146828	contact	8911995138211367850	Đăng	@Trịnh Tiến tí ké	text	[]	f	\N	2026-05-04 10:17:49.486	\N	2026-05-04 10:17:49.627
96f3f8b6-0e70-45cd-8802-b9c486bea47a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790074201857	contact	7998210325808057592	Khang Nguyễn	Guil nào đó	text	[]	f	\N	2026-05-04 10:17:50.437	\N	2026-05-04 10:17:50.607
e0496cd5-1dc5-4093-859f-0b1b8dacc00d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790074419564	contact	8911995138211367850	Đăng	{"title":"","description":"","href":"https://photo-stal-26.zdn.vn/no/f21262deee2f2f71763e/4049268632032793117.jpg","thumb":"","childnumber":0,"action":"","params":"{\\"thumb_height\\":320,\\"contentId\\":\\"41B5AA6D-51F5-4DE1-BB64-4F6F4499082C1\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":320,\\"height\\":320,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-04 10:17:54.056	\N	2026-05-04 10:17:54.179
49031613-0c03-4200-8fd7-0220e561c10e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790075045285	contact	8911995138211367850	Đăng	@Khang Nguyễn KH.	text	[]	f	\N	2026-05-04 10:18:04.434	\N	2026-05-04 10:18:04.746
b1557e13-76f0-4320-8a0d-fa52f80ae3c6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790078594291	contact	5336474073727949065	Trịnh Tiến	@Khang Nguyễn Rùi sếp	text	[]	f	\N	2026-05-04 10:19:03.878	\N	2026-05-04 10:19:04.196
4d70974d-a988-4260-bf81-920bbfd8faae	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790087334274	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-37.zdn.vn/gr/jpg/8fa4a3dd366cf732ae7d/1691566772832719456.jpg","thumb":"https://photo-stal-37.zdn.vn/gr/jpg/8fa4a3dd366cf732ae7d/1691566772832719456.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-04 10:21:30.943	\N	2026-05-04 10:21:31.437
4c13e795-35e8-45aa-82ff-78dd00d6f9e8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790087763106	contact	7998210325808057592	Khang Nguyễn	Nuôi hết nổi. Bán thôi :)))	text	[]	f	\N	2026-05-04 10:21:38.209	\N	2026-05-04 10:21:38.501
348bfc7f-dd04-45bf-93a3-0e6839f6da10	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790090747746	contact	3115939052991645753	Phạm Huy Hoàng	Giờ bà Nhường bà giấu bảng điểm luôn r	text	[]	f	\N	2026-05-04 10:22:28.618	\N	2026-05-04 10:22:29.044
59ad1c70-16cc-4300-b6d2-d20a1a20f347	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790091203421	contact	4769288754303725608	Hiếu	@Khang Nguyễn cha nào mua v a	text	[]	f	\N	2026-05-04 10:22:36.36	\N	2026-05-04 10:22:36.819
f6b59b65-ad08-454b-8630-050425fce636	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790091568659	contact	4769288754303725608	Hiếu	Bảo trả tên đây	text	[]	f	\N	2026-05-04 10:22:42.555	\N	2026-05-04 10:22:42.813
dd9ae969-9510-4484-bc0c-314a8e7b5fe3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790094623421	contact	7998210325808057592	Khang Nguyễn	Định kéo lên 700 xong bán. Mà giờ hết cái để lên bà rồi	text	[]	f	\N	2026-05-04 10:23:34.398	\N	2026-05-04 10:23:34.638
6a53282f-99a7-4c8b-b093-05aeb65c81fa	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790095051655	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-10.zdn.vn/gr/jpg/df404bb5d504145a4d15/2004416116653862292.jpg","thumb":"https://photo-stal-10.zdn.vn/gr/jpg/df404bb5d504145a4d15/2004416116653862292.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-04 10:23:41.692	\N	2026-05-04 10:23:41.897
e8e4b9a1-7619-47cc-824c-056c2adb670e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790096480052	contact	8911995138211367850	Đăng	{"title":"","description":"","href":"https://photo-stal-26.zdn.vn/no/f21262deee2f2f71763e/4049268632032793117.jpg","thumb":"","childnumber":0,"action":"","params":"{\\"thumb_height\\":320,\\"contentId\\":\\"41B5AA6D-51F5-4DE1-BB64-4F6F4499082C1\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":320,\\"height\\":320,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-04 10:24:05.987	\N	2026-05-04 10:24:06.549
11c0a3ef-46f2-4a97-99bd-4d8826a42782	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790096812601	contact	8911995138211367850	Đăng	Mạnh ác	text	[]	f	\N	2026-05-04 10:24:11.685	\N	2026-05-04 10:24:11.913
0f5d1495-2e66-4b2e-b957-54279d012ff0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790098693772	contact	8911995138211367850	Đăng	@Khang Nguyễn ép cỗ à a	text	[]	f	\N	2026-05-04 10:24:43.815	\N	2026-05-04 10:24:44.123
312d86f1-b133-4ffd-9ea0-94387675f78d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790099205952	contact	7998210325808057592	Khang Nguyễn	Sắp rớt dom3. Xuống dưới toàn 7xx	text	[]	f	\N	2026-05-04 10:24:52.537	\N	2026-05-04 10:24:52.791
90aaad13-5299-449a-b35d-6a28572aae9b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790099404510	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-13.zdn.vn/gr/jpg/4c9bcbee4f5f8e01d74e/2201657287399514533.jpg","thumb":"https://photo-stal-13.zdn.vn/gr/jpg/4c9bcbee4f5f8e01d74e/2201657287399514533.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-04 10:24:55.926	\N	2026-05-04 10:24:56.055
29b30924-42a2-46f9-845d-f5df0f25afb4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790100035962	contact	7998210325808057592	Khang Nguyễn	Được 2đợt hỗn độn nữa	text	[]	f	\N	2026-05-04 10:25:06.695	\N	2026-05-04 10:25:06.879
63c3939b-36b3-4d7b-960f-04d720d142a6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790100090484	contact	4011743786444555947	Như Phạm	@Khang Nguyễn sao giống acc ông Duy ms rao v=)	text	[]	f	\N	2026-05-04 10:25:07.614	\N	2026-05-04 10:25:07.921
a1f993f8-e01b-42b3-a0fd-2097bff38d31	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790100468478	contact	4011743786444555947	Như Phạm	{"id":43516,"catId":11786,"type":3}	sticker	[]	f	\N	2026-05-04 10:25:13.954	\N	2026-05-04 10:25:14.26
d2cf7d8b-43ba-4efe-a408-faa397a322b7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790100692606	contact	7998210325808057592	Khang Nguyễn	@Như Phạm ko đâu	text	[]	f	\N	2026-05-04 10:25:17.808	\N	2026-05-04 10:25:17.948
d0a9b4c8-0923-42e5-a597-e421ccd1266e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790100835024	contact	8911995138211367850	Đăng	@Khang Nguyễn Con 10k hở	text	[]	f	\N	2026-05-04 10:25:20.201	\N	2026-05-04 10:25:20.323
fba571cc-e2da-4d79-8b23-b99259b4b6dd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790101211059	contact	7998210325808057592	Khang Nguyễn	@Đăng nó đó	text	[]	f	\N	2026-05-04 10:25:26.626	\N	2026-05-04 10:25:26.913
8cdcb5f0-d30d-4505-b3f9-667d9d3fa196	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790101215590	contact	4011743786444555947	Như Phạm	@Đăng uhm	text	[]	f	\N	2026-05-04 10:25:26.705	\N	2026-05-04 10:25:26.948
18c32a45-8123-4e6c-9374-db2a3bc1e80b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790101497913	contact	4011743786444555947	Như Phạm	Nhìn y chang	text	[]	f	\N	2026-05-04 10:25:31.546	\N	2026-05-04 10:25:31.767
f85c7328-7495-4146-ae08-96ae26246516	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790101754505	contact	4011743786444555947	Như Phạm	{"id":49780,"catId":12334,"type":3}	sticker	[]	f	\N	2026-05-04 10:25:35.884	\N	2026-05-04 10:25:36.11
83662a1c-a994-4fa6-af39-4884de24742e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790102466215	contact	7998210325808057592	Khang Nguyễn	Hay thế nhể	text	[]	f	\N	2026-05-04 10:25:48.015	\N	2026-05-04 10:25:48.249
fb93bf8e-8b2f-45de-a697-22a0d737e7c8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790102474186	contact	8911995138211367850	Đăng	Lên nhiều z	text	[]	f	\N	2026-05-04 10:25:48.145	\N	2026-05-04 10:25:48.368
5a059ceb-ef3a-4782-bc01-f7dd1fe7fa3c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790102583846	contact	8911995138211367850	Đăng	{"title":"","description":"","href":"https://photo-stal-12.zdn.vn/gr/jpg/94b4a2ca227be325ba6a/1641092694855696665.jpg","thumb":"https://photo-stal-12.zdn.vn/gr/jpg/94b4a2ca227be325ba6a/1641092694855696665.jpg","childnumber":0,"action":"","params":"{\\"height\\":1280,\\"thumb_width\\":320,\\"thumb_height\\":320,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-12.zdn.vn\\\\/gr\\\\/jpg\\\\/94b4a2ca227be325ba6a\\\\/1641092694855696665.jpg\\",\\"width\\":1280,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-04 10:25:50.027	\N	2026-05-04 10:25:50.162
b251d1be-e8a7-4e7a-baf3-759f2ea8c443	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790102817059	contact	8911995138211367850	Đăng	Bữa xem	text	[]	f	\N	2026-05-04 10:25:53.948	\N	2026-05-04 10:25:54.125
bd2fda1f-d5cc-45fa-b145-fedeb48b0904	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790102974967	contact	8911995138211367850	Đăng	Mới như này	text	[]	f	\N	2026-05-04 10:25:56.635	\N	2026-05-04 10:25:56.795
9cbc9d0e-852c-4dd8-9567-397118ad8200	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790103069196	contact	8911995138211367850	Đăng	{"title":"","description":"","href":"https://photo-stal-26.zdn.vn/no/f21262deee2f2f71763e/4049268632032793117.jpg","thumb":"","childnumber":0,"action":"","params":"{\\"thumb_height\\":320,\\"contentId\\":\\"41B5AA6D-51F5-4DE1-BB64-4F6F4499082C1\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":320,\\"height\\":320,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-04 10:25:58.224	\N	2026-05-04 10:25:58.353
842ca8bb-9e62-4ffd-8501-332aa917b251	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790103742016	contact	7998210325808057592	Khang Nguyễn	@Đăng Mới bú cái top2 cổ là full cổ rồi	text	[]	f	\N	2026-05-04 10:26:09.745	\N	2026-05-04 10:26:09.924
dac8a63c-bb28-4c8c-af3e-dc63aa0572b9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790103836751	contact	8911995138211367850	Đăng	H chủ lên cao dữ	text	[]	f	\N	2026-05-04 10:26:11.333	\N	2026-05-04 10:26:11.452
6db6acff-4b0c-4c9e-855f-c3e1f6982bee	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790104403454	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-24.zdn.vn/gr/jpg/3422879e052fc4719d3e/3528840549253480673.jpg","thumb":"https://photo-stal-24.zdn.vn/gr/jpg/3422879e052fc4719d3e/3528840549253480673.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-04 10:26:21.091	\N	2026-05-04 10:26:21.343
81f03cae-26f5-492d-8d5a-ef3116f07df9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790104571117	contact	8911995138211367850	Đăng	Hèn gì quen quen	text	[]	f	\N	2026-05-04 10:26:23.922	\N	2026-05-04 10:26:24.099
ea83c548-9f6c-4054-9e25-d2030aeff958	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790105268797	contact	7998210325808057592	Khang Nguyễn	@Đăng a nạp sml. Chứ chủ nào	text	[]	f	\N	2026-05-04 10:26:35.878	\N	2026-05-04 10:26:36.171
022bbbc9-6e50-4a65-8d7f-fc9577ee0a22	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790105413001	contact	7998210325808057592	Khang Nguyễn	{"id":46953,"catId":12002,"type":3}	sticker	[]	f	\N	2026-05-04 10:26:38.364	\N	2026-05-04 10:26:38.549
ee8ff6a0-9403-477b-84f8-6a91c05cbe5e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790105895215	contact	8911995138211367850	Đăng	@Khang Nguyễn ac chủ đại gia mè	text	[]	f	\N	2026-05-04 10:26:46.595	\N	2026-05-04 10:26:46.814
cb9dd687-716b-4426-9b6d-177e61e4b312	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790106505073	contact	8911995138211367850	Đăng	Đại trai đại gia nữa 😬😬	text	[]	f	\N	2026-05-04 10:26:57.033	\N	2026-05-04 10:26:57.261
c7625c01-f37e-43e9-add0-46b67f6498bd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790106689748	contact	7998210325808057592	Khang Nguyễn	Để lại ac ép kia. Nên bán ac này	text	[]	f	\N	2026-05-04 10:27:00.215	\N	2026-05-04 10:27:00.322
1665c37d-de37-4ad7-b861-9f6d9802351e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790107858765	contact	8911995138211367850	Đăng	@Khang Nguyễn con kia đẹp hơn à a	text	[]	f	\N	2026-05-04 10:27:20.195	\N	2026-05-04 10:27:20.409
8abc3f25-baf7-4392-bce9-a7e3bf0595bc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790109629401	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-2.zdn.vn/gr/jpg/d8ab5ba1d210134e4a01/1181471141067485803.jpg","thumb":"https://photo-stal-2.zdn.vn/gr/jpg/d8ab5ba1d210134e4a01/1181471141067485803.jpg","childnumber":0,"action":"","params":"{\\"height\\":1290,\\"thumb_width\\":780,\\"thumb_height\\":360,\\"total_item_in_group\\":2,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":0,\\"group_layout_id\\":1777890470089,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-04 10:27:50.136	\N	2026-05-04 10:27:50.513
5635754e-5dc0-4328-846c-1b215c85b527	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790109633719	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-1.zdn.vn/gr/jpg/5a251e25979456ca0f85/1181471141067485803.jpg","thumb":"https://photo-stal-1.zdn.vn/gr/jpg/5a251e25979456ca0f85/1181471141067485803.jpg","childnumber":0,"action":"","params":"{\\"height\\":1290,\\"thumb_width\\":780,\\"thumb_height\\":360,\\"total_item_in_group\\":2,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":1,\\"group_layout_id\\":1777890470089,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-04 10:27:50.224	\N	2026-05-04 10:27:50.561
117407ed-56e3-4d73-b117-c8fb35a7accd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790109866733	contact	7998210325808057592	Khang Nguyễn	Con này ngon hơn	text	[]	f	\N	2026-05-04 10:27:54.192	\N	2026-05-04 10:27:54.305
d1ca8b88-49ef-4c19-84b4-7398c5e5a7a4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790111077435	contact	3540842572674797348	Tạ Gia Long	{"id":43523,"catId":11786,"type":3}	sticker	[]	f	\N	2026-05-04 10:28:14.554	\N	2026-05-04 10:28:14.952
e0c59732-aab1-48cf-8eea-11171b9f6b58	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790113493272	contact	5336474073727949065	Trịnh Tiến	@Khang Nguyễn Cổ thấp hơn con kia	text	[]	f	\N	2026-05-04 10:28:55.289	\N	2026-05-04 10:28:55.646
364461d4-2d58-47d6-8e7b-00a81fb61b6c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790115836810	contact	4381049269168369099	Ngọc Hướng	@Khang Nguyễn hầy chửi cho bõ tức a oi	text	[]	f	\N	2026-05-04 10:29:34.779	\N	2026-05-04 10:29:35.23
a7af2e79-3c4d-4104-91cb-f78904191885	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790117368290	contact	7998210325808057592	Khang Nguyễn	@Trịnh Tiến ép chuẩn hơn. Nhưng up full nc săn. Thành ra nc nó lỏ hơn con kia 🤣🤣	text	[]	f	\N	2026-05-04 10:30:00.758	\N	2026-05-04 10:30:01.061
16bf4fee-10d4-4888-bb9b-b8f1e5adbb5c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790118918941	contact	5336474073727949065	Trịnh Tiến	@Khang Nguyễn lại thọt * nhà	text	[]	f	\N	2026-05-04 10:30:26.61	\N	2026-05-04 10:30:26.781
f5e82917-71c3-42ce-8863-fe0cbb2a0a1e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790120289619	contact	8911995138211367850	Đăng	@Khang Nguyễn quen lăm snha	text	[]	f	\N	2026-05-04 10:30:49.569	\N	2026-05-04 10:30:50.069
3fd3eeab-7bea-4c97-90ce-9d58610239c8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790120626263	contact	7998210325808057592	Khang Nguyễn	@Trịnh Tiến 2 đợt bán lại nhà mà ko mua :)))	text	[]	f	\N	2026-05-04 10:30:55.327	\N	2026-05-04 10:30:55.551
dfe43e99-1c38-4aa4-91b2-ce54d798688e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790122036519	contact	8911995138211367850	Đăng	@Khang Nguyễn Trắng nhiêu á a	text	[]	f	\N	2026-05-04 10:31:19.332	\N	2026-05-04 10:31:19.587
c0e55812-521e-401b-b6f3-3735d592ac55	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790123030961	contact	7998210325808057592	Khang Nguyễn	@Đăng 650 thui. Lỏ hơn ac kia	text	[]	f	\N	2026-05-04 10:31:36.222	\N	2026-05-04 10:31:36.765
78291536-4c0d-4d99-a508-d94a80cf7279	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790124231096	contact	7998210325808057592	Khang Nguyễn	Bị thọt gần 30 nhà atk	text	[]	f	\N	2026-05-04 10:31:56.662	\N	2026-05-04 10:31:56.885
a44823cf-57c7-4ea5-9cc8-c46beea2beea	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790127780556	contact	8911995138211367850	Đăng	{"title":"H acc này qua ai r nhỉ","description":"","href":"https://photo-stal-34.zdn.vn/gr/jpg/59d22b008db14cef15a0/2865641719954330335.jpg","thumb":"https://photo-stal-34.zdn.vn/gr/jpg/59d22b008db14cef15a0/2865641719954330335.jpg","childnumber":0,"action":"","params":"{\\"height\\":1280,\\"thumb_width\\":320,\\"thumb_height\\":320,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-34.zdn.vn\\\\/gr\\\\/jpg\\\\/59d22b008db14cef15a0\\\\/2865641719954330335.jpg\\",\\"width\\":1280,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-04 10:32:57.403	\N	2026-05-04 10:32:57.673
450b5f3a-20ab-4126-85c3-ca090664b7bc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790128018816	contact	8911995138211367850	Đăng	Thấy ép kinh	text	[]	f	\N	2026-05-04 10:33:01.541	\N	2026-05-04 10:33:01.675
b207628a-eeb5-4016-bd51-8da9809cc16c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790129946394	contact	7998210325808057592	Khang Nguyễn	@Đăng Nó up 108bp rồi. Trắng 860	text	[]	f	\N	2026-05-04 10:33:34.76	\N	2026-05-04 10:33:35.045
0121b411-1150-45ca-a37c-605f7dec765d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790130348560	contact	8911995138211367850	Đăng	@Khang Nguyễn ù ơi	text	[]	f	\N	2026-05-04 10:33:41.667	\N	2026-05-04 10:33:41.918
e01dae1b-0659-404b-8292-a96f21ce3bd5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790130603219	contact	8911995138211367850	Đăng	Hết ép cỗ	text	[]	f	\N	2026-05-04 10:33:46.062	\N	2026-05-04 10:33:46.331
30fd2afa-bccc-4e11-9a88-ae17e0763eec	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790130682637	contact	8911995138211367850	Đăng	{"title":"","description":"","href":"https://photo-stal-26.zdn.vn/no/f21262deee2f2f71763e/4049268632032793117.jpg","thumb":"","childnumber":0,"action":"","params":"{\\"thumb_height\\":320,\\"contentId\\":\\"41B5AA6D-51F5-4DE1-BB64-4F6F4499082C1\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":320,\\"height\\":320,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-04 10:33:47.421	\N	2026-05-04 10:33:47.584
123e9907-afb2-4649-abdb-c300b5e49d82	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790131312495	contact	8911995138211367850	Đăng	@Khang Nguyễn ủa vẫn ép nhỉ	text	[]	f	\N	2026-05-04 10:33:58.285	\N	2026-05-04 10:33:58.534
66aa9555-ee55-40f9-931f-09986c1f9cd6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790131487645	contact	7998210325808057592	Khang Nguyễn	Đợt bán là 5cổ atk top bp còn thiếu 1cổ	text	[]	f	\N	2026-05-04 10:34:01.298	\N	2026-05-04 10:34:01.429
5edb8681-7b28-478b-80fc-7ebd29b15bf3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790131875589	contact	7998210325808057592	Khang Nguyễn	@Đăng Thì vẫn ép mà	text	[]	f	\N	2026-05-04 10:34:08.027	\N	2026-05-04 10:34:08.229
de162da8-046e-47c1-8c11-3098cd7ff915	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790132588812	contact	8911995138211367850	Đăng	@Khang Nguyễn thích mấy acc ép cỗ ghê	text	[]	f	\N	2026-05-04 10:34:20.394	\N	2026-05-04 10:34:20.592
6f5a67fe-6ccf-4658-9f17-0886ea00ae3a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790133106710	contact	8911995138211367850	Đăng	Nhìn nó đã	text	[]	f	\N	2026-05-04 10:34:29.385	\N	2026-05-04 10:34:29.577
43266b0e-0338-485b-81b1-270c6a3bd18e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790136505593	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-37.zdn.vn/gr/jpg/c546027ea8cf699130de/4568995955099037611.jpg","thumb":"https://photo-stal-37.zdn.vn/gr/jpg/c546027ea8cf699130de/4568995955099037611.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":1874,\\"height\\":873,\\"thumb_width\\":772}","type":""}	image	[]	f	\N	2026-05-04 10:35:28.453	\N	2026-05-04 10:35:28.74
c032c1fa-73a5-49f3-8aef-8c79b39340a1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790137101550	contact	7998210325808057592	Khang Nguyễn	100bp chứ	text	[]	f	\N	2026-05-04 10:35:38.864	\N	2026-05-04 10:35:39.178
89096bd9-3709-45fe-aa20-c8a0f43cd913	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790137770511	contact	7998210325808057592	Khang Nguyễn	Thật chứ tìm méo ra ac thứ 2 ngon hơn ac đó	text	[]	f	\N	2026-05-04 10:35:50.555	\N	2026-05-04 10:35:50.862
3a5ef30f-60d5-48a9-b980-61cb4febec2b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790140445183	contact	8911995138211367850	Đăng	@Khang Nguyễn đẹp	text	[]	f	\N	2026-05-04 10:36:37.473	\N	2026-05-04 10:36:37.895
2cffe6d0-1540-428d-8b17-432808e7b6fb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790141647239	contact	8911995138211367850	Đăng	@Khang Nguyễn nhìn này 860 khối ăn thua nhảy cầu	text	[]	f	\N	2026-05-04 10:36:58.514	\N	2026-05-04 10:36:58.78
2ac5faa1-2bd3-4f09-80e0-9354197c420f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790141781540	contact	8911995138211367850	Đăng	{"id":43528,"catId":11786,"type":3}	sticker	[]	f	\N	2026-05-04 10:37:00.868	\N	2026-05-04 10:37:00.992
f0b64b53-8e30-4790-a5d7-8c6b6acdd8ea	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790145896460	contact	7998210325808057592	Khang Nguyễn	Thời cầm ac đó def hỗn độn. Kẹp 3-4 nhát ko cháy. Toàn bọn bp 150 đâm	text	[]	f	\N	2026-05-04 10:38:13.343	\N	2026-05-04 10:38:13.742
3d3a5f97-6070-410c-a6b0-f92195edd3dc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790145957521	contact	7998210325808057592	Khang Nguyễn	{"id":22148,"catId":10340,"type":3}	sticker	[]	f	\N	2026-05-04 10:38:14.48	\N	2026-05-04 10:38:14.616
36eb757d-1db2-45d8-b915-7ae853f61084	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790149255988	contact	5336474073727949065	Trịnh Tiến	@Đăng ác ngon thế	text	[]	f	\N	2026-05-04 10:39:12.709	\N	2026-05-04 10:39:13.163
1018abad-d0dc-424e-8a86-d42f78f851cd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790150567679	contact	8911995138211367850	Đăng	@Trịnh Tiến ảnh thằng full chaml 15 kìa a	text	[]	f	\N	2026-05-04 10:39:35.997	\N	2026-05-04 10:39:36.3
97df6a09-6c5e-4d5d-aa34-beec23955f65	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790151004660	contact	8911995138211367850	Đăng	Cùng 1 acc đó :)))	text	[]	f	\N	2026-05-04 10:39:43.779	\N	2026-05-04 10:39:44.021
6131fbbd-2d5b-40ce-b256-f25289fe8329	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790151177874	contact	8911995138211367850	Đăng	Kinh vãi	text	[]	f	\N	2026-05-04 10:39:46.821	\N	2026-05-04 10:39:46.979
a856c006-1264-4e24-ad3f-50245c922d49	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790152336923	contact	8911995138211367850	Đăng	@Khang Nguyễn z nè đef xong gạ mua acc nó	text	[]	f	\N	2026-05-04 10:40:07.418	\N	2026-05-04 10:40:07.63
62555270-114f-4e86-8064-d873e879b2df	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790152615528	contact	8911995138211367850	Đăng	Bao cay	text	[]	f	\N	2026-05-04 10:40:12.267	\N	2026-05-04 10:40:12.487
25df68b4-8197-4f3b-86fa-772184c0c637	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790153881423	contact	7998210325808057592	Khang Nguyễn	Đợt bị lộ atk thì bán lun	text	[]	f	\N	2026-05-04 10:40:34.739	\N	2026-05-04 10:40:35.024
736fd7a0-0100-4630-9e2e-2c843e8c5c26	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790155636602	contact	7998210325808057592	Khang Nguyễn	Toàn mấy đứa 150-170bp nó join cho lun mà :)))	text	[]	f	\N	2026-05-04 10:41:05.728	\N	2026-05-04 10:41:05.981
48b1a6b0-00bf-4d19-b99f-ff2bb4aefc5d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790156709262	contact	7998210325808057592	Khang Nguyễn	Đánh base dạo thì mặc sét 8ấn bóng đêm vàng. Chả ai biết đồ + mấy	text	[]	f	\N	2026-05-04 10:41:24.803	\N	2026-05-04 10:41:25.01
2a84411d-dfb4-4889-9628-a2a53916d72e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790157192360	contact	412430307068518846	Phúc Mai	{"id":43523,"catId":11786,"type":3}	sticker	[]	f	\N	2026-05-04 10:41:33.388	\N	2026-05-04 10:41:33.793
4be6462e-fe51-4ee2-88b7-54da0e1d8017	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790159400931	contact	8911995138211367850	Đăng	@Khang Nguyễn acc đó 8 ấm à à	text	[]	f	\N	2026-05-04 10:42:12.666	\N	2026-05-04 10:42:13.003
d334a4a4-5daa-44bd-9df9-0f91790e4a73	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790160038753	contact	8911995138211367850	Đăng	z đẹp ác đạn	text	[]	f	\N	2026-05-04 10:42:24.034	\N	2026-05-04 10:42:24.251
b6e2bd40-f22b-4d04-a6fd-79e853e383c4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790160831069	contact	7998210325808057592	Khang Nguyễn	@Đăng đúng rồi. 11army 8ấn bóng đêm	text	[]	f	\N	2026-05-04 10:42:38.098	\N	2026-05-04 10:42:38.372
e0777143-0b89-47ec-b1cc-054b5e4676e9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790161465633	contact	8911995138211367850	Đăng	@Khang Nguyễn đẹp quá chừng	text	[]	f	\N	2026-05-04 10:42:49.408	\N	2026-05-04 10:42:49.671
668b0ac8-ea20-4161-a036-a57a17e2541f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790161802066	contact	8911995138211367850	Đăng	Chắc nó ko nhả :)))	text	[]	f	\N	2026-05-04 10:42:55.472	\N	2026-05-04 10:42:55.745
a72ec686-535b-43d6-ab28-1a90dda375d5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790162070919	contact	7998210325808057592	Khang Nguyễn	Thời đó ko kiếm ra ac thứ 2	text	[]	f	\N	2026-05-04 10:43:00.27	\N	2026-05-04 10:43:00.474
1575dbef-b80a-4da4-bde5-8f6278361cf9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790163162114	contact	8911995138211367850	Đăng	@Khang Nguyễn h xem lên dữ quá	text	[]	f	\N	2026-05-04 10:43:19.686	\N	2026-05-04 10:43:19.911
af366da5-5a97-4094-9772-aadb114113a9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790163450610	contact	7998210325808057592	Khang Nguyễn	Đầu năm 2025 mà max 6cổ top bp atk mà	text	[]	f	\N	2026-05-04 10:43:24.865	\N	2026-05-04 10:43:25.208
4d460202-d7f7-4720-a908-078194c382f9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790225737366	contact	7529400288167692410	Minh	A chị check giúp e với ạ onl hay off.\nMYZDIKAHT	text	[]	f	\N	2026-05-04 11:02:04.709	\N	2026-05-04 11:02:05.143
d2a14cf6-6e63-4345-ab2d-0f06a81a2d80	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790226379966	contact	1921966402916428715	Kunghia	Có kèo nào ko ae	text	[]	f	\N	2026-05-04 11:02:16.222	\N	2026-05-04 11:02:16.538
a1c114dd-cdce-41bf-9c19-60d89b049233	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790298963101	contact	4835990816698319387	Minh Nguyễn	Thử liền cho nóng	text	[]	f	\N	2026-05-04 11:25:03.333	\N	2026-05-04 11:25:03.77
483458c5-13cc-4235-b6d4-b77bc66eaeb2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790301817466	contact	7387240757415509891	Trần Thoại	K biết sao chứ con đó vẫn tính điểm hell ấy hell săn bật con đó chém cx có điểm	text	[]	f	\N	2026-05-04 11:25:56.403	\N	2026-05-04 11:25:56.802
ca7f081a-2699-4072-9d56-06ff42ccf12d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790227220553	contact	7529400288167692410	Minh	{"title":"","description":"","href":"https://photo-stal-23.zdn.vn/gr/jpg/9df772214a918bcfd280/2955262254363388505.jpg","thumb":"https://photo-stal-23.zdn.vn/gr/jpg/9df772214a918bcfd280/2955262254363388505.jpg","childnumber":0,"action":"","params":"{\\"width\\":2408,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-23.zdn.vn\\\\/gr\\\\/jpg\\\\/9df772214a918bcfd280\\\\/2955262254363388505.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000039347\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 11:02:31.311	\N	2026-05-04 11:02:31.602
31b9a9e1-7fbd-4157-aa96-103dc2fbbf8a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790227227732	contact	1921966402916428715	Kunghia	Cho mình qua ké với	text	[]	f	\N	2026-05-04 11:02:31.445	\N	2026-05-04 11:02:31.688
99562806-5f62-4735-9f5f-655e542d37d9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790227955031	contact	1921966402916428715	Kunghia	Múc ko bạn	text	[]	f	\N	2026-05-04 11:02:44.592	\N	2026-05-04 11:02:44.874
fa639ac7-233e-4de5-ba0c-5d2c623c40cb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790228602471	contact	1921966402916428715	Kunghia	Bang bạn góp lính hong	text	[]	f	\N	2026-05-04 11:02:56.263	\N	2026-05-04 11:02:56.463
6b077c21-0202-41c2-b0a2-dc4df4f60d98	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790229013362	contact	7529400288167692410	Minh	Bang nhật bổn nì nó keo lắm a.ng trong bang out ra vào còn ko cho	text	[]	f	\N	2026-05-04 11:03:03.735	\N	2026-05-04 11:03:03.906
cb2aba08-775d-498a-9e5a-0fe40a26c634	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790229579704	contact	2450945486215429124	Hoàng Danh Luyến	Kkk	text	[]	f	\N	2026-05-04 11:03:13.999	\N	2026-05-04 11:03:14.387
963e1c15-2ad1-443a-a689-0b20750dabd8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790230489867	contact	1921966402916428715	Kunghia	Là nó onl hay off hả bạn	text	[]	f	\N	2026-05-04 11:03:30.56	\N	2026-05-04 11:03:30.823
f5c19b9c-b494-4fec-a774-2041fe6447da	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790230699983	contact	1921966402916428715	Kunghia	Off thì múc	text	[]	f	\N	2026-05-04 11:03:34.394	\N	2026-05-04 11:03:34.506
b14f37b5-8180-4f48-a337-c22eaad080ca	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790230891617	contact	7529400288167692410	Minh	Vâng check thử	text	[]	f	\N	2026-05-04 11:03:37.848	\N	2026-05-04 11:03:37.977
de5e45b4-465c-4191-a8d7-21f61f2dabfc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790231431204	contact	7529400288167692410	Minh	A chị check giúp e với ạ onl hay off.\nMYZDIKAHT	text	[]	f	\N	2026-05-04 11:03:47.653	\N	2026-05-04 11:03:47.975
4f918a42-361d-496d-abe5-1380c8bdaa17	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790233351163	contact	5336474073727949065	Trịnh Tiến	@Khang Nguyễn xong chưa sếp	text	[]	f	\N	2026-05-04 11:04:22.511	\N	2026-05-04 11:04:22.964
7a50b98e-25ae-48b7-99d0-fca0f08f9932	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790235859867	contact	585801465063846950	Võ Vũ Nam 武武南	Cho e xin bản quái nanh kiếm vs mn	text	[]	f	\N	2026-05-04 11:05:08.195	\N	2026-05-04 11:05:08.624
93d017c7-4bd9-4fd4-a5bd-553b35538ede	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790237015281	contact	1921966402916428715	Kunghia	@Minh \nMYZbIKAHTofff 20 ngày rồi	text	[]	f	\N	2026-05-04 11:05:29.358	\N	2026-05-04 11:05:29.644
2ecc3ea4-d639-41b9-9fa1-421e3b3f0dc3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790237182857	contact	1921966402916428715	Kunghia	Múc ko bạn	text	[]	f	\N	2026-05-04 11:05:32.426	\N	2026-05-04 11:05:32.549
7ad91613-7769-42de-a1d4-5cfeaf8c4b27	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790246982741	contact	7998210325808057592	Khang Nguyễn	@Trịnh Tiến xong rồi nha. Thanks	text	[]	f	\N	2026-05-04 11:08:33.102	\N	2026-05-04 11:08:33.52
b45bcf66-47a0-41c8-8aae-48811ebed270	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790247456378	contact	7529400288167692410	Minh	Đang múc a	text	[]	f	\N	2026-05-04 11:08:41.906	\N	2026-05-04 11:08:42.379
480bbc43-5378-4ae1-a605-56f774f00758	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790251583138	contact	1921966402916428715	Kunghia	@Minh à nó trên kinh mới thì chịu rồi	text	[]	f	\N	2026-05-04 11:09:58.821	\N	2026-05-04 11:09:59.326
0f49f57a-6fc0-4561-a00a-8196980ec1f6	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790286871976	contact	3115939052991645753	Phạm Huy Hoàng	{"title":"","description":"","href":"https://photo-stal-12.zdn.vn/gr/jpg/63bf68230893c9cd9082/1605783783625642340.jpg","thumb":"https://photo-stal-12.zdn.vn/gr/jpg/63bf68230893c9cd9082/1605783783625642340.jpg","childnumber":0,"action":"","params":"{\\"width\\":2048,\\"height\\":1365,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-12.zdn.vn\\\\/gr\\\\/jpg\\\\/63bf68230893c9cd9082\\\\/1605783783625642340.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777893668944,\\"id_in_group\\":0,\\"total_item_in_group\\":4,\\"contentId\\":\\"1000034873\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 11:21:09.651	\N	2026-05-04 11:21:10.031
e37fa39f-f30e-4c81-8090-b73b98a9234d	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790286882287	contact	3115939052991645753	Phạm Huy Hoàng	{"title":"","description":"","href":"https://photo-stal-37.zdn.vn/gr/jpg/4da247372787e6d9bf96/652875206947774560.jpg","thumb":"https://photo-stal-37.zdn.vn/gr/jpg/4da247372787e6d9bf96/652875206947774560.jpg","childnumber":0,"action":"","params":"{\\"width\\":2048,\\"height\\":1365,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-37.zdn.vn\\\\/gr\\\\/jpg\\\\/4da247372787e6d9bf96\\\\/652875206947774560.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777893668944,\\"id_in_group\\":1,\\"total_item_in_group\\":4,\\"contentId\\":\\"1000034874\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 11:21:09.846	\N	2026-05-04 11:21:10.086
cf09132c-a9a6-4aa4-a535-4bff5f581dbb	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790286926857	contact	3115939052991645753	Phạm Huy Hoàng	{"title":"","description":"","href":"https://photo-stal-34.zdn.vn/gr/jpg/c092712d119dd0c3898c/3854796251694232709.jpg","thumb":"https://photo-stal-34.zdn.vn/gr/jpg/c092712d119dd0c3898c/3854796251694232709.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1706,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-34.zdn.vn\\\\/gr\\\\/jpg\\\\/c092712d119dd0c3898c\\\\/3854796251694232709.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777893668944,\\"id_in_group\\":2,\\"total_item_in_group\\":4,\\"contentId\\":\\"1000034875\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 11:21:10.725	\N	2026-05-04 11:21:10.822
49d96473-db21-4ab0-b26f-73e27eba9f41	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790286930382	contact	3115939052991645753	Phạm Huy Hoàng	{"title":"","description":"","href":"https://photo-stal-25.zdn.vn/gr/jpg/792d089f682fa971f03e/1320690605436522874.jpg","thumb":"https://photo-stal-25.zdn.vn/gr/jpg/792d089f682fa971f03e/1320690605436522874.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1706,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-25.zdn.vn\\\\/gr\\\\/jpg\\\\/792d089f682fa971f03e\\\\/1320690605436522874.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777893668944,\\"id_in_group\\":3,\\"total_item_in_group\\":4,\\"contentId\\":\\"1000034876\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 11:21:10.762	\N	2026-05-04 11:21:10.87
0f5ade52-b445-40eb-9ba0-b8c6b2c03164	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790287082659	contact	3115939052991645753	Phạm Huy Hoàng	Wwoa	text	[]	f	\N	2026-05-04 11:21:13.678	\N	2026-05-04 11:21:13.741
6bfdd728-2fed-4773-ba9c-402ba4c89b13	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790287236871	contact	3115939052991645753	Phạm Huy Hoàng	Khủng	text	[]	f	\N	2026-05-04 11:21:16.676	\N	2026-05-04 11:21:16.753
7d84a846-cfb9-482f-a642-d7370a977445	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790292758507	contact	2936642097806243014	Mthuan	@Tuấn Peodethuong ko ý hỏi quái 5 tiệc bang hội á	text	[]	f	\N	2026-05-04 11:23:03.523	\N	2026-05-04 11:23:03.996
6ea7e669-82e8-44f8-aa05-92978f7c3e43	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790302304146	contact	7387240757415509891	Trần Thoại	Và bao gồm luôn điểm paragon	text	[]	f	\N	2026-05-04 11:26:05.453	\N	2026-05-04 11:26:05.687
a466f8bc-37dc-4d9b-8362-c68279bd2e23	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790303039971	contact	3391365375455109655	Huy	@Mthuan hình như k á	text	[]	f	\N	2026-05-04 11:26:19.073	\N	2026-05-04 11:26:19.414
ade96d4f-1228-46ac-9f62-d8ab8a984249	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790303383575	contact	7387240757415509891	Trần Thoại	Nhưng nv thì t k bt	text	[]	f	\N	2026-05-04 11:26:25.486	\N	2026-05-04 11:26:25.714
22bf1613-3040-4f60-9c40-b3c6c1c30d5f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790321873464	contact	2936642097806243014	Mthuan	Chưa có dịp test	text	[]	f	\N	2026-05-04 11:32:04.95	\N	2026-05-04 11:32:05.384
1bc1180c-1606-44f1-85d7-b4dc9cc2be31	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790322602726	contact	2936642097806243014	Mthuan	Ko đc thì săn luôn	text	[]	f	\N	2026-05-04 11:32:17.667	\N	2026-05-04 11:32:17.89
e1ec5e00-98dd-4d0c-b411-67952b752d21	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790323207470	contact	2936642097806243014	Mthuan	Quái 5 3s là đủ	text	[]	f	\N	2026-05-04 11:32:28.221	\N	2026-05-04 11:32:28.432
701f243d-8ffb-4392-872a-ef7b765f3780	b402e246-2b72-4bb2-a020-74694b771084	7790339104678	contact	2707100667522427286	Trung Tâm Ngoại Ngữ Tin Học Flic Dntu	{"title":"@All Chào các bạn sinh viên,\\n\\nTrung tâm xin thông báo KHÓA MÃ HỌC PHẦN thi chứng nhận tiếng Anh chuẩn đầu ra tháng 5/2026 (Mã học phần 007008103)\\nHiện tại, Trung tâm đã ghi nhận 463 sinh viên đã đăng ký kỳ thi Chứng nhận tiếng Anh chuẩn đầu ra (ngày thi: 16/05/2026), trong đó:\\n343 sinh viên đã hoàn thành lệ phí thi\\n120 sinh viên chưa hoàn thành lệ phí (theo danh sách đính kèm)\\n\\n🔶 Lưu ý quan trọng:\\nCác bạn được tô màu vàng trong danh sách đính kèm sau đây cần khẩn trương hoàn thành lệ phí thi (1.200.000đ), hạn chót đóng lệ phí là trước 23h59p ngày 05/05/2026 để được bảo đảm tư cách dự thi. Đối với các trường hợp không hoàn thành lệ phí thi sau thời điểm trên, trung tâm xin phép hủy tư cách dự thi của các bạn đó nhé!\\n\\nĐối với những bạn chưa kịp đăng ký thi đợt tháng 5, các bạn đợi trung tâm thông báo mã học phần thi mới của tháng 6 rồi nhanh chóng đăng ký nhé.\\n\\n📞 Hotline tư vấn (Trung tâm Ngoại ngữ - Tin học): 070 393 88 99\\n\\nTrân trọng.","description":"","href":"","thumb":"","childnumber":0,"action":"rtf","params":"{\\"styles\\":[{\\"start\\":0,\\"len\\":4,\\"st\\":\\"b\\"},{\\"start\\":4,\\"len\\":1,\\"st\\":\\"b\\"},{\\"start\\":30,\\"len\\":24,\\"st\\":\\"f_18,b,c_15a85f\\"},{\\"start\\":54,\\"len\\":16,\\"st\\":\\"f_18,b,c_db342e\\"},{\\"start\\":70,\\"len\\":75,\\"st\\":\\"f_18,b,c_15a85f\\"},{\\"start\\":146,\\"len\\":131,\\"st\\":\\"b,c_db342e\\"},{\\"start\\":278,\\"len\\":38,\\"st\\":\\"b\\"},{\\"start\\":317,\\"len\\":62,\\"st\\":\\"b\\"},{\\"start\\":402,\\"len\\":134,\\"st\\":\\"c_db342e,f_18\\"},{\\"start\\":536,\\"len\\":28,\\"st\\":\\"f_18\\"},{\\"start\\":564,\\"len\\":161,\\"st\\":\\"c_db342e,f_18\\"},{\\"start\\":727,\\"len\\":144,\\"st\\":\\"b,c_15a85f,f_18\\"},{\\"start\\":873,\\"len\\":0,\\"st\\":\\"u,c_db342e\\"},{\\"start\\":924,\\"len\\":13,\\"st\\":\\"u,c_db342e\\"}],\\"ver\\":0}","type":""}	rich	[]	f	\N	2026-05-04 11:37:06.997	\N	2026-05-04 11:37:07.513
a09b510f-0f4d-4110-ade8-ada2d4692dfd	b402e246-2b72-4bb2-a020-74694b771084	7790339696317	contact	2707100667522427286	Trung Tâm Ngoại Ngữ Tin Học Flic Dntu	{"title":"DS sinh viên đăng ký thi TACĐR 16.05.xls","description":"","href":"https://fg43.dlfl.vn/81005642cd976dc93486/5749733417498196612","thumb":"","childnumber":0,"action":"","params":"{\\"fileSize\\":\\"142336\\", \\"checksum\\":\\"f5832ee52253b55efb7b3998a213da34\\", \\"checksumSha\\":\\"null\\", \\"fileExt\\":\\"xls\\", \\"fdata\\":\\"{}\\", \\"fType\\":1}","type":""}	file	[]	f	\N	2026-05-04 11:37:17.683	\N	2026-05-04 11:37:17.872
6c342623-9794-4079-83b1-299dd38595de	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790348940858	contact	384393945512922450	Đăng	@Khang Nguyễn thằng này nó đi solo zero lun	text	[]	f	\N	2026-05-04 11:40:00.938	\N	2026-05-04 11:40:01.348
e7859280-a06d-476e-9f5a-fc5f57ca48c4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790353332538	contact	384393945512922450	Đăng	{"title":"","description":"","href":"https://photo-stal-12.zdn.vn/gr/jpg/32a7c8816331a26ffb20/742098829211222564.jpg","thumb":"https://photo-stal-12.zdn.vn/gr/jpg/32a7c8816331a26ffb20/742098829211222564.jpg","childnumber":0,"action":"","params":"{\\"width\\":1280,\\"height\\":548,\\"is_group_layout\\":0,\\"contentId\\":\\"1000038895\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 11:41:18.05	\N	2026-05-04 11:41:18.293
d500a986-73c4-4173-9401-47bec7f96ee6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790353994962	contact	384393945512922450	Đăng	1b7 mà nó solo cho zero lun	text	[]	f	\N	2026-05-04 11:41:29.991	\N	2026-05-04 11:41:30.247
17a26696-1ed6-47c2-a463-3cd0bef98297	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790357442433	contact	4569605916426160237	Phát	3b nó cũng solo chứ 1b7	text	[]	f	\N	2026-05-04 11:42:33.352	\N	2026-05-04 11:42:33.757
d26a2d6b-bea4-4871-a1f7-0c4ba4075d75	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790357531475	contact	4569605916426160237	Phát	{"id":45356,"catId":11901,"type":3}	sticker	[]	f	\N	2026-05-04 11:42:34.988	\N	2026-05-04 11:42:35.085
bbdd0fd4-425d-41e0-bee6-714647d1c193	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790358992969	contact	4769288754303725608	Hiếu	Điểm cao nhất đh bao nhiu mn nhỉ	text	[]	f	\N	2026-05-04 11:43:01.796	\N	2026-05-04 11:43:02.166
a27b432e-c0e6-46c6-b338-6e9ba3d39fed	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790359196978	contact	4769288754303725608	Hiếu	{"id":42440,"catId":11726,"type":3}	sticker	[]	f	\N	2026-05-04 11:43:05.555	\N	2026-05-04 11:43:05.712
a475d81b-d79a-4cb3-9ef9-221eb608cb29	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790359334776	contact	2760596411766142024	Nguyễn Đạt	@Hiếu 638x7	text	[]	f	\N	2026-05-04 11:43:08.081	\N	2026-05-04 11:43:08.302
062192c1-65fc-4543-a1ca-1124135278ea	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790359492445	contact	2760596411766142024	Nguyễn Đạt	384x7	text	[]	f	\N	2026-05-04 11:43:10.95	\N	2026-05-04 11:43:11.097
0caab85c-1924-434e-8bd5-157f64ec70cc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790360191582	contact	4769288754303725608	Hiếu	@Nguyễn Đạt này là về hell hay nạp á ah	text	[]	f	\N	2026-05-04 11:43:23.777	\N	2026-05-04 11:43:24.02
38d55a0d-7c1e-45d3-94b8-35f2ff3e2905	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790360232789	contact	2760596411766142024	Nguyễn Đạt	Nvu thường là 3xx j đó	text	[]	f	\N	2026-05-04 11:43:24.56	\N	2026-05-04 11:43:24.65
09f942f4-1d64-4b89-a98d-15c735e522d1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790360306672	contact	2760596411766142024	Nguyễn Đạt	Quêm r	text	[]	f	\N	2026-05-04 11:43:25.877	\N	2026-05-04 11:43:25.995
91aa8a39-04f1-4a6a-8019-4b2a81bc3985	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790360438401	contact	2760596411766142024	Nguyễn Đạt	@Hiếu nạp	text	[]	f	\N	2026-05-04 11:43:28.263	\N	2026-05-04 11:43:28.394
b2abf4ed-8ad1-4543-bab5-8c73247898e7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790360882282	contact	4769288754303725608	Hiếu	@Nguyễn Đạt còn cổ là bao nhiêu nhỉ	text	[]	f	\N	2026-05-04 11:43:36.462	\N	2026-05-04 11:43:36.667
fc1a3ad7-670e-4373-a194-4513bb2bcce6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790361372735	contact	2760596411766142024	Nguyễn Đạt	Cộng vô+bonus 300 điểm nữa	text	[]	f	\N	2026-05-04 11:43:45.452	\N	2026-05-04 11:43:45.654
a8e56320-3457-49ab-8e27-8816084e9270	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790361757453	contact	2760596411766142024	Nguyễn Đạt	@Hiếu cổ 522	text	[]	f	\N	2026-05-04 11:43:52.469	\N	2026-05-04 11:43:52.682
05e326b6-32af-4a5c-a20b-2aecf0b0e08b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790364264664	contact	7496477430098754831	Kenny Đại	@Hiếu 1 nv	text	[]	f	\N	2026-05-04 11:44:38.452	\N	2026-05-04 11:44:38.89
bee3f5e9-08c1-43af-8016-5842b5e133f5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790364515876	contact	7496477430098754831	Kenny Đại	hay full hết nv	text	[]	f	\N	2026-05-04 11:44:43.461	\N	2026-05-04 11:44:43.668
5d50afab-5fbf-4ca3-b3dd-74478003c311	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790389496011	contact	4769288754303725608	Hiếu	@Kenny Đại 1 nv a	text	[]	f	\N	2026-05-04 11:52:21.625	\N	2026-05-04 11:52:22.1
f50f61e9-bcc0-4284-a403-5b10328d5cf5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790389691461	contact	4769288754303725608	Hiếu	@Nguyễn Đạt oke thank a	text	[]	f	\N	2026-05-04 11:52:25.226	\N	2026-05-04 11:52:25.344
40ac6fb8-f8fa-4af4-9a66-16c3f6015993	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790389885040	contact	4769288754303725608	Hiếu	{"id":43521,"catId":11786,"type":3}	sticker	[]	f	\N	2026-05-04 11:52:28.78	\N	2026-05-04 11:52:28.929
f872978a-d4ed-4a7c-89df-7dc5d4dbd8dc	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790405044565	contact	3429230737531381136	Nguyễn Nhật Tân	Khủng ác	text	[]	f	\N	2026-05-04 11:57:06.525	\N	2026-05-04 11:57:06.887
86a9733d-c566-47b1-9210-2322b5171ccf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790418056486	contact	3391365375455109655	Huy	Ae bt đám Fit lead nó chủ yếu là ng nước nào k á	text	[]	f	\N	2026-05-04 12:01:03.127	\N	2026-05-04 12:01:03.578
390bb160-2ac9-4c50-8c0c-29a7d60f76ef	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7790456480900	contact	3429230737531381136	Nguyễn Nhật Tân	@https://drive.google.com/drive/folders/1TwJJTWjOnd-1PomUHf8MLAoYCgm1irXN	text	[]	f	\N	2026-05-04 12:12:43.039	\N	2026-05-04 12:12:43.389
1ed900bf-5efe-45c0-8324-03d4495efb53	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790531171815	contact	2226503885650453985	Nguyễn Thành	@Hiếu Cao nhất là mua 7 gói, nv p2p nên đừng quan tâm	text	[]	f	\N	2026-05-04 12:34:54.278	\N	2026-05-04 12:34:54.713
e8eb7f9b-f4ba-411c-8145-e09a1562b80c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790538399987	contact	4769288754303725608	Hiếu	@Nguyễn Thành dạ a	text	[]	f	\N	2026-05-04 12:37:00.751	\N	2026-05-04 12:37:01.201
30930b9f-5409-4682-8d05-34b7c4a637b8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790544152204	contact	8087701766132846650	Vũ Lộc	{"title":"này chắc trap cụ king mới nhỉ anh em","description":"","href":"https://photo-stal-32.zdn.vn/gr/jpg/133e3a8bb93878662129/2185671839757093592.jpg","thumb":"https://photo-stal-32.zdn.vn/gr/jpg/133e3a8bb93878662129/2185671839757093592.jpg","childnumber":0,"action":"","params":"{\\"width\\":1292,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-32.zdn.vn\\\\/gr\\\\/jpg\\\\/133e3a8bb93878662129\\\\/2185671839757093592.jpg\\",\\"height\\":716}","type":""}	image	[]	f	\N	2026-05-04 12:38:41.858	\N	2026-05-04 12:38:42.333
4093950f-f0fa-437d-9ab4-4806d0d338d7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790548329878	contact	4769288754303725608	Hiếu	@Vũ Lộc rõ ln á a Lộc:))	text	[]	f	\N	2026-05-04 12:39:54.651	\N	2026-05-04 12:39:54.859
64967056-cd12-48cf-97d3-615b0cd7bc5e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790556657397	contact	4881617662073102521	Nguyễn Minh Tuan	đợi mấy idol xuống 1910....	text	[]	f	\N	2026-05-04 12:42:19.825	\N	2026-05-04 12:42:20.284
454d61a9-6d1e-4f15-a1ac-36ca08a6ffc7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790627076954	contact	585801465063846950	Võ Vũ Nam 武武南	{"title":"","description":"","href":"https://photo-stal-9.zdn.vn/gr/jpg/a92a53cab17970272968/4454399482414030421.jpg","thumb":"https://photo-stal-9.zdn.vn/gr/jpg/a92a53cab17970272968/4454399482414030421.jpg","childnumber":0,"action":"","params":"{\\"width\\":2460,\\"height\\":991,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-9.zdn.vn\\\\/gr\\\\/jpg\\\\/a92a53cab17970272968\\\\/4454399482414030421.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000014797\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 13:02:09.856	\N	2026-05-04 13:02:10.315
ffc53258-cd63-4711-9e21-1e01a25806bd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790627295925	contact	585801465063846950	Võ Vũ Nam 武武南	Hảo	text	[]	f	\N	2026-05-04 13:02:13.422	\N	2026-05-04 13:02:13.561
44261785-6723-4f6f-bee5-eb4218250180	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790628515514	contact	585801465063846950	Võ Vũ Nam 武武南	Lần đầu tiên trong đời thấy đánh ám 6 t2😝	text	[]	f	\N	2026-05-04 13:02:33.215	\N	2026-05-04 13:02:33.492
6484361c-1776-43d7-887c-87851c5adcb2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790630794363	contact	585801465063846950	Võ Vũ Nam 武武南	@Vũ Lộc cgi chứ bang TQ thì nổi vs mấy vụ đầu tư r	text	[]	f	\N	2026-05-04 13:03:10.363	\N	2026-05-04 13:03:10.676
e2d584e0-1dd4-4535-9d27-540ae8f28704	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790634530597	contact	3420914362673515390	Nhatgan	@Võ Vũ Nam 武武南 win ko	text	[]	f	\N	2026-05-04 13:04:11.025	\N	2026-05-04 13:04:11.462
0b4f4723-a2a3-4e7a-8a2c-3b5dfdb6af6f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790635254106	contact	585801465063846950	Võ Vũ Nam 武武南	@Nhatgan win rõ	text	[]	f	\N	2026-05-04 13:04:22.826	\N	2026-05-04 13:04:23.087
2168acdc-d074-46b9-bc92-f5e63f92719d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790635694312	contact	3420914362673515390	Nhatgan	À	text	[]	f	\N	2026-05-04 13:04:30.027	\N	2026-05-04 13:04:30.307
e901359b-982b-4b1e-abe2-eb72d93bc211	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790645902139	contact	585801465063846950	Võ Vũ Nam 武武南	{"title":"","description":"","href":"https://photo-stal-12.zdn.vn/gr/jpg/0ee1a35fbbed7ab323fc/278763889396669917.jpg","thumb":"https://photo-stal-12.zdn.vn/gr/jpg/0ee1a35fbbed7ab323fc/278763889396669917.jpg","childnumber":0,"action":"","params":"{\\"width\\":2460,\\"height\\":974,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-12.zdn.vn\\\\/gr\\\\/jpg\\\\/0ee1a35fbbed7ab323fc\\\\/278763889396669917.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000014798\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 13:07:16.328	\N	2026-05-04 13:07:16.824
e28a86e7-f2fc-4421-b384-b877100b4416	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790646486972	contact	585801465063846950	Võ Vũ Nam 武武南	Tính ra mạnh như này tiết kiệm RSS vc ấy chứ	text	[]	f	\N	2026-05-04 13:07:25.877	\N	2026-05-04 13:07:26.127
c173ba89-77c4-4d41-9ca7-c0c68583b357	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790647149986	contact	3420914362673515390	Nhatgan	@Võ Vũ Nam 武武南 có tướng pet đồ gì ko	text	[]	f	\N	2026-05-04 13:07:36.699	\N	2026-05-04 13:07:36.911
f5a51bf7-9858-4033-91ea-f06b82f79d0f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790647987229	contact	3420914362673515390	Nhatgan	@Võ Vũ Nam 武武南 bảo nó đánh t1 nó mới chất	text	[]	f	\N	2026-05-04 13:07:50.403	\N	2026-05-04 13:07:50.634
8af9620c-dfba-48d2-b47f-bd2846c6396c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790652686412	contact	585801465063846950	Võ Vũ Nam 武武南	Tướng pet thì 4 5 , đồ thì cỡ 1k5-1k7	text	[]	f	\N	2026-05-04 13:09:07.154	\N	2026-05-04 13:09:07.435
a0c17b3c-098a-414d-9a70-ff891ab09e67	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790654274862	contact	585801465063846950	Võ Vũ Nam 武武南	{"id":46669,"catId":11984,"type":3}	sticker	[]	f	\N	2026-05-04 13:09:33.095	\N	2026-05-04 13:09:33.439
4d581680-2e0b-45a5-9386-194e008ec798	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790654946093	contact	585801465063846950	Võ Vũ Nam 武武南	Family DW mà	text	[]	f	\N	2026-05-04 13:09:44.089	\N	2026-05-04 13:09:44.337
cf7167d8-da7f-47f4-b7be-75cdbd7824d4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790655127189	contact	3420914362673515390	Nhatgan	@Võ Vũ Nam 武武南 : )	text	[]	f	\N	2026-05-04 13:09:47.065	\N	2026-05-04 13:09:47.334
eded1c8f-7dd1-4582-9ab4-649d0b08c76c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790657801635	contact	4881617662073102521	Nguyễn Minh Tuan	mạnh :v	text	[]	f	\N	2026-05-04 13:10:31.663	\N	2026-05-04 13:10:32.058
0a9be3ad-fdbd-4e16-aec0-d3e45b7425d6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790657919325	contact	585801465063846950	Võ Vũ Nam 武武南	Kêu thứ 5 đi nam tước vs thk Dom	text	[]	f	\N	2026-05-04 13:10:33.252	\N	2026-05-04 13:10:33.383
1c273f81-71aa-4be6-9136-d848e4b27ca0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790658971693	contact	585801465063846950	Võ Vũ Nam 武武南	{"id":45356,"catId":11901,"type":3}	sticker	[]	f	\N	2026-05-04 13:10:50.751	\N	2026-05-04 13:10:50.941
91db3d24-b5c5-4252-b580-63c7119bbfe5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791027229236	contact	4064673509712448879	Tất Đại	Chia sẻ mã mời --ni7cGC3dNq--, [[llRYGXVNxlgZuUzKJwkrU2Mjkv4N0PP ]]	text	[]	f	\N	2026-05-04 14:54:54.943	\N	2026-05-04 14:54:55.35
a7f1379f-0ccc-423f-a43f-ca72f8c70947	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790845032724	contact	7496477430098754831	Kenny Đại	Ra ít gem all lực giá mềm & bán ac 21 nuôi đá ATK\n- Còn 2 ac nhà 21 đang nc và rèn lính săn đá ATK tt 1200d,a c tạo 1843 gem đủ lên HV 25, đồ 6x nl lên xanh tím ( đá vàng gần 5 viên )\n- Trap rally t5 lính 50m ( 2 chén vàng, áo-chân-găng cam ) \nAnh em đam mê nuôi tiếp pmm	text	[]	f	\N	2026-05-04 14:02:06.444	\N	2026-05-04 14:02:06.888
dfe25c08-8af2-4b0b-8706-583efd42ebd8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790888935088	contact	3391365375455109655	Huy	{"title":"","description":"","href":"https://video-stal-28.dlmd.me/gr/b43b3e230d9eccc0958f/2aOboQU69aq3zpIZaV5RZpi0ypI277TWqFaMB6J6","thumb":"https://photo-stal-22.zdn.vn/gr/c8eb60f06b4daa13f35c/2441378371794145708.jpg","childnumber":0,"action":"","params":"{\\"duration\\":241000,\\"is_group_layout\\":0,\\"video_original_width\\":2400,\\"video_original_height\\":1080,\\"video_width\\":1072,\\"video_height\\":480,\\"video_rotation\\":0,\\"fileSize\\":54318064,\\"isHD\\":0}","type":""}	video	[]	f	\N	2026-05-04 14:14:19.79	\N	2026-05-04 14:14:20.259
de4fc7a6-7696-4287-b7f1-227ada8e7d9b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790890613569	contact	3391365375455109655	Huy	Wifi dạo này điên vl:)	text	[]	f	\N	2026-05-04 14:14:48.1	\N	2026-05-04 14:14:48.35
9cde437b-3c37-480c-b299-ada57fe07551	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790899320355	contact	7387240757415509891	Trần Thoại	Bố tiên sư đánh lq còn bật 4G chs ms nổi	text	[]	f	\N	2026-05-04 14:17:15.345	\N	2026-05-04 14:17:15.695
de4fe47f-dea9-4723-b3a7-3e3d2588f966	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790901204200	contact	3391365375455109655	Huy	{"title":"","description":"","href":"https://photo-stal-3.zdn.vn/gr/jpg/04c2e48fc532046c5d23/4535816268621908647.jpg","thumb":"https://photo-stal-3.zdn.vn/gr/jpg/04c2e48fc532046c5d23/4535816268621908647.jpg","childnumber":0,"action":"","params":"{\\"width\\":1908,\\"height\\":858,\\"is_group_layout\\":0,\\"contentId\\":\\"1000012983\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 14:17:47.221	\N	2026-05-04 14:17:47.44
cfff7d34-7a78-4120-a991-1e7bd3df75a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790937790518	contact	5474938560300690685	Hoang Van Tung	Lq bỏ gêm gần năm chơi lại khác vãi nhiều tướng mới ra khó đánh	text	[]	f	\N	2026-05-04 14:28:11.143	\N	2026-05-04 14:28:11.677
4a5217ac-0864-4a26-89f3-7885a3ddb86f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790938094911	contact	5474938560300690685	Hoang Van Tung	{"id":43523,"catId":11786,"type":3}	sticker	[]	f	\N	2026-05-04 14:28:16.412	\N	2026-05-04 14:28:16.609
76c060e7-91ad-4aa4-ba12-b12f21cf9a51	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790939107257	contact	3391365375455109655	Huy	@Hoang Van Tung rank cao k nói chứ rank tầm 5x trở lại	text	[]	f	\N	2026-05-04 14:28:33.808	\N	2026-05-04 14:28:34.198
c040200a-a465-4447-85f2-993831ca5d7c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790939782492	contact	3391365375455109655	Huy	Đem champ đấm vẫn nhừ đòn tụi nó mà:)	text	[]	f	\N	2026-05-04 14:28:45.443	\N	2026-05-04 14:28:45.759
873fa6a4-64d0-4fc1-920f-81cbf8227abb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790941764534	contact	3540842572674797348	Tạ Gia Long	tùy	text	[]	f	\N	2026-05-04 14:29:19.675	\N	2026-05-04 14:29:20.102
91b9a499-4f5e-43a6-8057-b7cfa7265a0e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790942743171	contact	3540842572674797348	Tạ Gia Long	lâu lâu gặp hội rank bk 10k trận:)))	text	[]	f	\N	2026-05-04 14:29:36.66	\N	2026-05-04 14:29:36.937
b1e0f98c-02f9-40bc-8554-aa6a8c6369b0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790953466043	contact	7387240757415509891	Trần Thoại	@Huy đang 4 sao bị hành sml còn 2 sao luôn	text	[]	f	\N	2026-05-04 14:32:41.574	\N	2026-05-04 14:32:41.996
dc2c9d83-5b10-47b8-9c8e-0600ba095bbc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790955122601	contact	7387240757415509891	Trần Thoại	Cầm champ vô vẫn bị bón ngập hành	text	[]	f	\N	2026-05-04 14:33:10.366	\N	2026-05-04 14:33:10.627
0d7cf81f-382d-48e3-b4df-189f158d346e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790965145804	contact	7387240757415509891	Trần Thoại	Mùa trc nx chs max ping lên cục đỏ luôn chưa lên 50 sao	text	[]	f	\N	2026-05-04 14:36:05.914	\N	2026-05-04 14:36:06.232
5c9a5b30-3b7b-4dc2-8525-01ed6287b6e1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790965712255	contact	7387240757415509891	Trần Thoại	{"title":"","description":"","href":"https://sticker-f4-zsocial.zadn.vn/6fa169933e2cde72873d.webp","thumb":"https://sticker-f4-zsocial.zadn.vn/6fa169933e2cde72873d.webp","childnumber":0,"action":"","params":"{\\"width\\":360,\\"height\\":360,\\"is_group_layout\\":0,\\"tracking\\":\\"{\\\\\\"source\\\\\\":7,\\\\\\"keyword\\\\\\":\\\\\\"\\\\\\",\\\\\\"contentID\\\\\\":\\\\\\"-94231832\\\\\\",\\\\\\"send_method\\\\\\":0}\\",\\"webp\\":{\\"url\\":\\"https:\\\\/\\\\/sticker-f4-zsocial.zadn.vn\\\\/6fa169933e2cde72873d.webp\\",\\"width\\":360,\\"height\\":360,\\"thumb\\":\\"\\"},\\"contentId\\":\\"-94231832\\",\\"pStickerType\\":1,\\"pStickerRootCateId\\":10371,\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 14:36:15.91	\N	2026-05-04 14:36:16.085
7f73cb23-218c-4fc2-9118-cf41645b3aa8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790968103049	contact	7387240757415509891	Trần Thoại	Vào game rank 4x gặp mấy ông cóc check thông tin thấy 1k2 1k3 trận muốn thở oxi r	text	[]	f	\N	2026-05-04 14:36:58.166	\N	2026-05-04 14:36:58.456
01840143-a549-43d9-aaa5-1e128e3357aa	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790984475032	contact	585801465063846950	Võ Vũ Nam 武武南	@Trần Thoại nhột bác	text	[]	f	\N	2026-05-04 14:41:50.049	\N	2026-05-04 14:41:50.441
78fca02d-9777-4e29-93d0-d2d158c239d7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7790986210465	contact	585801465063846950	Võ Vũ Nam 武武南	1k2 trận chiến tướng   💔	text	[]	f	\N	2026-05-04 14:42:21.195	\N	2026-05-04 14:42:21.453
2230c266-d1d7-44ba-a2ae-d1ab0ee8a78a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791001669054	contact	5474938560300690685	Hoang Van Tung	@Huy chước bỏ đại cao thủ 3 mà giờ chơi lại hơn tuần nay mà mãi ko lên được ct	text	[]	f	\N	2026-05-04 14:47:00.783	\N	2026-05-04 14:47:01.183
177b4dca-9c31-4588-abcf-df9091c4d935	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791017411542	contact	7387240757415509891	Trần Thoại	{"title":"","description":"","href":"https://photo-stal-13.zdn.vn/gr/jpg/c53f246e88d3498d10c2/50858942523339462.jpg","thumb":"https://photo-stal-13.zdn.vn/gr/jpg/c53f246e88d3498d10c2/50858942523339462.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":1,\\"group_layout_id\\":1777906310691,\\"id_in_group\\":0,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000054798\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 14:51:51.27	\N	2026-05-04 14:51:51.756
8cb92505-faea-4966-8cb8-d8a10c1d190f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791017424922	contact	7387240757415509891	Trần Thoại	{"title":"","description":"","href":"https://photo-stal-11.zdn.vn/gr/jpg/d006985834e5f5bbacf4/50858942523339462.jpg","thumb":"https://photo-stal-11.zdn.vn/gr/jpg/d006985834e5f5bbacf4/50858942523339462.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":1,\\"group_layout_id\\":1777906310691,\\"id_in_group\\":1,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000054799\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 14:51:51.499	\N	2026-05-04 14:51:51.805
3e9a0ee2-5185-45f2-8a6c-ee88942a20bf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791018208773	contact	7387240757415509891	Trần Thoại	Trc đánh đúng gắt h già r về hưu	text	[]	f	\N	2026-05-04 14:52:06.092	\N	2026-05-04 14:52:06.342
74199dfa-0c45-4480-be65-743585f4280c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791019225486	contact	7387240757415509891	Trần Thoại	Đúng là combo thất nghiệp + nghỉ hè cày rank lẹ thiệt	text	[]	f	\N	2026-05-04 14:52:25.022	\N	2026-05-04 14:52:25.283
8965f493-24b4-4d2b-94f5-716ebdb23c1b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791028455610	contact	4064673509712448879	Tất Đại	Ace các bác giúp với:))(	text	[]	f	\N	2026-05-04 14:55:17.956	\N	2026-05-04 14:55:18.257
93082092-7226-496b-aa2d-2f399339c983	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791028640748	contact	7215567985167948581	Nguyễn Tài	Ae oi	text	[]	f	\N	2026-05-04 14:55:21.456	\N	2026-05-04 14:55:21.676
6c167322-6705-4e36-af91-4e350b502435	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791028802637	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-34.zdn.vn/gr/jpg/69032073f6ce37906edf/4595435078278556270.jpg","thumb":"https://photo-stal-34.zdn.vn/gr/jpg/69032073f6ce37906edf/4595435078278556270.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":2,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":0,\\"group_layout_id\\":1777906524220,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-04 14:55:24.519	\N	2026-05-04 14:55:24.676
eb380fd2-63bd-4707-ad18-8bd6e2c6de73	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791028808566	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-34.zdn.vn/gr/jpg/46310e41d8fc19a240ed/4595435078278556270.jpg","thumb":"https://photo-stal-34.zdn.vn/gr/jpg/46310e41d8fc19a240ed/4595435078278556270.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":2,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":1,\\"group_layout_id\\":1777906524220,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-04 14:55:24.623	\N	2026-05-04 14:55:24.805
015c8b9b-cb6a-4fba-8874-7db195fb6a71	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791029346989	contact	7215567985167948581	Nguyễn Tài	anh em ơi cái sự kiện này là sao cho tôi hỏi thử cái đó là cái gì	text	[]	f	\N	2026-05-04 14:55:34.775	\N	2026-05-04 14:55:35.015
18679756-6d8c-44ab-8f1c-480c9f916783	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791029804239	contact	7215567985167948581	Nguyễn Tài	tôi cũng chưa có hiểu	text	[]	f	\N	2026-05-04 14:55:43.392	\N	2026-05-04 14:55:43.625
f3e8941c-7fda-41d9-b99d-9c864c3645cf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791029975095	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-36.zdn.vn/gr/ba0bb4b2401f8141d80e/3070390814707709853.jpg","thumb":"https://photo-stal-36.zdn.vn/gr/ba0bb4b2401f8141d80e/3070390814707709853.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":320,\\"contentId\\":\\"C94DBC66-D1E1-4CF1-97CE-E6FBF4BD9B1A0\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":320,\\"height\\":320,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-04 14:55:46.661	\N	2026-05-04 14:55:46.772
8a258dc5-622e-4123-8b5d-5740f6fa1208	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791031574343	contact	2760596411766142024	Nguyễn Đạt	{"id":27182,"catId":10726,"type":3}	sticker	[]	f	\N	2026-05-04 14:56:16.897	\N	2026-05-04 14:56:17.373
35fee8c5-484c-4217-bc27-a9ac478efd29	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791031856345	contact	7498720695294354711	Nguyễn Quốc Hữu	@Trần Thoại gold sp rồi kk	text	[]	f	\N	2026-05-04 14:56:22.287	\N	2026-05-04 14:56:22.584
5c3ffa0d-3f8c-4291-aa3c-f62868a6c7d2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791083964957	contact	4769288754303725608	Hiếu	{"title":"","description":"","href":"https://photo-stal-13.zdn.vn/gr/jpg/cfcbf7621cdfdd8184ce/4262374572920747168.jpg","thumb":"https://photo-stal-13.zdn.vn/gr/jpg/cfcbf7621cdfdd8184ce/4262374572920747168.jpg","childnumber":0,"action":"","params":"{\\"width\\":960,\\"height\\":1280,\\"is_group_layout\\":0,\\"contentId\\":\\"1000030466\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 15:12:53.88	\N	2026-05-04 15:12:54.421
18515c3b-08f9-4f54-bee9-aca6d6953b32	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791084617721	contact	4769288754303725608	Hiếu	@Huy	text	[]	f	\N	2026-05-04 15:13:06.845	\N	2026-05-04 15:13:07.06
11184be3-b4fa-4ff8-b6c7-4897c50edc77	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791084692972	contact	4769288754303725608	Hiếu	A huy	text	[]	f	\N	2026-05-04 15:13:08.303	\N	2026-05-04 15:13:08.422
a9970c9e-2686-416f-ac1d-29c7c750bad5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791087090189	contact	3391365375455109655	Huy	@Hiếu t có con đẹp hơn gòi mạy	text	[]	f	\N	2026-05-04 15:13:56.166	\N	2026-05-04 15:13:56.605
17f65fe5-eac1-4790-941a-0f9b11cc8f89	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791087638729	contact	3391365375455109655	Huy	Nuôi nhiều gem chuộc chịu k nổi:)	text	[]	f	\N	2026-05-04 15:14:07.21	\N	2026-05-04 15:14:07.407
39641b6b-d4ed-44c4-8cef-e5d8308f9084	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791127210074	contact	5474938560300690685	Hoang Van Tung	@Trần Thoại chơi lq phải vui nhất cày suốt cả ngày là dịch có ít sóng lập nhóm f Zalo song nhóm này đi đánh với nhóm kia vuii	text	[]	f	\N	2026-05-04 15:28:01.185	\N	2026-05-04 15:28:01.666
5786b849-99d6-47a3-aa8e-4475432075ff	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791128520190	contact	4769288754303725608	Hiếu	@Huy a bịp bợm-_-	text	[]	f	\N	2026-05-04 15:28:30.297	\N	2026-05-04 15:28:30.741
5fae24d2-8162-4a47-8a54-108be3fc39ee	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791128796289	contact	4769288754303725608	Hiếu	Má lừa ngta bán rẻ kkk	text	[]	f	\N	2026-05-04 15:28:36.47	\N	2026-05-04 15:28:36.64
646cb488-09c0-4818-b339-4c3be1cb47df	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791330595230	contact	4064673509712448879	Tất Đại	{"title":"","description":"","href":"https://photo-stal-31.zdn.vn/gr/jpg/456c1e16f2aa33f46abb/3655358195574282651.jpg","thumb":"https://photo-stal-31.zdn.vn/gr/jpg/456c1e16f2aa33f46abb/3655358195574282651.jpg","childnumber":0,"action":"","params":"{\\"width\\":1520,\\"height\\":720,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-31.zdn.vn\\\\/gr\\\\/jpg\\\\/456c1e16f2aa33f46abb\\\\/3655358195574282651.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"995111\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 18:13:11.62	\N	2026-05-04 18:13:12.143
c68e9b63-0d1a-47a9-813c-370a85235665	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791330609807	contact	4064673509712448879	Tất Đại	Ti	text	[]	f	\N	2026-05-04 18:13:14.378	\N	2026-05-04 18:13:14.492
80acc6d2-1061-404f-b76c-8024a17f5634	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791330695915	contact	4064673509712448879	Tất Đại	1h đêm chs đỏ đen :)))	text	[]	f	\N	2026-05-04 18:13:30.472	\N	2026-05-04 18:13:30.763
36fbb6f1-9678-471d-9b9b-81ecf3770848	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343460358	contact	4579632439414729865	Tungthanh	{"title":"","description":"","href":"https://photo-stal-13.zdn.vn/gr/jpg/dbc2f52ce89329cd7082/4515662056517197959.jpg","thumb":"https://photo-stal-13.zdn.vn/gr/jpg/dbc2f52ce89329cd7082/4515662056517197959.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1158,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-13.zdn.vn\\\\/gr\\\\/jpg\\\\/dbc2f52ce89329cd7082\\\\/4515662056517197959.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000010245\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 19:05:21.178	\N	2026-05-04 19:05:21.541
5bff710d-7783-4c1d-b53c-8f39349cc45c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343486214	contact	4579632439414729865	Tungthanh	bắt mỗi con tướng mà khổ quá	text	[]	f	\N	2026-05-04 19:05:28.804	\N	2026-05-04 19:05:28.992
1e1e0ae2-6b33-4a39-9433-fb2fd4e37332	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343521703	contact	4579632439414729865	Tungthanh	bắn tiếng mấy r	text	[]	f	\N	2026-05-04 19:05:39.508	\N	2026-05-04 19:05:39.796
df4f1e3b-5465-47ad-90a9-1f51027607d7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343528665	contact	4579632439414729865	Tungthanh	{"id":25774,"catId":10615,"type":3}	sticker	[]	f	\N	2026-05-04 19:05:41.512	\N	2026-05-04 19:05:41.615
0307164d-5464-47d7-8ffb-8a3ebeb6a70c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343585554	contact	826306325505433968	Nana	Bay king khác	text	[]	f	\N	2026-05-04 19:05:58.676	\N	2026-05-04 19:05:59.069
fea252e8-65dc-4570-86f4-0004c1994460	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343607665	contact	4579632439414729865	Tungthanh	kệ hoi	text	[]	f	\N	2026-05-04 19:06:05.3	\N	2026-05-04 19:06:05.47
4b5146be-585a-4244-b1fe-7fba56fe1568	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343643503	contact	4579632439414729865	Tungthanh	vừa ăn con tử 😂	text	[]	f	\N	2026-05-04 19:06:16.248	\N	2026-05-04 19:06:16.496
c17a3a38-3f7d-410f-aec3-eaa3a9d221f0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343682054	contact	4579632439414729865	Tungthanh	solo nó lẹ quá nhỏ onl mà ko cata kịp cả tướng	text	[]	f	\N	2026-05-04 19:06:27.747	\N	2026-05-04 19:06:27.964
be3a2992-6b83-4cc3-bf5f-656592dbf4a0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343703425	contact	826306325505433968	Nana	{"title":"","description":"","href":"https://video-stal-41.dlmd.me/gr/1e61fb29e59624c87d87/pWF2AmF0GwAAAZ30YpFyYWYAYXUCYXMaABAcxw","thumb":"https://photo-stal-35.zdn.vn/gr/93ee36a4281be945b00a/4464786483290620548.jpg","childnumber":0,"action":"","params":"{\\"duration\\":14000,\\"is_group_layout\\":0,\\"video_original_width\\":1096,\\"video_original_height\\":480,\\"video_width\\":1096,\\"video_height\\":480,\\"video_rotation\\":0,\\"fileSize\\":1055943,\\"isHD\\":0}","type":""}	video	[]	f	\N	2026-05-04 19:06:34.183	\N	2026-05-04 19:06:34.403
679f80d0-b973-4ec3-a09d-9de7f15c23ed	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343716629	contact	4579632439414729865	Tungthanh	acc chính nó 3b mấy key đó 😂	text	[]	f	\N	2026-05-04 19:06:38.135	\N	2026-05-04 19:06:38.239
1043b0cb-85eb-4731-8f20-a80c5934be66	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343719522	contact	826306325505433968	Nana	Con này hả	text	[]	f	\N	2026-05-04 19:06:39.17	\N	2026-05-04 19:06:39.262
ff38d1eb-e943-46ac-a76a-40962832b74e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343743015	contact	4579632439414729865	Tungthanh	nó nguyên dàn acc cơ	text	[]	f	\N	2026-05-04 19:06:46.256	\N	2026-05-04 19:06:46.516
7545da98-d8bd-4abe-ba90-8f473e0528d0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343764839	contact	4579632439414729865	Tungthanh	nó đổi acc bắn tối h	text	[]	f	\N	2026-05-04 19:06:53.156	\N	2026-05-04 19:06:53.369
cdefbe06-63c1-4c3d-af5c-24c4a4842c35	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343773650	contact	4579632439414729865	Tungthanh	:$	text	[]	f	\N	2026-05-04 19:06:55.62	\N	2026-05-04 19:06:55.711
656a4f5e-b363-4bdc-9188-6dbb7abb3929	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343851186	contact	4579632439414729865	Tungthanh	xem tên ng bắn đj	text	[]	f	\N	2026-05-04 19:07:19.661	\N	2026-05-04 19:07:19.9
e08cf3ba-d721-4916-945c-abc0c3d5fa88	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343866191	contact	4579632439414729865	Tungthanh	chung chủ đó	text	[]	f	\N	2026-05-04 19:07:24.251	\N	2026-05-04 19:07:24.42
9d34f734-9c10-4d9f-9bad-0d1e134f331c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343872069	contact	4579632439414729865	Tungthanh	:$	text	[]	f	\N	2026-05-04 19:07:26.23	\N	2026-05-04 19:07:26.359
fff27c85-d0fe-423b-8df9-19feb430651f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791343935590	contact	4579632439414729865	Tungthanh	thanh niên bih lụm lead cay lắm 😂	text	[]	f	\N	2026-05-04 19:07:45.902	\N	2026-05-04 19:07:46.146
35271489-0cc7-461b-a25a-d8b4f0890682	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791344007122	contact	4579632439414729865	Tungthanh	onl mà giấu hầm ko kịp mà	text	[]	f	\N	2026-05-04 19:08:08.049	\N	2026-05-04 19:08:08.238
da2bd792-85aa-4b7a-b0ae-539b335b7b64	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791344016307	contact	4579632439414729865	Tungthanh	:')	text	[]	f	\N	2026-05-04 19:08:11.151	\N	2026-05-04 19:08:11.252
9f72648c-bc4b-4d7e-a587-0782bfb15e96	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791344037250	contact	4579632439414729865	Tungthanh	quá nhanh quá nguy hiểm	text	[]	f	\N	2026-05-04 19:08:17.673	\N	2026-05-04 19:08:17.91
3f606cea-afc9-4b71-8f74-e7065799ddc4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791344108977	contact	4579632439414729865	Tungthanh	{"title":"","description":"","href":"https://photo-stal-23.zdn.vn/gr/jpg/4ecd73396d86acd8f597/4580866922280141745.jpg","thumb":"https://photo-stal-23.zdn.vn/gr/jpg/4ecd73396d86acd8f597/4580866922280141745.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1158,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-23.zdn.vn\\\\/gr\\\\/jpg\\\\/4ecd73396d86acd8f597\\\\/4580866922280141745.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000010246\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 19:08:40.224	\N	2026-05-04 19:08:40.461
103b471e-9217-4f05-b413-801d4ccb5c53	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791344144309	contact	4579632439414729865	Tungthanh	cưng ghê luôn á na ơi	text	[]	f	\N	2026-05-04 19:08:51.295	\N	2026-05-04 19:08:51.482
95eade9c-467c-4408-8f6f-222ca52a12dc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791344189119	contact	4579632439414729865	Tungthanh	bắt co  lead còn lời mới pet nữa 😂	text	[]	f	\N	2026-05-04 19:09:05.036	\N	2026-05-04 19:09:05.23
cb3b3e14-e27a-4286-8d7c-a7f88985ba34	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791345617174	contact	4579632439414729865	Tungthanh	{"title":"","description":"","href":"https://photo-stal-11.zdn.vn/gr/jpg/bbda0830108fd1d1889e/1229111417431581855.jpg","thumb":"https://photo-stal-11.zdn.vn/gr/jpg/bbda0830108fd1d1889e/1229111417431581855.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1158,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-11.zdn.vn\\\\/gr\\\\/jpg\\\\/bbda0830108fd1d1889e\\\\/1229111417431581855.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000010247\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-04 19:16:56.572	\N	2026-05-04 19:16:57.019
2d728775-4b60-41fb-8b79-a32efea24ba3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791345655404	contact	4579632439414729865	Tungthanh	@Nana vác clone solo pet vs nó nè	text	[]	f	\N	2026-05-04 19:17:09.662	\N	2026-05-04 19:17:09.904
a43a4c57-3dd6-4921-9b67-9438f0b660a3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7791345664874	contact	4579632439414729865	Tungthanh	:')	text	[]	f	\N	2026-05-04 19:17:12.649	\N	2026-05-04 19:17:12.771
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.orders (id, org_id, contact_id, created_by_user_id, conversation_id, order_code, total_amount, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.organizations (id, name, created_at, updated_at) FROM stdin;
ecae3be0-2ff7-4547-bf7a-308be16a20ad	1car	2026-05-02 04:55:34.533	2026-05-02 04:55:34.533
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.teams (id, org_id, name, created_at) FROM stdin;
9f96990a-679a-4962-8451-25d7d683ed47	ecae3be0-2ff7-4547-bf7a-308be16a20ad	makeeting	2026-05-02 06:05:19.012
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.users (id, org_id, team_id, email, password_hash, full_name, role, is_active, created_at, updated_at) FROM stdin;
e533888b-4c79-42d5-ab7b-7c25b35d6bc8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	\N	hiephiep1002@gmail.com	$2b$12$0eaUaEl86Kxp8ex34agFAOcxfLv2pYaXL78NL7YU2jYkTxKANjuae	hiep	owner	t	2026-05-02 04:55:34.563	2026-05-02 04:55:34.563
fffd31b7-2279-4069-b124-6ef85d977285	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9f96990a-679a-4962-8451-25d7d683ed47	hiephiep10023@gmail.com	$2b$10$kiXYOPwRgx14/gFMuWhDd..4oFvfS9s0yhD2iTJLMofabwxJg3oEa	trần nghĩa hiệp	member	t	2026-05-02 06:05:00.419	2026-05-02 06:05:27.091
\.


--
-- Data for Name: zalo_account_access; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.zalo_account_access (id, zalo_account_id, user_id, permission, created_at) FROM stdin;
\.


--
-- Data for Name: zalo_accounts; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.zalo_accounts (id, org_id, owner_user_id, zalo_uid, display_name, avatar_url, phone, status, session_data, last_connected_at, created_at) FROM stdin;
3b0f3596-7f25-4548-ab4e-dca73e7be21c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	e533888b-4c79-42d5-ab7b-7c25b35d6bc8	117555250217991590	Trần Nghĩa Hiệp	https://s160-ava-talk.zadn.vn/default	\N	connected	{"imei": "6a4faa21-aba3-4ec4-b173-da69e3c839c6-a69b52f9d7f760edf3fd052bcda2542f", "cookie": [{"key": "nl_b04af40bb0e193acf8a9877592394ada", "path": "/", "value": "tzaoLC8i6ltAr3jLnomN_SpMDa_HTtcudT4K13enVG", "domain": "id.zalo.me", "maxAge": 5, "secure": true, "creation": "2026-05-04T02:45:56.476Z", "hostOnly": false, "httpOnly": true, "sameSite": "lax", "lastAccessed": "2026-05-04T02:46:04.054Z"}, {"key": "zpdid", "path": "/", "value": "41NyaLRvgpqK6fEILlZ3D1KVavzM_i4u", "domain": "id.zalo.me", "maxAge": 157680000, "secure": true, "creation": "2026-05-04T02:45:56.476Z", "hostOnly": false, "httpOnly": true, "sameSite": "lax", "lastAccessed": "2026-05-04T02:46:04.054Z"}, {"key": "zlogin_session", "path": "/", "value": "kW4JGLyjCnIxFnDDLXTbH-Tj1a1V5c17wcqOLGDGRb-XB0fS3r1eMg4i15yFK6DDVG", "domain": "id.zalo.me", "maxAge": 3600, "secure": true, "creation": "2026-05-04T02:45:56.476Z", "hostOnly": false, "httpOnly": true, "sameSite": "lax", "lastAccessed": "2026-05-04T02:46:04.054Z"}, {"key": "_zlang", "path": "/", "value": "vn", "domain": "zalo.me", "maxAge": 86400, "secure": true, "expires": "2026-05-05T02:46:04.000Z", "creation": "2026-05-04T02:45:56.519Z", "hostOnly": false, "lastAccessed": "2026-05-04T02:46:04.592Z"}, {"key": "zpsid", "path": "/", "value": "Vqs_.305260274.11.NiJ51w3T_PTIEyo5hDtzbzMkZwIGwC-XaE_AeyTxH9fuegZkeRRrRydT_PS", "domain": "zalo.me", "maxAge": 31536000, "secure": true, "creation": "2026-05-04T02:46:04.052Z", "hostOnly": false, "httpOnly": true, "sameSite": "none", "lastAccessed": "2026-05-04T02:46:04.557Z"}, {"key": "__zi", "path": "/", "value": "3000.QOBlzDCV2uGerkFzm09Mr6RJu_h501hNPj2eyyG56jbaqgtr.1", "domain": "zalo.me", "maxAge": 63072000, "secure": true, "creation": "2026-05-04T02:46:04.052Z", "hostOnly": false, "sameSite": "none", "lastAccessed": "2026-05-04T02:46:04.557Z"}, {"key": "zlogtype", "path": "/", "value": "EXPIRED", "domain": "id.zalo.me", "maxAge": 0, "secure": true, "expires": "1970-01-01T00:00:00.000Z", "creation": "2026-05-04T02:46:04.052Z", "hostOnly": false, "httpOnly": true, "lastAccessed": "2026-05-04T02:46:04.090Z"}, {"key": "zpsid", "path": "/", "value": "eMKnVcAlVqAZUYmFLx5XCziuRsLBj64qtZfnPask0Mob8GvuDCzlIy8y554Fiq9ssNCURpQYUdlTNpDRKhriVQz6DsTPX44zdKiQEMMQGGYLKYqIKxnC8LC", "domain": "zaloapp.com", "maxAge": 31536000, "secure": true, "creation": "2026-05-04T02:46:04.214Z", "hostOnly": false, "httpOnly": true, "sameSite": "none", "lastAccessed": "2026-05-04T02:46:04.214Z"}, {"key": "__zi", "path": "/", "value": "3000.QOBlzDCV2uGerkFzm09Mr6RJu_h501hNPj2eyyG56jbaqgdo.1", "domain": "zaloapp.com", "maxAge": 63072000, "secure": true, "creation": "2026-05-04T02:46:04.214Z", "hostOnly": false, "sameSite": "none", "lastAccessed": "2026-05-04T02:46:04.214Z"}, {"key": "zpw_sek", "path": "/", "value": "Xa6t.305260274.a0.f0Tm9ge3zrLOvSP7YmFtLT4XaZw8ETKxm4R14vunn2FeTQGns7U6OkX9WJpDFiftrsHHxAVRY03J0fjTKchtLG", "domain": "chat.zalo.me", "maxAge": 7776000, "secure": true, "creation": "2026-05-04T02:46:04.403Z", "hostOnly": false, "httpOnly": true, "sameSite": "lax", "lastAccessed": "2026-05-04T02:46:04.557Z"}], "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0"}	2026-05-04 04:00:05.941	2026-05-02 04:55:52.673
\.


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: daily_message_stats daily_message_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: zalo_account_access zalo_account_access_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_pkey PRIMARY KEY (id);


--
-- Name: zalo_accounts zalo_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_pkey PRIMARY KEY (id);


--
-- Name: app_settings_org_id_setting_key_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX app_settings_org_id_setting_key_key ON public.app_settings USING btree (org_id, setting_key);


--
-- Name: conversations_zalo_account_id_external_thread_id_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX conversations_zalo_account_id_external_thread_id_key ON public.conversations USING btree (zalo_account_id, external_thread_id);


--
-- Name: daily_message_stats_user_id_zalo_account_id_stat_date_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX daily_message_stats_user_id_zalo_account_id_stat_date_key ON public.daily_message_stats USING btree (user_id, zalo_account_id, stat_date);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: zalo_account_access_zalo_account_id_user_id_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX zalo_account_access_zalo_account_id_user_id_key ON public.zalo_account_access USING btree (zalo_account_id, user_id);


--
-- Name: zalo_accounts_zalo_uid_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX zalo_accounts_zalo_uid_key ON public.zalo_accounts USING btree (zalo_uid);


--
-- Name: activity_logs activity_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: app_settings app_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contacts contacts_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contacts contacts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: conversations conversations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: daily_message_stats daily_message_stats_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: daily_message_stats daily_message_stats_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_replied_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_replied_by_user_id_fkey FOREIGN KEY (replied_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: teams teams_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: zalo_account_access zalo_account_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_account_access zalo_account_access_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_accounts zalo_accounts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_accounts zalo_accounts_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict dyvyDPCNwUQJbqTPPM1cxwbKti1kYhU1OllTkB7aVejgEAWV5yFBalvg2mFthSn

