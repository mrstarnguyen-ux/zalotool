--
-- PostgreSQL database dump
--

\restrict rdxrjVG5V1HZrxww94jXvourK4CtyJ5b47j67tYh3ybzvl3ZwPjgPPfTK0Ykw5S

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.activity_logs (
    id text NOT NULL,
    org_id text NOT NULL,
    user_id text,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.activity_logs OWNER TO crmuser;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.app_settings (
    id text NOT NULL,
    org_id text NOT NULL,
    setting_key text NOT NULL,
    value_plain text,
    value_encrypted bytea,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.app_settings OWNER TO crmuser;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.appointments (
    id text NOT NULL,
    org_id text NOT NULL,
    contact_id text NOT NULL,
    assigned_user_id text,
    appointment_date timestamp(3) without time zone NOT NULL,
    appointment_time text,
    type text,
    status text DEFAULT 'scheduled'::text NOT NULL,
    notes text,
    reminder_sent boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.appointments OWNER TO crmuser;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.contacts (
    id text NOT NULL,
    org_id text NOT NULL,
    zalo_uid text,
    phone text,
    email text,
    full_name text,
    avatar_url text,
    source text,
    source_date timestamp(3) without time zone,
    first_contact_date timestamp(3) without time zone,
    status text DEFAULT 'new'::text,
    next_appointment timestamp(3) without time zone,
    assigned_user_id text,
    notes text,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contacts OWNER TO crmuser;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.conversations (
    id text NOT NULL,
    org_id text NOT NULL,
    zalo_account_id text NOT NULL,
    contact_id text,
    "threadType" text DEFAULT 'user'::text NOT NULL,
    external_thread_id text,
    last_message_at timestamp(3) without time zone,
    unread_count integer DEFAULT 0 NOT NULL,
    is_replied boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversations OWNER TO crmuser;

--
-- Name: daily_message_stats; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.daily_message_stats (
    id text NOT NULL,
    org_id text NOT NULL,
    user_id text NOT NULL,
    zalo_account_id text NOT NULL,
    stat_date date NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    messages_received integer DEFAULT 0 NOT NULL,
    messages_unread integer DEFAULT 0 NOT NULL,
    messages_unreplied integer DEFAULT 0 NOT NULL,
    avg_response_time_seconds integer
);


ALTER TABLE public.daily_message_stats OWNER TO crmuser;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.messages (
    id text NOT NULL,
    conversation_id text NOT NULL,
    zalo_msg_id text,
    sender_type text NOT NULL,
    sender_uid text,
    sender_name text,
    content text,
    content_type text DEFAULT 'text'::text NOT NULL,
    attachments jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone NOT NULL,
    replied_by_user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.messages OWNER TO crmuser;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.orders (
    id text NOT NULL,
    org_id text NOT NULL,
    contact_id text NOT NULL,
    created_by_user_id text NOT NULL,
    conversation_id text,
    order_code text NOT NULL,
    total_amount double precision NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO crmuser;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.organizations (
    id text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.organizations OWNER TO crmuser;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.teams (
    id text NOT NULL,
    org_id text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.teams OWNER TO crmuser;

--
-- Name: users; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.users (
    id text NOT NULL,
    org_id text NOT NULL,
    team_id text,
    email text NOT NULL,
    password_hash text NOT NULL,
    full_name text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO crmuser;

--
-- Name: zalo_account_access; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.zalo_account_access (
    id text NOT NULL,
    zalo_account_id text NOT NULL,
    user_id text NOT NULL,
    permission text DEFAULT 'read'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.zalo_account_access OWNER TO crmuser;

--
-- Name: zalo_accounts; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.zalo_accounts (
    id text NOT NULL,
    org_id text NOT NULL,
    owner_user_id text NOT NULL,
    zalo_uid text,
    display_name text,
    avatar_url text,
    phone text,
    status text DEFAULT 'disconnected'::text NOT NULL,
    session_data jsonb,
    last_connected_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.zalo_accounts OWNER TO crmuser;

--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.activity_logs (id, org_id, user_id, action, entity_type, entity_id, details, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.app_settings (id, org_id, setting_key, value_plain, value_encrypted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.appointments (id, org_id, contact_id, assigned_user_id, appointment_date, appointment_time, type, status, notes, reminder_sent, created_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.contacts (id, org_id, zalo_uid, phone, email, full_name, avatar_url, source, source_date, first_contact_date, status, next_appointment, assigned_user_id, notes, tags, metadata, created_at, updated_at) FROM stdin;
bd7af861-3466-4c49-bfbd-fcc12733f9ca	ecae3be0-2ff7-4547-bf7a-308be16a20ad	246336029840242028	0925525263	hiephiep1002@gmail.com	LEO SLAYER VÀ NHỮNG NGƯỜI BẠN LORDS MOBILE	\N	FB	\N	2222-01-20 17:00:00	new	2323-03-01 17:00:00	\N	\N	[]	{"isGroup": true}	2026-05-02 04:58:31.389	2026-05-02 06:27:03.834
3818c757-0a5c-4139-848f-1c8c94a9d267	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4860181653371989109	\N	\N	KHOÁ LUẬN K17	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-02 07:09:03.168	2026-05-02 07:09:03.168
2f8c4bc5-fea1-4f9c-8f21-7bd4352de60e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8810000927059780676	\N	\N	Team Thực tập	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-02 14:14:26.559	2026-05-02 14:14:26.559
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.conversations (id, org_id, zalo_account_id, contact_id, "threadType", external_thread_id, last_message_at, unread_count, is_replied, created_at) FROM stdin;
3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	bd7af861-3466-4c49-bfbd-fcc12733f9ca	group	246336029840242028	2026-05-02 16:11:01.582	56	f	2026-05-02 04:58:31.45
33da79ac-da04-4b3e-a667-48f8eca973c5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	3818c757-0a5c-4139-848f-1c8c94a9d267	group	4860181653371989109	2026-05-02 07:09:08.859	0	f	2026-05-02 07:09:03.208
fc2b1261-c3eb-4d1e-9453-162126f5e2d9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3b0f3596-7f25-4548-ab4e-dca73e7be21c	2f8c4bc5-fea1-4f9c-8f21-7bd4352de60e	group	8810000927059780676	2026-05-02 14:27:21.529	0	f	2026-05-02 14:14:26.594
\.


--
-- Data for Name: daily_message_stats; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.daily_message_stats (id, org_id, user_id, zalo_account_id, stat_date, messages_sent, messages_received, messages_unread, messages_unreplied, avg_response_time_seconds) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.messages (id, conversation_id, zalo_msg_id, sender_type, sender_uid, sender_name, content, content_type, attachments, is_deleted, deleted_at, sent_at, replied_by_user_id, created_at) FROM stdin;
2ff79707-e898-433a-8a76-bf01d81eee03	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783037129955	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-4.zdn.vn/gr/jpg/3e66859a9c0d5d53041c/633651562396063229.jpg","thumb":"https://photo-stal-4.zdn.vn/gr/jpg/3e66859a9c0d5d53041c/633651562396063229.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-02 04:58:30.876	\N	2026-05-02 04:58:31.47
a2fe14af-2cd2-4d25-a1f4-862a5eba20e8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783037253189	contact	7998210325808057592	Khang Nguyễn	Ngon :)))	text	[]	f	\N	2026-05-02 04:58:33.743	\N	2026-05-02 04:58:33.905
82bdc21d-d4f3-4330-b158-d3f77640c9bf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783040752159	contact	386507739282916698	Tuấn Peodethuong	Về top 2 là bú rồi, quá đã	text	[]	f	\N	2026-05-02 04:59:54.278	\N	2026-05-02 04:59:54.741
97fda415-db31-49a5-9d0d-a50bf65834a6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783042162656	contact	7998210325808057592	Khang Nguyễn	Đang có 10 mảnh. Đợt này thiếu đúng 2cổ	text	[]	f	\N	2026-05-02 05:00:26.584	\N	2026-05-02 05:00:26.819
191c6168-569e-46fb-98cf-279c6ea430e0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783042537453	contact	7998210325808057592	Khang Nguyễn	Full cổ lun 🤣🤣	text	[]	f	\N	2026-05-02 05:00:35.068	\N	2026-05-02 05:00:35.309
59b23335-199d-4cc0-b013-044c55a7103c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783047040279	contact	7998210325808057592	Khang Nguyễn	{"title":"","description":"","href":"https://photo-stal-24.zdn.vn/gr/jpg/54c3a708a99f68c1318e/152004283628605596.jpg","thumb":"https://photo-stal-24.zdn.vn/gr/jpg/54c3a708a99f68c1318e/152004283628605596.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2796,\\"height\\":1290,\\"thumb_width\\":780}","type":""}	image	[]	f	\N	2026-05-02 05:02:18.181	\N	2026-05-02 05:02:18.472
81e62ed0-1d8a-4758-b875-0d05376cf3a6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783048339578	contact	2191769504086747501	Văn Minh	Trắng 850 chưa sếp	text	[]	f	\N	2026-05-02 05:02:48.138	\N	2026-05-02 05:02:48.49
5bda0bb8-b70c-4406-aff4-cc9829477bc1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783050033648	contact	7998210325808057592	Khang Nguyễn	Ac dom2	text	[]	f	\N	2026-05-02 05:03:27.05	\N	2026-05-02 05:03:27.291
7140b055-5171-4c1c-a45c-389340c5747d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783050215737	contact	7998210325808057592	Khang Nguyễn	Có cái nịt	text	[]	f	\N	2026-05-02 05:03:31.237	\N	2026-05-02 05:03:31.602
395337ba-7087-433a-91a4-cae6ab3b94dd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783094091878	contact	3540842572674797348	Tạ Gia Long	@Huy	text	[]	f	\N	2026-05-02 05:20:51.837	\N	2026-05-02 05:20:52.355
fe45b939-1f68-4237-90bf-09256bfb35ba	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783094273996	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-35.zdn.vn/gr/jpg/73f109034b948acad385/667392811254466561.jpg","thumb":"https://photo-stal-35.zdn.vn/gr/jpg/73f109034b948acad385/667392811254466561.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-35.zdn.vn\\\\/gr\\\\/jpg\\\\/73f109034b948acad385\\\\/667392811254466561.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699254338,\\"id_in_group\\":1,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000014447\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:20:56.309	\N	2026-05-02 05:20:56.523
2c5a4f21-bae3-4641-85d3-51212a501bd4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783094275549	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-16.zdn.vn/gr/jpg/171f1cfa5e6d9f33c67c/1792132690915917282.jpg","thumb":"https://photo-stal-16.zdn.vn/gr/jpg/171f1cfa5e6d9f33c67c/1792132690915917282.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-16.zdn.vn\\\\/gr\\\\/jpg\\\\/171f1cfa5e6d9f33c67c\\\\/1792132690915917282.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699254338,\\"id_in_group\\":0,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000014448\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:20:56.335	\N	2026-05-02 05:20:56.57
5c744595-ca19-44bf-8cb0-80e592076a8a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783094625865	contact	3540842572674797348	Tạ Gia Long	Chỉ cách biến nó thành atk 70 đi fen	text	[]	f	\N	2026-05-02 05:21:04.799	\N	2026-05-02 05:21:05.113
d4603cb6-df88-429f-a05c-57319a59201a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783101591503	contact	2226503885650453985	Nguyễn Thành	Atk70 ăn ám tinh 28 cũng có tỉ lệ ra đó	text	[]	f	\N	2026-05-02 05:23:54.522	\N	2026-05-02 05:23:55.001
4ad67b03-2f7e-4d85-8196-609d05bec1d0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783106472320	contact	7916569348779191770	Kiều Quang Phúc	@Nguyễn Thành ra 50 thôi a	text	[]	f	\N	2026-05-02 05:25:54.643	\N	2026-05-02 05:25:55.053
c4ef5aa2-a490-4e5a-8140-cb0323190179	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783107442989	contact	3874537684008431042	Trang Thành Lộc	50 thôi 🙄	text	[]	f	\N	2026-05-02 05:26:18.546	\N	2026-05-02 05:26:18.869
2813b60e-d59b-4aef-a583-cc80ed30639c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783108282027	contact	2408615132830093674	Dang Tran	{"title":"","description":"","href":"https://photo-stal-26.zdn.vn/gr/jpg/eaeeca5cfccb3d9564da/317269121305226406.jpg","thumb":"https://photo-stal-26.zdn.vn/gr/jpg/eaeeca5cfccb3d9564da/317269121305226406.jpg","childnumber":0,"action":"","params":"{\\"width\\":2772,\\"height\\":1280,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-26.zdn.vn\\\\/gr\\\\/jpg\\\\/eaeeca5cfccb3d9564da\\\\/317269121305226406.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"3232\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:26:39.209	\N	2026-05-02 05:26:39.523
3ea9564a-ad87-41eb-b102-0c816d144c53	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783108759604	contact	2408615132830093674	Dang Tran	Từng rương làm j cứ full mà mở cho lẹ :> :>	text	[]	f	\N	2026-05-02 05:26:50.934	\N	2026-05-02 05:26:51.205
f1048ee0-d09c-4219-962c-6c13d7319e27	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109302423	contact	7498720695294354711	Nguyễn Quốc Hữu	@Dang Tran ngonn	text	[]	f	\N	2026-05-02 05:27:04.369	\N	2026-05-02 05:27:04.802
df0372f9-bdcf-43c2-9833-c08a1681be67	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109837620	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-16.zdn.vn/gr/jpg/171f1cfa5e6d9f33c67c/1792132690915917282.jpg","thumb":"https://photo-stal-16.zdn.vn/gr/jpg/171f1cfa5e6d9f33c67c/1792132690915917282.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-16.zdn.vn\\\\/gr\\\\/jpg\\\\/171f1cfa5e6d9f33c67c\\\\/1792132690915917282.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699636472,\\"id_in_group\\":0,\\"total_item_in_group\\":3,\\"contentId\\":\\"1000014448\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:27:17.53	\N	2026-05-02 05:27:17.92
46de031f-21e1-4a67-be47-8e8925f735ce	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109878050	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-30.zdn.vn/gr/jpg/51821cd06147a019f956/4238697784177133835.jpg","thumb":"https://photo-stal-30.zdn.vn/gr/jpg/51821cd06147a019f956/4238697784177133835.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-30.zdn.vn\\\\/gr\\\\/jpg\\\\/51821cd06147a019f956\\\\/4238697784177133835.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699636472,\\"id_in_group\\":1,\\"total_item_in_group\\":3,\\"contentId\\":\\"1000014449\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:27:18.563	\N	2026-05-02 05:27:18.691
20764e63-c588-4f1e-84a3-3b0a36944801	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109878912	contact	3540842572674797348	Tạ Gia Long	{"title":"","description":"","href":"https://photo-stal-35.zdn.vn/gr/jpg/73f109034b948acad385/667392811254466561.jpg","thumb":"https://photo-stal-35.zdn.vn/gr/jpg/73f109034b948acad385/667392811254466561.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1920,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-35.zdn.vn\\\\/gr\\\\/jpg\\\\/73f109034b948acad385\\\\/667392811254466561.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777699636472,\\"id_in_group\\":2,\\"total_item_in_group\\":3,\\"contentId\\":\\"1000014447\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:27:18.588	\N	2026-05-02 05:27:18.831
5bba8a15-64ab-47f3-b756-9aa8ff2cc990	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783109922292	contact	3540842572674797348	Tạ Gia Long	{"id":43517,"catId":11786,"type":3}	sticker	[]	f	\N	2026-05-02 05:27:19.649	\N	2026-05-02 05:27:19.772
e2c9a17b-1226-4470-af29-cc77050e807c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783110197789	contact	3540842572674797348	Tạ Gia Long	4 acc tạch cả r	text	[]	f	\N	2026-05-02 05:27:26.461	\N	2026-05-02 05:27:26.691
832ce8ca-e64f-49a6-aa4f-b16ea66f2f7b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783139352819	contact	5552626581457264137	Nguyễn Hoài Sơn	{"title":"","description":"","href":"https://photo-stal-22.zdn.vn/gr/jpg/8c57ef126885a9dbf094/1078175464054840850.jpg","thumb":"https://photo-stal-22.zdn.vn/gr/jpg/8c57ef126885a9dbf094/1078175464054840850.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-22.zdn.vn\\\\/gr\\\\/jpg\\\\/8c57ef126885a9dbf094\\\\/1078175464054840850.jpg\\",\\"width\\":2778,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-02 05:39:46.27	\N	2026-05-02 05:39:46.735
ad4dbec7-4633-4bc9-a324-81fa71912760	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783139584219	contact	5552626581457264137	Nguyễn Hoài Sơn	Z là lời hay lỗ	text	[]	f	\N	2026-05-02 05:39:52.288	\N	2026-05-02 05:39:52.629
7003ab83-0878-4195-a91e-9f46bc401ee5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783142177547	contact	7133099385971049210	Phạm Đức Tiến	Lời cám ơn	text	[]	f	\N	2026-05-02 05:40:59.915	\N	2026-05-02 05:41:00.332
53ec7951-05b6-41f1-b02e-ea8dcda692a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783145572766	contact	2191769504086747501	Văn Minh	{"title":"","description":"","href":"https://photo-stal-37.zdn.vn/gr/jpg/1e1119969601575f0e10/1199703692766986882.jpg","thumb":"https://photo-stal-37.zdn.vn/gr/jpg/1e1119969601575f0e10/1199703692766986882.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":360,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"height\\":1284,\\"thumb_width\\":778}","type":""}	image	[]	f	\N	2026-05-02 05:42:29.07	\N	2026-05-02 05:42:29.454
5cf4786a-304b-4125-ac8e-149cba3b1e86	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783145721080	contact	2191769504086747501	Văn Minh	Vậy mới lời nè	text	[]	f	\N	2026-05-02 05:42:32.917	\N	2026-05-02 05:42:33.062
c8ccee2f-abcf-4cdc-a405-5887065a3a2e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783145767871	contact	2191769504086747501	Văn Minh	{"id":1105,"catId":50,"type":3}	sticker	[]	f	\N	2026-05-02 05:42:34.146	\N	2026-05-02 05:42:34.279
a48c6df2-16b9-4080-8c41-5c09df7f262c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184249610	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-9.zdn.vn/gr/jpg/a1a8be3917aed6f08fbf/4083059782671533844.jpg","thumb":"https://photo-stal-9.zdn.vn/gr/jpg/a1a8be3917aed6f08fbf/4083059782671533844.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":1,\\"group_layout_id\\":1777701587445,\\"id_in_group\\":0,\\"total_item_in_group\\":4,\\"contentId\\":\\"99244\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:59:49.028	\N	2026-05-02 05:59:49.411
c83a88b1-317d-4cc4-8a02-f622dd930b9c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184259252	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-24.zdn.vn/gr/jpg/0af90b72a2e563bb3af4/585545276540625646.jpg","thumb":"https://photo-stal-24.zdn.vn/gr/jpg/0af90b72a2e563bb3af4/585545276540625646.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":1,\\"group_layout_id\\":1777701587445,\\"id_in_group\\":1,\\"total_item_in_group\\":4,\\"contentId\\":\\"99245\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:59:49.263	\N	2026-05-02 05:59:49.527
177defb5-70bb-493a-b54f-4a2aa22b8b83	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184274483	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-20.zdn.vn/gr/jpg/dddd5025f9b238ec61a3/4082635243753428268.jpg","thumb":"https://photo-stal-20.zdn.vn/gr/jpg/dddd5025f9b238ec61a3/4082635243753428268.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":1,\\"group_layout_id\\":1777701587445,\\"id_in_group\\":2,\\"total_item_in_group\\":4,\\"contentId\\":\\"99246\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:59:49.751	\N	2026-05-02 05:59:49.879
737ce3aa-f135-4329-83a0-3dcf5c0050ad	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184274496	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-19.zdn.vn/gr/jpg/0df8d20c7b9bbac5e38a/4082635243753428268.jpg","thumb":"https://photo-stal-19.zdn.vn/gr/jpg/0df8d20c7b9bbac5e38a/4082635243753428268.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":1,\\"group_layout_id\\":1777701587445,\\"id_in_group\\":3,\\"total_item_in_group\\":4,\\"contentId\\":\\"99247\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 05:59:49.77	\N	2026-05-02 05:59:49.886
c1c2746a-e3be-4f90-881a-9ff681ca312f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184374906	contact	2936642097806243014	Mthuan	Cũng cũng đi	text	[]	f	\N	2026-05-02 05:59:52.475	\N	2026-05-02 05:59:52.583
79fd701e-4bb0-451c-9970-b3acd299c9fd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184753491	contact	2936642097806243014	Mthuan	@Văn Minh 2 atk70	text	[]	f	\N	2026-05-02 06:00:02.802	\N	2026-05-02 06:00:03.034
51e95f70-4b6d-4c52-8d00-932e743d0dbf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783184827324	contact	2936642097806243014	Mthuan	{"title":"","description":"","href":"https://photo-stal-12.zdn.vn/gr/4ec9a13cee4b2f15765a/790503755819622518.jpg","thumb":"https://photo-stal-12.zdn.vn/gr/4ec9a13cee4b2f15765a/790503755819622518.jpg","childnumber":0,"action":"","params":"{\\"width\\":720,\\"height\\":720,\\"is_group_layout\\":0,\\"tracking\\":\\"{\\\\\\"source\\\\\\":7,\\\\\\"keyword\\\\\\":\\\\\\"\\\\\\",\\\\\\"contentID\\\\\\":\\\\\\"5a0969affe9eadeabbe8b92a19292595\\\\\\",\\\\\\"send_method\\\\\\":0}\\",\\"contentId\\":\\"5a0969affe9eadeabbe8b92a19292595\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 06:00:04.792	\N	2026-05-02 06:00:04.925
438a58c2-8252-4ba2-86b4-50c5c26d3c15	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783187991741	contact	8087701766132846650	Vũ Lộc	Cái kia def 70 mà :)))	text	[]	f	\N	2026-05-02 06:01:29.943	\N	2026-05-02 06:01:30.337
697c1472-71d1-49a0-b94d-34a3fe75b72d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783192154780	contact	3540842572674797348	Tạ Gia Long	của ô khác	text	[]	f	\N	2026-05-02 06:03:23.684	\N	2026-05-02 06:03:24.093
8d5e0188-bb70-42e5-8189-a21cbc87a51b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783192414534	contact	3540842572674797348	Tạ Gia Long	lướt lên đi	text	[]	f	\N	2026-05-02 06:03:30.963	\N	2026-05-02 06:03:31.147
9268b4af-65a5-4ede-b4e8-5d8f1a0a0494	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783192917622	contact	8087701766132846650	Vũ Lộc	À	text	[]	f	\N	2026-05-02 06:03:44.486	\N	2026-05-02 06:03:44.723
fc4542a6-2677-4708-b423-b82766afe72b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783202653768	contact	3900706176857508133	Trần Thái Thiên	{"title":"","description":"","href":"https://photo-stal-10.zdn.vn/gr/jpg/94aee05a24cde593bcdc/2160892849330236103.jpg","thumb":"https://photo-stal-10.zdn.vn/gr/jpg/94aee05a24cde593bcdc/2160892849330236103.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"is_group_layout\\":0,\\"contentId\\":\\"1000027471\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 06:08:12.653	\N	2026-05-02 06:08:13.06
3e03f9f5-11d8-4e1a-9b24-7a6f03240fa0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783202895562	contact	3900706176857508133	Trần Thái Thiên	Buồn của đớ	text	[]	f	\N	2026-05-02 06:08:19.398	\N	2026-05-02 06:08:19.612
d183d6e8-1b10-4911-b29b-23423e207c36	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225472933	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-5.zdn.vn/gr/jpg/9cc343cf52599307ca48/464541618954580023.jpg","thumb":"https://photo-stal-5.zdn.vn/gr/jpg/9cc343cf52599307ca48/464541618954580023.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":2,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:49.981	\N	2026-05-02 06:18:50.419
c9d00cff-ee73-49c6-aa2c-e42a35e350a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225482660	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-23.zdn.vn/gr/jpg/c6b48bba9a2c5b72023d/464541618954580023.jpg","thumb":"https://photo-stal-23.zdn.vn/gr/jpg/c6b48bba9a2c5b72023d/464541618954580023.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":0,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:50.221	\N	2026-05-02 06:18:50.459
4dddc099-ab2e-45c8-a4dc-f45839b37a2b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225479600	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-33.zdn.vn/gr/jpg/8355e25af3cc32926bdd/464541618954580023.jpg","thumb":"https://photo-stal-33.zdn.vn/gr/jpg/8355e25af3cc32926bdd/464541618954580023.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":1,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:50.133	\N	2026-05-02 06:18:50.496
f0df8b06-01b3-47e2-9ea7-ea7290159d88	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225521786	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-2.zdn.vn/gr/jpg/639cf013e38522db7b94/720456045978797076.jpg","thumb":"https://photo-stal-2.zdn.vn/gr/jpg/639cf013e38522db7b94/720456045978797076.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":4,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:51.364	\N	2026-05-02 06:18:51.472
ab6f015d-6142-415f-bf71-17bdaa4428fb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225530514	contact	7215567985167948581	Nguyễn Tài	{"title":"","description":"","href":"https://photo-stal-3.zdn.vn/gr/jpg/1887dd09ce9f0fc1568e/720456045978797076.jpg","thumb":"https://photo-stal-3.zdn.vn/gr/jpg/1887dd09ce9f0fc1568e/720456045978797076.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"total_item_in_group\\":5,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":2778,\\"convertible\\":\\"jxl\\",\\"id_in_group\\":3,\\"group_layout_id\\":1777702729430,\\"is_group_layout\\":1}","type":""}	image	[]	f	\N	2026-05-02 06:18:51.623	\N	2026-05-02 06:18:51.738
c41a370c-e81f-423b-89fe-322ab28730ff	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783225681203	contact	7215567985167948581	Nguyễn Tài	Chào ae OTT Đang ở K1364 Tuyển thành viên bao RSS all sk bang đang thiếu key mời ae key về sẽ được chăm sóc đặt biệt bang vv hoà đồng war nhẹ	text	[]	f	\N	2026-05-02 06:18:55.874	\N	2026-05-02 06:18:56.11
35cd8084-156a-4507-b8d6-abe027211612	33da79ac-da04-4b3e-a667-48f8eca973c5	7783334288377	contact	843064466021066164	Đặng Minh Quang	chỉ cần như vậy thôi đúng k cô? Niên khóa thì e bỏ trống ạ	text	[]	f	\N	2026-05-02 07:09:02.818	\N	2026-05-02 07:09:03.218
d82689fe-5862-497f-a979-f3b0ed25fcab	33da79ac-da04-4b3e-a667-48f8eca973c5	7783334326736	contact	843064466021066164	Đặng Minh Quang	{"title":"","description":"","href":"https://photo-stal-20.zdn.vn/gr/jpg/14fba07d2bebeab5b3fa/3285038049309946119.jpg","thumb":"https://photo-stal-20.zdn.vn/gr/jpg/14fba07d2bebeab5b3fa/3285038049309946119.jpg","childnumber":0,"action":"","params":"{\\"id_in_group\\":0,\\"is_group_layout\\":1,\\"width\\":1919,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-20.zdn.vn\\\\/gr\\\\/jpg\\\\/14fba07d2bebeab5b3fa\\\\/3285038049309946119.jpg\\",\\"group_layout_id\\":1777705742149,\\"height\\":386,\\"total_item_in_group\\":2}","type":""}	image	[]	f	\N	2026-05-02 07:09:03.842	\N	2026-05-02 07:09:03.99
ac5f82ad-d76e-4907-9f1b-c0b60a874338	33da79ac-da04-4b3e-a667-48f8eca973c5	7783334326735	contact	843064466021066164	Đặng Minh Quang	{"title":"","description":"","href":"https://photo-stal-2.zdn.vn/gr/jpg/a0c8124d99db588501ca/3285038049309946119.jpg","thumb":"https://photo-stal-2.zdn.vn/gr/jpg/a0c8124d99db588501ca/3285038049309946119.jpg","childnumber":0,"action":"","params":"{\\"id_in_group\\":1,\\"is_group_layout\\":1,\\"width\\":709,\\"convertible\\":\\"jxl\\",\\"hd\\":\\"https:\\\\/\\\\/photo-stal-2.zdn.vn\\\\/gr\\\\/jpg\\\\/a0c8124d99db588501ca\\\\/3285038049309946119.jpg\\",\\"group_layout_id\\":1777705742149,\\"height\\":298,\\"total_item_in_group\\":2}","type":""}	image	[]	f	\N	2026-05-02 07:09:03.842	\N	2026-05-02 07:09:04.062
5fed3a22-8704-4c98-af93-165352ab8af3	33da79ac-da04-4b3e-a667-48f8eca973c5	7783334500205	contact	843064466021066164	Đặng Minh Quang	@Quách Thị Bích Nhường	text	[]	f	\N	2026-05-02 07:09:08.859	\N	2026-05-02 07:09:09.007
d9a1bbe6-2d90-4a04-ba47-d245506f2613	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783390758172	contact	4579632439414729865	Tungthanh	{"title":"","description":"","href":"https://photo-stal-11.zdn.vn/gr/jpg/6b166b04939252cc0b83/4579207177238629541.jpg","thumb":"https://photo-stal-11.zdn.vn/gr/jpg/6b166b04939252cc0b83/4579207177238629541.jpg","childnumber":0,"action":"","params":"{\\"width\\":2560,\\"height\\":1158,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-11.zdn.vn\\\\/gr\\\\/jpg\\\\/6b166b04939252cc0b83\\\\/4579207177238629541.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000010168\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 07:33:25.901	\N	2026-05-02 07:33:26.416
1e5ad963-fc13-4915-b33f-b50e299f2874	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783391072641	contact	4579632439414729865	Tungthanh	này cần nhiêu sách nữa vậy ae	text	[]	f	\N	2026-05-02 07:33:33.903	\N	2026-05-02 07:33:34.148
0b4a7609-1153-4e50-9ba1-6ec5c471ef0e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783393373999	contact	2760596411766142024	Nguyễn Đạt	@Tungthanh 2k	text	[]	f	\N	2026-05-02 07:34:32.077	\N	2026-05-02 07:34:32.47
6d9fdbe3-2dab-45c0-a93d-e7163b19bc92	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783393619604	contact	4579632439414729865	Tungthanh	{"id":16786,"catId":10052,"type":3}	sticker	[]	f	\N	2026-05-02 07:34:38.27	\N	2026-05-02 07:34:38.494
59ea3d55-ff67-452f-98b5-658b8d9ea75e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783393813353	contact	4579632439414729865	Tungthanh	adu nhiều z	text	[]	f	\N	2026-05-02 07:34:43.103	\N	2026-05-02 07:34:43.298
e69ebfc6-c0c8-4bc7-bf1a-593a5156bc18	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783394389633	contact	2760596411766142024	Nguyễn Đạt	Cái mbd là 1k3	text	[]	f	\N	2026-05-02 07:34:57.711	\N	2026-05-02 07:34:57.953
682fbb18-db89-4bc9-9f57-27dd1593727f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783394616048	contact	2760596411766142024	Nguyễn Đạt	Cái ô cuối xấp xỉ 700	text	[]	f	\N	2026-05-02 07:35:03.471	\N	2026-05-02 07:35:03.679
556b5dec-67c8-4778-b436-e2f465df56eb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783394733236	contact	2760596411766142024	Nguyễn Đạt	{"id":27449,"catId":10739,"type":3}	sticker	[]	f	\N	2026-05-02 07:35:06.393	\N	2026-05-02 07:35:06.53
f9095962-f432-43ab-b0d3-34f98d9dcfa0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783451915970	contact	6562854816970626324	Đức Bình	Kiếm acc đi k13xx	text	[]	f	\N	2026-05-02 07:58:43.616	\N	2026-05-02 07:58:44.029
0f1e5358-7bfd-4456-b40d-247160962da5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783460531910	contact	7673666916021537145	ĐỨC lưu	@Đức Bình ib	text	[]	f	\N	2026-05-02 08:02:00.376	\N	2026-05-02 08:02:00.809
b7c78d9b-e22a-465d-b406-4df98becc09f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783591744967	contact	7496477430098754831	Kenny Đại	Sk 120% ra ít gem all lực giá mềm & bán ac 21 nuôi đá ATK\n- Còn 2 ac nhà 21 đang nc và rèn lính săn đá ATK tt 1200d,a c tạo 1843 gem đủ lên HV 25, đồ 6x nl lên xanh tím ( đá vàng gần 5 viên )\n- Trap rally t5 lính 50m ( 2 chén vàng, áo-chân-găng cam ) \nAnh em đam mê nuôi tiếp pmm	text	[]	f	\N	2026-05-02 08:49:18.475	\N	2026-05-02 08:49:18.924
951c1522-1b55-4c76-b108-d233f8fd9d5e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783605014334	contact	1532676259223031106	Nguyễn Thuỳ Dung	{"title":"","description":"","href":"https://photo-stal-6.zdn.vn/gr/jpg/85e3f4f5e865293b7074/3597491818672983719.jpg","thumb":"https://photo-stal-6.zdn.vn/gr/jpg/85e3f4f5e865293b7074/3597491818672983719.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":780,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":1290,\\"height\\":2796,\\"thumb_width\\":360}","type":""}	image	[]	f	\N	2026-05-02 08:53:55.411	\N	2026-05-02 08:53:55.82
c9c60de4-1134-4d76-bdb1-038d1eca00da	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783613855293	contact	8335543682305672106	Ma Văn Vương	cần 3m gems - 2.278m	text	[]	f	\N	2026-05-02 08:57:04.946	\N	2026-05-02 08:57:05.456
c5e6eb79-3b3b-4c41-9073-1b07df375954	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783620906730	contact	8335543682305672106	Ma Văn Vương	done	text	[]	f	\N	2026-05-02 08:59:37.404	\N	2026-05-02 08:59:37.728
7d9e6162-260a-4ae8-ade0-3ae5c58a0328	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783762023069	contact	4835990816698319387	Minh Nguyễn	{"title":"","description":"","href":"https://photo-stal-5.zdn.vn/gr/jpg/f32ac0ae083ec960902f/3040130261441955514.jpg","thumb":"https://photo-stal-5.zdn.vn/gr/jpg/f32ac0ae083ec960902f/3040130261441955514.jpg","childnumber":0,"action":"","params":"{\\"width\\":858,\\"height\\":1908,\\"is_group_layout\\":0,\\"contentId\\":\\"1000052986\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 09:51:34.577	\N	2026-05-02 09:51:35.069
fabbd7d9-d5f5-4ae6-a7b7-e487a10415dc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783764298885	contact	4835990816698319387	Minh Nguyễn	Game nào khứa kia cũng spam bài đăng tặng acc	text	[]	f	\N	2026-05-02 09:52:24.475	\N	2026-05-02 09:52:24.789
670f22b4-0b29-4466-8de2-ef05479d8a3c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783765710109	contact	4835990816698319387	Minh Nguyễn	Trốn lord mobile sang game khác cũng ko thoát	text	[]	f	\N	2026-05-02 09:52:55.466	\N	2026-05-02 09:52:55.74
9d61d972-ceff-455f-a501-794acd8275d4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783770171259	contact	7193756553000496082	Ht Mr Minh	Hot boy Phú Yên	text	[]	f	\N	2026-05-02 09:54:33.721	\N	2026-05-02 09:54:34.147
b6e29a79-b7fe-4c4d-be06-1db91c793479	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783771474717	contact	7496477430098754831	Kenny Đại	@Minh Nguyễn chắc nghề rồi	text	[]	f	\N	2026-05-02 09:55:02.018	\N	2026-05-02 09:55:02.385
69b42e5b-63af-4e4e-a07b-e88657dcb6c1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783774711164	contact	7193756553000496082	Ht Mr Minh	game nào chả có nó, ăn dễ quá mà	text	[]	f	\N	2026-05-02 09:56:13.646	\N	2026-05-02 09:56:13.842
bbd812b9-516d-43ee-8cc5-ae04c7269507	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783781867113	contact	4835990816698319387	Minh Nguyễn	{"title":"","description":"","href":"https://photo-stal-22.zdn.vn/gr/jpg/bdf351e7b27773292a66/2235515486796704769.jpg","thumb":"https://photo-stal-22.zdn.vn/gr/jpg/bdf351e7b27773292a66/2235515486796704769.jpg","childnumber":0,"action":"","params":"{\\"width\\":858,\\"height\\":1908,\\"is_group_layout\\":0,\\"contentId\\":\\"1000052987\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 09:58:50.002	\N	2026-05-02 09:58:50.498
5f09bdc4-5686-4b1b-8c45-feb11c9f349a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783784166613	contact	4835990816698319387	Minh Nguyễn	Thì ra đây là lý do mà nó có cả đống acc fb	text	[]	f	\N	2026-05-02 09:59:40.433	\N	2026-05-02 09:59:40.666
76a73afe-f99d-4244-9675-d95ad9105f7b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783862187970	contact	585801465063846950	Võ Vũ Nam 武武南	{"id":45356,"catId":11901,"type":3}	sticker	[]	f	\N	2026-05-02 10:28:49.608	\N	2026-05-02 10:28:50.069
1eb0ed8f-9d5d-46b3-b772-30cd65aa00be	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783884163868	contact	8395788325665172100	Lê Quang Long	Mn cho hỏi acc ng ta lk gc nma mình k có sài ip vâyh khi trao đổi tt , chèn sdt mình vô gc đó chỉ vâyj thôi thì có ảnh hưởng j k mn, ổn k mn	text	[]	f	\N	2026-05-02 10:36:57.186	\N	2026-05-02 10:36:57.701
09f69ac4-1bc2-4171-8e2b-47bfd72d9324	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783890712645	contact	4881617662073102521	Nguyễn Minh Tuan	{"title":"","description":"","href":"https://photo-stal-24.zdn.vn/gr/jpg/20aaacd63c45fd1ba454/1017820025811179161.jpg","thumb":"https://photo-stal-24.zdn.vn/gr/jpg/20aaacd63c45fd1ba454/1017820025811179161.jpg","childnumber":0,"action":"","params":"{\\"width\\":1600,\\"height\\":720,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-24.zdn.vn\\\\/gr\\\\/jpg\\\\/20aaacd63c45fd1ba454\\\\/1017820025811179161.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"83728\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 10:39:21.946	\N	2026-05-02 10:39:22.361
62b621f9-3a57-4782-91ca-fff3634b950e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783890902409	contact	4881617662073102521	Nguyễn Minh Tuan	Chợ thốn quá	text	[]	f	\N	2026-05-02 10:39:26.045	\N	2026-05-02 10:39:26.184
033e1c90-314c-43fd-9bab-ac2eacd0957b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783890942614	contact	3540842572674797348	Tạ Gia Long	{"id":43523,"catId":11786,"type":7}	sticker	[]	f	\N	2026-05-02 10:39:26.984	\N	2026-05-02 10:39:27.211
934c5f5c-68fa-4edd-b060-9866e38caaa8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783891034561	contact	3540842572674797348	Tạ Gia Long	giàu	text	[]	f	\N	2026-05-02 10:39:29.147	\N	2026-05-02 10:39:29.261
40f5efd9-4cce-452d-b8de-f8796d39ba8d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783891813729	contact	3540842572674797348	Tạ Gia Long	t dám mua mỗi não nhện vs cuộn sao kèm rương quyền lực	text	[]	f	\N	2026-05-02 10:39:46.471	\N	2026-05-02 10:39:46.686
dd753da7-4ba4-4520-8daa-0ce75d6bde0a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783892055126	contact	4881617662073102521	Nguyễn Minh Tuan	Nghèo r	text	[]	f	\N	2026-05-02 10:39:51.555	\N	2026-05-02 10:39:51.761
5a7d6dda-b96c-41d9-99f6-6b22062ba430	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783892452199	contact	3540842572674797348	Tạ Gia Long	3d mà tiêu z gf chỉ đi đánh ám	text	[]	f	\N	2026-05-02 10:40:00.6	\N	2026-05-02 10:40:00.779
f782b518-e055-4f62-a72d-44373e1ddcff	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783892774414	contact	3540842572674797348	Tạ Gia Long	{"id":45356,"catId":11901,"type":7}	sticker	[]	f	\N	2026-05-02 10:40:07.822	\N	2026-05-02 10:40:08.026
8a2e7c12-fb04-46bc-a08a-89f9118d8b83	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783892948634	contact	4881617662073102521	Nguyễn Minh Tuan	@Tạ Gia Long acc trap lỏ nên j cũng cần á ông	text	[]	f	\N	2026-05-02 10:40:11.317	\N	2026-05-02 10:40:11.41
24cccc3b-b73f-47e2-b843-0511a45c66e2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783893993494	contact	4881617662073102521	Nguyễn Minh Tuan	Bộ thầy tế lên j ngon nhỉ	text	[]	f	\N	2026-05-02 10:40:34.292	\N	2026-05-02 10:40:34.589
c7e8e8bd-afef-489c-ba81-9ed55c5185f2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783894028510	contact	3540842572674797348	Tạ Gia Long	@Nguyễn Minh Tuan k nạp lấy đâu ra lắm nl phụ mà lên	text	[]	f	\N	2026-05-02 10:40:35.042	\N	2026-05-02 10:40:35.258
8f513fda-4d25-4498-95c8-31ad3c9d4b5e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783894556577	contact	4881617662073102521	Nguyễn Minh Tuan	@Tạ Gia Long tích sẵn thôi ôg	text	[]	f	\N	2026-05-02 10:40:46.792	\N	2026-05-02 10:40:47.036
734fb9d3-fc8b-49a6-a56e-f54fa3a09590	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783895090213	contact	4881617662073102521	Nguyễn Minh Tuan	Đập hộp dần	text	[]	f	\N	2026-05-02 10:40:58.547	\N	2026-05-02 10:40:58.862
ed5adbad-acdf-4016-a3df-4f68ae2143d7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783896011714	contact	4881617662073102521	Nguyễn Minh Tuan	Như cái kiếm rồng đủ nl phụ mà đợt k mua giờ k lên đc:))	text	[]	f	\N	2026-05-02 10:41:18.895	\N	2026-05-02 10:41:19.145
54b3d261-2b74-4955-9544-ed9e0e757f09	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783898714368	contact	3540842572674797348	Tạ Gia Long	t chơi hóa cốt chê kiếm rồng :)))	text	[]	f	\N	2026-05-02 10:42:18.982	\N	2026-05-02 10:42:19.29
2f5a4a65-b0e2-4757-a976-c86f746a4273	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783899240412	contact	3540842572674797348	Tạ Gia Long	hết chợ đc 35/36 tím ms lên vàng	text	[]	f	\N	2026-05-02 10:42:30.478	\N	2026-05-02 10:42:30.684
d94210ec-fdbb-4c44-a9eb-6008d700a5d4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783899378379	contact	3540842572674797348	Tạ Gia Long	{"id":45342,"catId":11901,"type":7}	sticker	[]	f	\N	2026-05-02 10:42:33.525	\N	2026-05-02 10:42:33.642
173a50d4-1830-4620-887f-333d61714cb3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783908881274	contact	4881617662073102521	Nguyễn Minh Tuan	Cố gồng v	text	[]	f	\N	2026-05-02 10:46:02.15	\N	2026-05-02 10:46:02.608
fc158b60-2534-434e-a49a-32a9c17560a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783910234390	contact	4881617662073102521	Nguyễn Minh Tuan	Mai khỏi mua búp bê quỷ	text	[]	f	\N	2026-05-02 10:46:31.698	\N	2026-05-02 10:46:31.982
b0581135-a97b-4824-8c35-5e76331270ec	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783940536411	contact	3540842572674797348	Tạ Gia Long	@Nguyễn Minh Tuan mua làm quái j	text	[]	f	\N	2026-05-02 10:57:32.289	\N	2026-05-02 10:57:32.68
1e3ffdc9-3309-4e9c-ad49-fba25d1ddd72	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783940819445	contact	3540842572674797348	Tạ Gia Long	đồ pet lam đủ dùng r	text	[]	f	\N	2026-05-02 10:57:38.439	\N	2026-05-02 10:57:38.642
486f7900-9bf2-43c0-91cb-04eeb8f07fcb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783962783819	contact	3391365375455109655	Huy	@Nguyễn Minh Tuan mua phí gem d ông:)	text	[]	f	\N	2026-05-02 11:05:28.705	\N	2026-05-02 11:05:29.135
9ec341c9-b71b-4d6f-a061-b9e601f30749	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783977054564	contact	7496477430098754831	Kenny Đại	@Nguyễn Minh Tuan ghê vậy	text	[]	f	\N	2026-05-02 11:10:37.756	\N	2026-05-02 11:10:38.18
bebd5d6b-4839-4059-8a5d-0b860f49930c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783977378415	contact	7496477430098754831	Kenny Đại	Búp bê mua chi	text	[]	f	\N	2026-05-02 11:10:44.75	\N	2026-05-02 11:10:44.954
ebb66d8d-3a4c-411a-b6af-740e62b96d34	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783984762620	contact	3540842572674797348	Tạ Gia Long	ngta giàu thì kệ đi	text	[]	f	\N	2026-05-02 11:13:26.573	\N	2026-05-02 11:13:26.992
6ea8d160-1ad6-403d-a4d3-f086f7fe395a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783985318918	contact	3540842572674797348	Tạ Gia Long	mình nghèo chưa đến chợ đã hết gem	text	[]	f	\N	2026-05-02 11:13:39.369	\N	2026-05-02 11:13:39.643
41e69475-e28d-4c6d-9af5-c64b96cac917	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783985775189	contact	3540842572674797348	Tạ Gia Long	kia đi sạch chợ túi vẫn rủng rỉnh	text	[]	f	\N	2026-05-02 11:13:48.901	\N	2026-05-02 11:13:49.12
52f693e0-9db5-4d42-b737-224ea26b9293	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783987135220	contact	8087701766132846650	Vũ Lộc	Từng kia gem mai là cạn	text	[]	f	\N	2026-05-02 11:14:18.276	\N	2026-05-02 11:14:18.725
99c22772-140f-4b3b-be6a-ba59ef2eb6f4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7783988561117	contact	3540842572674797348	Tạ Gia Long	@Vũ Lộc mua nửa chợ hết tiền :)))	text	[]	f	\N	2026-05-02 11:14:50.079	\N	2026-05-02 11:14:50.338
343746bf-d10c-4926-a21c-6a63b2f9f8a2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784014777402	contact	3343804879378568288	Ndh	Vậy mai vs mốt	text	[]	f	\N	2026-05-02 11:24:35.749	\N	2026-05-02 11:24:36.239
efafb009-3b2d-4e4c-9d56-f83acfca97f1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784015441815	contact	3343804879378568288	Ndh	Nạp gói quà phát triển để đổi đồ à anh trai	text	[]	f	\N	2026-05-02 11:24:50.54	\N	2026-05-02 11:24:50.798
9fa39a2c-cf65-4ebd-917b-cd321a6fd527	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784015570608	contact	3343804879378568288	Ndh	{"id":34839,"catId":11190,"type":3}	sticker	[]	f	\N	2026-05-02 11:24:53.431	\N	2026-05-02 11:24:53.57
3c014eb3-d1c6-4f06-8316-651896d4b8dc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784016558316	contact	3540842572674797348	Tạ Gia Long	hỏi ngta chứ t có gem đâu mà mua :))	text	[]	f	\N	2026-05-02 11:25:16.305	\N	2026-05-02 11:25:16.845
945d10e1-51c9-4986-89bb-7ed8edb185bb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784034422536	contact	4881617662073102521	Nguyễn Minh Tuan	@Vũ Lộc mua mớ đó gần 100k r:))	text	[]	f	\N	2026-05-02 11:31:43.607	\N	2026-05-02 11:31:44.084
bd7413c5-37c5-457b-b1e1-55132c18fd86	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784042175563	contact	3391365375455109655	Huy	@Nguyễn Minh Tuan r mai vs mốt lấy gì mua ông:)	text	[]	f	\N	2026-05-02 11:34:25.824	\N	2026-05-02 11:34:26.234
6d0f361e-4147-48d7-ac8b-ed3cbd40c815	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784091608961	contact	2226503885650453985	Nguyễn Thành	@Tạ Gia Long ko mua ấn sói à	text	[]	f	\N	2026-05-02 11:51:52.181	\N	2026-05-02 11:51:52.633
2e6de27c-257d-408d-83c9-ea14c0216673	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784095787594	contact	4881617662073102521	Nguyễn Minh Tuan	@Huy tính toán mua nguyên liệu chính	text	[]	f	\N	2026-05-02 11:53:21.232	\N	2026-05-02 11:53:21.778
51269659-8247-4e9c-a173-d8d6a231094d	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784099177563	contact	3391365375455109655	Huy	@Nguyễn Minh Tuan tập trung 1 set mix thôi:) r mua hết đống rương quyền lực là đẹp	text	[]	f	\N	2026-05-02 11:54:33.686	\N	2026-05-02 11:54:34.12
eb609024-2d56-4c3f-a4f9-7e7cf5466477	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784100166983	contact	3391365375455109655	Huy	Set khế hay gì nó tự lên tím vàng hết:) k cần phải mua ở chợ đâu	text	[]	f	\N	2026-05-02 11:54:54.847	\N	2026-05-02 11:54:55.085
0eebbf91-abc8-4ccf-a297-65fe7df9f524	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784122316436	contact	442684109737541411	Cường Tạ	{"title":"","description":"","href":"https://video-stal-4.dlmd.me/gr/15b339108c824ddc1493/pWF2AmF0GwAAAZ3okILPYWYAYXUCYXMaAFAlDA","thumb":"https://photo-stal-25.zdn.vn/gr/606bbda50837c9699026/2819132692122377283.jpg","childnumber":0,"action":"","params":"{\\"duration\\":32000,\\"is_group_layout\\":0,\\"video_original_width\\":480,\\"video_original_height\\":854,\\"video_width\\":480,\\"video_height\\":854,\\"video_rotation\\":0,\\"fileSize\\":5252364,\\"isHD\\":0}","type":""}	video	[]	f	\N	2026-05-02 12:02:41.906	\N	2026-05-02 12:02:42.338
8748de89-c1f8-45c4-bb26-31b53b8217d8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784297065928	contact	6562854816970626324	Đức Bình	Kiếm acc bay 13xx ae nhé	text	[]	f	\N	2026-05-02 13:02:20.938	\N	2026-05-02 13:02:21.375
4ba6d259-2e81-4149-8bae-82293dc2c652	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784306221119	contact	3874537684008431042	Trang Thành Lộc	;xx ;xx	text	[]	f	\N	2026-05-02 13:05:19.297	\N	2026-05-02 13:05:29.438
c32ab8f0-bd8d-4292-beee-7ec71b2d9fc3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784126786158	contact	7498720695294354711	Nguyễn Quốc Hữu	{"title":"","description":"","href":"https://photo-stal-25.zdn.vn/gr/jpg/887fbc5904cbc5959cda/3734726208909873930.jpg","thumb":"https://photo-stal-25.zdn.vn/gr/jpg/887fbc5904cbc5959cda/3734726208909873930.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-25.zdn.vn\\\\/gr\\\\/jpg\\\\/887fbc5904cbc5959cda\\\\/3734726208909873930.jpg\\",\\"width\\":2778,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-02 12:04:15.7	\N	2026-05-02 12:04:16.083
a323d1f6-bec5-4ab5-b4c6-f288cb2b4655	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784128708586	contact	7498720695294354711	Nguyễn Quốc Hữu	Chắc botcheck của khứa nào	text	[]	f	\N	2026-05-02 12:04:56.062	\N	2026-05-02 12:04:56.312
936a2d89-dec1-45ed-82b2-fdce499fafd8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784141283156	contact	3540842572674797348	Tạ Gia Long	@Nguyễn Thành tiền đâu	text	[]	f	\N	2026-05-02 12:09:20.767	\N	2026-05-02 12:09:21.14
c27da2c6-0815-4b6a-89a9-e70d8b6179cd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784141379140	contact	3540842572674797348	Tạ Gia Long	{"id":45356,"catId":11901,"type":3}	sticker	[]	f	\N	2026-05-02 12:09:22.784	\N	2026-05-02 12:09:22.895
b0105f3c-5f5d-4f34-81c9-34c48501da37	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784147859855	contact	4384990568718728157	Khủng Long Đỏ	@All  xe ONG CHÚA  1q5=2q4=1q4+3q3=6q3 out guil cũ và nộp đơn lên xe nhé ae	text	[]	f	\N	2026-05-02 12:11:39.584	\N	2026-05-02 12:11:40.132
fc5865b4-a09e-4ed2-a778-9a7178d96dde	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784149323222	contact	7998210325808057592	Khang Nguyễn	@Khủng Long Đỏ xe nào :)))	text	[]	f	\N	2026-05-02 12:12:10.623	\N	2026-05-02 12:12:11.075
ec0f1b3a-7000-4c6b-80b6-1838e9b1be23	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784150085276	contact	4384990568718728157	Khủng Long Đỏ	@Khang Nguyễn fom:)	text	[]	f	\N	2026-05-02 12:12:26.717	\N	2026-05-02 12:12:26.968
eeb132fe-bb2f-4a66-a50d-362e91c6d1c4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784150323426	contact	6554538239607812593	Triết	Xe ong chúa	text	[]	f	\N	2026-05-02 12:12:31.777	\N	2026-05-02 12:12:32.128
64189cb9-8e18-4faf-99d8-b6e1819e7f76	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784154917247	contact	2226503885650453985	Nguyễn Thành	@Tạ Gia Long Ko có tiền mới phải mua đó, ko có ấn sói kiếm điểm hỗn độn khó	text	[]	f	\N	2026-05-02 12:14:08.605	\N	2026-05-02 12:14:09.041
d7287aa1-5ffc-44a8-b5bd-ed7cf634e7df	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784185787570	contact	3534643548480446730	Trương Đức Tính	{"title":"","description":"","href":"https://f64-zpg-r.zdn.vn/jpg/1768760787802137247/1843e6700473852ddc62.jpg","thumb":"https://f64-zpg-r.zdn.vn/jpg/1768760787802137247/1843e6700473852ddc62.jpg","childnumber":0,"action":"","params":"{\\"thumb_height\\":693,\\"convertible\\":\\"jxl\\",\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"width\\":1170,\\"height\\":2532,\\"thumb_width\\":320}","type":""}	image	[]	f	\N	2026-05-02 12:24:57.172	\N	2026-05-02 12:24:57.692
5c64ef49-964d-4f2f-a113-0017bcd608fe	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784186210302	contact	2032429908843083059	Yangb	{"title":"","description":"","href":"https://photo-stal-28.zdn.vn/gr/jpg/d69e9e907f02be5ce713/173196396795747578.jpg","thumb":"https://photo-stal-28.zdn.vn/gr/jpg/d69e9e907f02be5ce713/173196396795747578.jpg","childnumber":0,"action":"","params":"{\\"width\\":2400,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-28.zdn.vn\\\\/gr\\\\/jpg\\\\/d69e9e907f02be5ce713\\\\/173196396795747578.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000375502\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 12:25:05.964	\N	2026-05-02 12:25:06.358
fdf7ed6a-e2e5-49d1-aac9-e1adbf9d857c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784186376365	contact	2032429908843083059	Yangb	1379	text	[]	f	\N	2026-05-02 12:25:09.383	\N	2026-05-02 12:25:09.505
a1ab7168-3a38-42cf-9d03-6473c96a1927	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784197866359	contact	1851864074683856820	Đxn	{"title":"","description":"","href":"https://photo-stal-35.zdn.vn/gr/jpg/017d34ec2371e22fbb60/1879285424321135016.jpg","thumb":"https://photo-stal-35.zdn.vn/gr/jpg/017d34ec2371e22fbb60/1879285424321135016.jpg","childnumber":0,"action":"","params":"{\\"width\\":2316,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-35.zdn.vn\\\\/gr\\\\/jpg\\\\/017d34ec2371e22fbb60\\\\/1879285424321135016.jpg\\",\\"is_group_layout\\":0,\\"contentId\\":\\"1000005859\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 12:29:08.924	\N	2026-05-02 12:29:09.374
cca2c1de-6c08-4c62-8b4b-4332017b7ce4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784198162421	contact	1851864074683856820	Đxn	Bú hehe	text	[]	f	\N	2026-05-02 12:29:15.15	\N	2026-05-02 12:29:15.336
a5f6526e-0f81-4502-9753-fe34da974de8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784198364242	contact	7498720695294354711	Nguyễn Quốc Hữu	@Đxn xứng đáng zero	text	[]	f	\N	2026-05-02 12:29:19.314	\N	2026-05-02 12:29:19.759
87960500-0d68-4650-9a8e-d12818da3a49	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784213095567	contact	262937886851184801	Thu Phan	{"title":"","description":"","href":"https://photo-stal-9.zdn.vn/gr/jpg/6900a14fa3d2628c3bc3/676090054508309556.jpg","thumb":"https://photo-stal-9.zdn.vn/gr/jpg/6900a14fa3d2628c3bc3/676090054508309556.jpg","childnumber":0,"action":"","params":"{\\"width\\":1908,\\"height\\":858,\\"is_group_layout\\":0,\\"contentId\\":\\"26297\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 12:34:23.827	\N	2026-05-02 12:34:24.288
e6dce54e-c478-403b-a0c9-700a00ee0ede	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784213848671	contact	262937886851184801	Thu Phan	Off mấy h mà nó solo t luôn	text	[]	f	\N	2026-05-02 12:34:39.347	\N	2026-05-02 12:34:39.585
c280cfaa-b257-4148-93b3-0399393d4441	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784222437936	contact	7387240757415509891	Trần Thoại	A zai chịu đau dữ quá	text	[]	f	\N	2026-05-02 12:37:35.834	\N	2026-05-02 12:37:36.232
2e850735-d1f8-4391-8a88-2d7507129535	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784250020371	contact	3540842572674797348	Tạ Gia Long	@Thu Phan zero r à	text	[]	f	\N	2026-05-02 12:46:53.082	\N	2026-05-02 12:46:53.544
c9ce2155-8d46-4d16-8411-4ea635720ffa	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784266802396	contact	8087701766132846650	Vũ Lộc	@Thu Phan might bao nhiêu mà nó solo vậy	text	[]	f	\N	2026-05-02 12:52:27.317	\N	2026-05-02 12:52:27.749
ce9e480e-2e9c-4d6a-be8d-28c5b25dadd9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784281760250	contact	585801465063846950	Võ Vũ Nam 武武南	Kiếm rồng 12	text	[]	f	\N	2026-05-02 12:57:22.716	\N	2026-05-02 12:57:23.101
7f332fef-39a3-460c-ac61-2ef8b0fdf0c7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784281960839	contact	585801465063846950	Võ Vũ Nam 武武南	H mũ cốt mới vàng	text	[]	f	\N	2026-05-02 12:57:26.741	\N	2026-05-02 12:57:26.856
2ed7f6b9-16c5-4d40-906b-8e68e5fb9e75	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784282051063	contact	585801465063846950	Võ Vũ Nam 武武南	Cmn :))	text	[]	f	\N	2026-05-02 12:57:28.467	\N	2026-05-02 12:57:28.618
d9b94bb8-07f3-4c46-94d4-1cbc04ae90cd	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784283278827	contact	4881617662073102521	Nguyễn Minh Tuan	Ghê	text	[]	f	\N	2026-05-02 12:57:52.631	\N	2026-05-02 12:57:53.082
43acbb76-72b9-415a-8904-0a69ff3fd069	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784284606605	contact	585801465063846950	Võ Vũ Nam 武武南	Mũ ong sắp vàng tới	text	[]	f	\N	2026-05-02 12:58:18.701	\N	2026-05-02 12:58:18.977
99fe0d15-7233-417e-bd20-da02bd520121	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784285848805	contact	585801465063846950	Võ Vũ Nam 武武南	Xog chợ 1 vàng nx lên vàng luôn	text	[]	f	\N	2026-05-02 12:58:43.123	\N	2026-05-02 12:58:43.463
58e7947c-c45c-4ca9-bf39-c7d78653eee3	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784309926851	contact	7387240757415509891	Trần Thoại	@Đức Bình tìm như nào	text	[]	f	\N	2026-05-02 13:06:31.613	\N	2026-05-02 13:06:32.021
53f8fe3f-2bff-47a8-ab7b-e58cd4043e64	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784310152522	contact	7387240757415509891	Trần Thoại	Acc join t5 đc k	text	[]	f	\N	2026-05-02 13:06:36.01	\N	2026-05-02 13:06:36.263
c76ab268-7bfe-4a8a-9739-eb45da8fe042	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784315518144	contact	7387240757415509891	Trần Thoại	{"title":"","description":"","href":"https://photo-stal-2.zdn.vn/gr/jpg/9cad14e6967b57250e6a/2550380592467220280.jpg","thumb":"https://photo-stal-2.zdn.vn/gr/jpg/9cad14e6967b57250e6a/2550380592467220280.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":1,\\"group_layout_id\\":1777727300443,\\"id_in_group\\":0,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000054737\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 13:08:20.955	\N	2026-05-02 13:08:21.204
13e16aae-0ea2-4af6-8b39-80fa3df4f178	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784315531468	contact	7387240757415509891	Trần Thoại	{"title":"","description":"","href":"https://photo-stal-19.zdn.vn/gr/jpg/331f0d528fcf4e9117de/1395661825709217845.jpg","thumb":"https://photo-stal-19.zdn.vn/gr/jpg/331f0d528fcf4e9117de/1395661825709217845.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":1,\\"group_layout_id\\":1777727300443,\\"id_in_group\\":1,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000054738\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 13:08:21.187	\N	2026-05-02 13:08:21.305
b64c53d8-f72f-4c39-a5cb-552b651fed2e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784316117842	contact	7387240757415509891	Trần Thoại	Bay đc 1k47x 150k	text	[]	f	\N	2026-05-02 13:08:32.665	\N	2026-05-02 13:08:32.929
5538da4d-8726-498c-9f0f-b40adddf6da6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784411969029	contact	305746081800824633	Thịnh	ai bán mấy con clone nhiều gem ko	text	[]	f	\N	2026-05-02 13:39:47.709	\N	2026-05-02 13:39:48.169
ad281ba5-6088-4a1e-b273-10c7627ce1cf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784421441753	contact	7387240757415509891	Trần Thoại	Mua mấy acc bot 150k ông tính kìa	text	[]	f	\N	2026-05-02 13:42:54.419	\N	2026-05-02 13:42:54.863
5caf9012-2cb8-4a98-bae4-d15210ad6019	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784425262965	contact	792834338766427655	Lưu Văn Duy	@Thịnh acc 600-700k gems dc k	text	[]	f	\N	2026-05-02 13:44:09.969	\N	2026-05-02 13:44:10.434
619e95c9-507b-4125-8220-a878c3ec737f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784428471693	contact	3534643548480446730	Trương Đức Tính	@Trần Thoại đúng đúng , quá ngon :))	text	[]	f	\N	2026-05-02 13:45:13.6	\N	2026-05-02 13:45:13.986
175e1601-7caa-4e57-aee9-805b83e27255	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784431423855	contact	7387240757415509891	Trần Thoại	{"id":46953,"catId":12002,"type":3}	sticker	[]	f	\N	2026-05-02 13:46:11.455	\N	2026-05-02 13:46:11.751
cacb1f02-8ae7-4374-9977-5dfe481ac18c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784466158804	contact	3564335989560761200	Phạm Anh	Nếu bị tấn công 947 thì thủ tỷ lệ nào được mn nhỉ? Cho xin ý kiến với	text	[]	f	\N	2026-05-02 13:57:38.08	\N	2026-05-02 13:57:38.504
2f9b24db-ef99-4304-bed4-432a6a3f40f9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784472808493	contact	4881617662073102521	Nguyễn Minh Tuan	ct bộ luôn:D	text	[]	f	\N	2026-05-02 13:59:50.105	\N	2026-05-02 13:59:50.553
e8571c69-8f11-457d-a1f4-6385d2bba683	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784473141247	contact	585801465063846950	Võ Vũ Nam 武武南	Khó	text	[]	f	\N	2026-05-02 13:59:55.937	\N	2026-05-02 13:59:56.286
715b03f1-3899-482c-b6bf-799f6925f3ef	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784473346971	contact	585801465063846950	Võ Vũ Nam 武武南	Trừ khi nó k chống	text	[]	f	\N	2026-05-02 13:59:59.997	\N	2026-05-02 14:00:00.147
85311912-3d6d-44bd-b354-19fd2ecbd187	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784474379989	contact	585801465063846950	Võ Vũ Nam 武武南	Bác hỏi z chỉ khi có spy báo tỉ lệ bác khắc tỉ lệ đó th	text	[]	f	\N	2026-05-02 14:00:20.056	\N	2026-05-02 14:00:20.317
3028a94a-23d9-4858-b95f-ed203d7688c8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784477124775	contact	3564335989560761200	Phạm Anh	Hihi mình ko rành thật, 947 mới def đi gần hết dàn bộ	text	[]	f	\N	2026-05-02 14:01:13.228	\N	2026-05-02 14:01:13.758
2e96665a-ce14-4312-a696-6095bee997a2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784477951053	contact	3564335989560761200	Phạm Anh	Hỏi để kinh nghiệm lần tới	text	[]	f	\N	2026-05-02 14:01:29.447	\N	2026-05-02 14:01:29.73
c296c521-f3bd-4374-8bd7-d56c15ad85e7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784482650518	contact	7387240757415509891	Trần Thoại	Pt cung	text	[]	f	\N	2026-05-02 14:03:01.7	\N	2026-05-02 14:03:02.163
f8929d8f-438f-4a63-a07e-e6a3932e5850	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784482977999	contact	7387240757415509891	Trần Thoại	Hay ct cung cx đc:))	text	[]	f	\N	2026-05-02 14:03:08.143	\N	2026-05-02 14:03:08.37
9b063719-27b7-4973-b42e-3da0672fcc56	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784483193144	contact	7387240757415509891	Trần Thoại	Nhưng hơi đau	text	[]	f	\N	2026-05-02 14:03:12.426	\N	2026-05-02 14:03:12.623
408a8536-f12e-4ca4-9054-bd4afed7578c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784490505912	contact	4881617662073102521	Nguyễn Minh Tuan	@Phạm Anh nó đi trận j bác	text	[]	f	\N	2026-05-02 14:05:37.314	\N	2026-05-02 14:05:37.697
314e3f55-4965-427d-9083-38bb2d4da646	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784492274450	contact	4881617662073102521	Nguyễn Minh Tuan	lên dày bộ cung def ct bộ thôi:D	text	[]	f	\N	2026-05-02 14:06:11.712	\N	2026-05-02 14:06:11.952
42561b41-67f7-4050-bccd-442fd94199ec	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784507951077	contact	3564335989560761200	Phạm Anh	@Nguyễn Minh Tuan bộ bác	text	[]	f	\N	2026-05-02 14:11:22.984	\N	2026-05-02 14:11:23.418
d43cb4d5-36b6-43b3-96f2-def6daccc883	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784509252831	contact	3564335989560761200	Phạm Anh	Ct bộ	text	[]	f	\N	2026-05-02 14:11:48.99	\N	2026-05-02 14:11:49.215
ef52d257-a4d5-49c4-a07a-48356abb012b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784510714349	contact	3564335989560761200	Phạm Anh	@Nguyễn Minh Tuan nếu quay def trận kỵ	text	[]	f	\N	2026-05-02 14:12:18.214	\N	2026-05-02 14:12:18.523
27386d81-6ee1-4a44-ac48-0766f423c396	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784511104077	contact	3564335989560761200	Phạm Anh	Thì ntn bác nhỉ	text	[]	f	\N	2026-05-02 14:12:25.995	\N	2026-05-02 14:12:26.308
3d8bbe3b-65ed-46d7-b43d-4ab082dc0e80	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784512087222	contact	3564335989560761200	Phạm Anh	@Nguyễn Minh Tuan vậy chỉ có lên dầy bộ cung thôi hả bác	text	[]	f	\N	2026-05-02 14:12:45.725	\N	2026-05-02 14:12:45.976
de6b5b3b-1f33-4f51-81d1-362f8d6d378c	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784512913972	contact	4881617662073102521	Nguyễn Minh Tuan	@Phạm Anh có điều kiện cứ nhiều lính là tốt:))	text	[]	f	\N	2026-05-02 14:13:02.847	\N	2026-05-02 14:13:03.29
75f5abf3-b339-4047-9c85-7855b76ae6e8	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784517114055	contact	3429230737531381136	Nguyễn Nhật Tân	Stt nhóm tên đề tài giang viên hướng dẫn nếu t nhớ ko lầm	text	[]	f	\N	2026-05-02 14:14:26.169	\N	2026-05-02 14:14:26.602
fdf34123-0c5a-4a13-a51d-0ac1f6335f9a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784517168011	contact	3564335989560761200	Phạm Anh	@Nguyễn Minh Tuan nhiều tầm bn bác nhỉ? T4 mỗi loại tầm bn và t2	text	[]	f	\N	2026-05-02 14:14:27.246	\N	2026-05-02 14:14:27.395
b9b2708c-ba0f-4502-9b5e-b7f827957fab	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784519862933	contact	3429230737531381136	Nguyễn Nhật Tân	M coi xem tụi nó nộp file tên gì ko hỏi bả lun cho chắc hỏi lun mình làm đơn tốt nghiệp lấy ở đâu nộp ở đâu lun	text	[]	f	\N	2026-05-02 14:15:21.098	\N	2026-05-02 14:15:21.312
9ddc5e0c-bcee-4462-9063-18d5dfd75cda	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784521277597	contact	4881617662073102521	Nguyễn Minh Tuan	mấy idol trap rally đâu rùi, vô tư vấn nè @@	text	[]	f	\N	2026-05-02 14:15:49.649	\N	2026-05-02 14:15:49.924
a83b2e07-0640-4445-b590-db6710655d73	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784522840691	contact	4579632439414729865	Tungthanh	{"id":46953,"catId":12002,"type":3}	sticker	[]	f	\N	2026-05-02 14:16:20.49	\N	2026-05-02 14:16:20.928
a9eb04ac-ab8b-4f62-a11e-cd5ccbfeaaab	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784523490755	contact	4579632439414729865	Tungthanh	chưa bị đấm nên chưa tư vấn đc	text	[]	f	\N	2026-05-02 14:16:33.585	\N	2026-05-02 14:16:33.859
65516abc-86a8-4019-825d-b53fcbff22c6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784523690616	contact	4579632439414729865	Tungthanh	kêu nó đấm t phát	text	[]	f	\N	2026-05-02 14:16:37.621	\N	2026-05-02 14:16:37.754
710057d5-ad97-43c9-8e34-aeae3d029ed0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784524001903	contact	4579632439414729865	Tungthanh	def xong tư vấn cho	text	[]	f	\N	2026-05-02 14:16:43.882	\N	2026-05-02 14:16:44.121
07c7f7d4-4918-40f8-baec-d35a275bbdf4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784527157069	contact	3391365375455109655	Huy	@Phạm Anh cung	text	[]	f	\N	2026-05-02 14:17:47.466	\N	2026-05-02 14:17:47.923
66ccf2f1-5198-4b89-b66e-2a04e79d4db1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784527990257	contact	3391365375455109655	Huy	Cubg ngon nhất	text	[]	f	\N	2026-05-02 14:18:04.25	\N	2026-05-02 14:18:04.453
ca384037-d762-4057-923d-0fd154eb4077	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784528537334	contact	3429230737531381136	Nguyễn Nhật Tân	Thì đó sst nhóm tên đề tài giảng viên hướng dẫn t nhớ mang máng thôi nha	text	[]	f	\N	2026-05-02 14:18:15.339	\N	2026-05-02 14:18:15.547
406a3034-3d06-4ac1-98a6-f5ed84d1e1b9	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784530557393	contact	3429230737531381136	Nguyễn Nhật Tân	Sao lại là t	text	[]	f	\N	2026-05-02 14:18:56.216	\N	2026-05-02 14:18:56.4
a84a775d-387e-4f92-b78a-bb584f096e16	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784531486586	contact	3429230737531381136	Nguyễn Nhật Tân	Cả 3 tk chịu	text	[]	f	\N	2026-05-02 14:19:14.896	\N	2026-05-02 14:19:15.142
ec614d1a-c701-4158-bee3-97b09898a6d0	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784533440983	contact	3429230737531381136	Nguyễn Nhật Tân	T có kêu đâu m hỏi t trl mà	text	[]	f	\N	2026-05-02 14:19:54.363	\N	2026-05-02 14:19:54.734
b437d7a3-ecf7-44cb-82f0-9bb5ae7cd921	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784534426130	contact	3429230737531381136	Nguyễn Nhật Tân	Hỏi bà nhường đi bả trl à sẵn hỏi này lun	text	[]	f	\N	2026-05-02 14:20:14.22	\N	2026-05-02 14:20:14.422
426e0aab-4aa0-449b-8078-f4a614d9d11e	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784538066210	contact	3429230737531381136	Nguyễn Nhật Tân	Sợ chứ chưa ra mà khi nào ra rồi muốn làm gì làm	text	[]	f	\N	2026-05-02 14:21:27.911	\N	2026-05-02 14:21:28.111
9219e8c9-eb2c-4f79-aace-508cea508f50	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784541510385	contact	3429230737531381136	Nguyễn Nhật Tân	Thì nộp phải đàng hoàng chứ m mik có biết điểm bao nhiêu đâu nó trừ sao mình biết đc	text	[]	f	\N	2026-05-02 14:22:37.821	\N	2026-05-02 14:22:38.029
3c4aef73-c521-472d-8144-94fdff24f850	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784544084651	contact	3429230737531381136	Nguyễn Nhật Tân	Nhét đc 100 trang ko hiệp:))	text	[]	f	\N	2026-05-02 14:23:30.032	\N	2026-05-02 14:23:30.244
17d2ec2c-1ef7-42dc-b3fc-c3dff4acdc16	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784546217356	contact	3429230737531381136	Nguyễn Nhật Tân	Thôi qua chỉ tiêu đc rồi	text	[]	f	\N	2026-05-02 14:24:13.405	\N	2026-05-02 14:24:13.626
c3caf84f-75e6-4440-a282-3158fd6795aa	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784549217018	contact	3429230737531381136	Nguyễn Nhật Tân	Ủa ổng gửi hả tưởng mình gửi zo file gì của bà nhường chứ	text	[]	f	\N	2026-05-02 14:25:14.291	\N	2026-05-02 14:25:14.695
f3751b86-aad8-430a-a1a0-24462cd4fe8b	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784552781061	contact	3429230737531381136	Nguyễn Nhật Tân	{"title":"Agentic_AI_Supply_Chain_Risk_Analysis_(6).pptx","description":"","href":"https://file-stal-1006.dlfl.vn/gr/0dc578e2d37e12204b6f/4279214103631374125","thumb":"","childnumber":0,"action":"","params":"{\\"fileSize\\":\\"165309456\\", \\"checksum\\":\\"1378024f5d9cfc69a61e4b5922b97b5b\\", \\"checksumSha\\":\\"null\\", \\"fileExt\\":\\"pptx\\", \\"fdata\\":\\"{}\\", \\"fType\\":1}","type":""}	file	[]	f	\N	2026-05-02 14:26:27.562	\N	2026-05-02 14:26:27.733
b53a971f-3432-4148-bbd5-5d231d6bdc61	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784554267024	contact	3429230737531381136	Nguyễn Nhật Tân	@Trần Nghĩa Hiệp m cũng phải kêu ổng nhận xét lun để ổng gửi ko	text	[]	f	\N	2026-05-02 14:26:57.766	\N	2026-05-02 14:26:57.92
66658150-8379-47a2-81ff-cd7c7b8801fd	fc2b1261-c3eb-4d1e-9453-162126f5e2d9	7784555412700	contact	3429230737531381136	Nguyễn Nhật Tân	ủa có kêu z hả ta ko nhớ gì hết lun á	text	[]	f	\N	2026-05-02 14:27:21.529	\N	2026-05-02 14:27:21.794
4f27272a-1b70-4493-8c13-df744d5eb472	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784683444817	contact	2320230736563113524	Lương Minh Khoa	bác cứ bộ cho em	text	[]	f	\N	2026-05-02 15:13:20.096	\N	2026-05-02 15:13:20.503
af833a9f-fd86-4c3c-938d-46f9156acaaf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784684257382	contact	7498720695294354711	Nguyễn Quốc Hữu	Atk cung cao thì lợi mà	text	[]	f	\N	2026-05-02 15:13:38.532	\N	2026-05-02 15:13:38.873
c6a81830-a7bb-4b90-8f5b-180ccef16367	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784684893796	contact	7498720695294354711	Nguyễn Quốc Hữu	Bộ thì dễ bị về	text	[]	f	\N	2026-05-02 15:13:53.127	\N	2026-05-02 15:13:53.408
37b426a0-3e28-464b-b4d9-4a23f8462da9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784734982102	contact	826306325505433968	Nana	{"title":"","description":"","href":"https://photo-stal-29.zdn.vn/gr/jpg/ddadb310338ff2d1ab9e/2185210549462401121.jpg","thumb":"https://photo-stal-29.zdn.vn/gr/jpg/ddadb310338ff2d1ab9e/2185210549462401121.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":0,\\"contentId\\":\\"24174\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 15:34:24.126	\N	2026-05-02 15:34:24.56
2e29a717-3307-429a-af9a-3c7c1198640e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784735807673	contact	826306325505433968	Nana	K có nhà ở mn ai cho e tá túc với	text	[]	f	\N	2026-05-02 15:34:46.472	\N	2026-05-02 15:34:46.758
b9018cd6-c141-4eaa-bf27-be9c3e24dbbe	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784737649918	contact	826306325505433968	Nana	{"title":"","description":"","href":"https://photo-stal-15.zdn.vn/gr/jpg/1d54b7b23a2dfb73a23c/1765781565298146756.jpg","thumb":"https://photo-stal-15.zdn.vn/gr/jpg/1d54b7b23a2dfb73a23c/1765781565298146756.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":0,\\"contentId\\":\\"24172\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 15:35:36.449	\N	2026-05-02 15:35:36.692
5ad82c0d-e51b-42ce-b9d1-710b578270e2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784737986479	contact	826306325505433968	Nana	Bị khóa tiếng	text	[]	f	\N	2026-05-02 15:35:45.675	\N	2026-05-02 15:35:45.919
334ce25f-528b-4ed2-bab5-44c5be5134ea	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784738369719	contact	826306325505433968	Nana	😢	text	[]	f	\N	2026-05-02 15:35:56.178	\N	2026-05-02 15:35:56.379
1e079979-57d3-4733-bf0a-e5b256a351a7	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784739516098	contact	386507739282916698	Tuấn Peodethuong	Thì ibox bọn cskh, bọn nó mở lại cho	text	[]	f	\N	2026-05-02 15:36:27.369	\N	2026-05-02 15:36:27.811
29aa5778-c842-4f12-8d1b-ba30a0b9a6d8	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784743572082	contact	8395788325665172100	Lê Quang Long	Thấy cũng bị khóa, r ibox kêu mở nma 2 lần r, đều k dc, chán chả thèm nt, nó khóa 5 ngày xg mở lại bt thôi @@	text	[]	f	\N	2026-05-02 15:38:18.598	\N	2026-05-02 15:38:19.031
02863aac-50d0-465c-ba41-899f60e3f530	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784743894187	contact	386507739282916698	Tuấn Peodethuong	Bần đạo còn spam hoàng sa trường sa lên game, xong còn bị báo cấm mõm vĩnh viễn cơ mà	text	[]	f	\N	2026-05-02 15:38:27.497	\N	2026-05-02 15:38:27.778
bb788ee1-24a0-44a7-898b-1eb75a66f42e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784745071883	contact	386507739282916698	Tuấn Peodethuong	Bị ban mồm, xong nt spam mãi, nó mới mở	text	[]	f	\N	2026-05-02 15:39:00.173	\N	2026-05-02 15:39:00.414
db63bd55-36a2-471e-b5cc-0cd8cbb7ddf9	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784745549469	contact	386507739282916698	Tuấn Peodethuong	Bắt cam kết ko chính trị các kiểu	text	[]	f	\N	2026-05-02 15:39:13.402	\N	2026-05-02 15:39:13.611
44c70ad5-d125-413b-9856-949889924b12	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784750773250	contact	8395788325665172100	Lê Quang Long	À là cứ lì mặt scam là mở cho t, nhiều lần là dc hả, +1 kiến thức kk	text	[]	f	\N	2026-05-02 15:41:39.234	\N	2026-05-02 15:41:39.537
998ac56a-2ce8-4ef4-bfdf-6c4c3951e8ad	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784752507649	contact	2320230736563113524	Lương Minh Khoa	@Nana  bang nông dân bb5 nhé bác,ko cần di trú	text	[]	f	\N	2026-05-02 15:42:27.535	\N	2026-05-02 15:42:27.943
054641f9-1ec6-4a5b-aff3-6298b47fe406	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784752933381	contact	2320230736563113524	Lương Minh Khoa	nhắn r5 cho em	text	[]	f	\N	2026-05-02 15:42:39.745	\N	2026-05-02 15:42:39.974
bfe25516-d3e2-4d39-b485-69dfc3335e58	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784759684606	contact	826306325505433968	Nana	@Lương Minh Khoa có ngừi nt rùi	text	[]	f	\N	2026-05-02 15:45:50.962	\N	2026-05-02 15:45:51.358
6eadd6d8-2292-4226-9e50-d2b8ff94955f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784760082428	contact	826306325505433968	Nana	{"title":"","description":"","href":"https://photo-stal-35.zdn.vn/gr/jpg/a76b6168d8f719a940e6/948763708029986763.jpg","thumb":"https://photo-stal-35.zdn.vn/gr/jpg/a76b6168d8f719a940e6/948763708029986763.jpg","childnumber":0,"action":"","params":"{\\"width\\":1884,\\"height\\":869,\\"is_group_layout\\":0,\\"contentId\\":\\"24178\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 15:46:02.219	\N	2026-05-02 15:46:02.591
b305d5f3-db71-41dc-88c2-5d8d8b1d0087	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784760557846	contact	826306325505433968	Nana	Đồ hơi cùi may ngừi ta nhận	text	[]	f	\N	2026-05-02 15:46:15.828	\N	2026-05-02 15:46:16.09
f7f794a4-9750-467e-8e03-9e0a78fcb7f6	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784771134591	contact	826306325505433968	Nana	@Lương Minh Khoa cảm ơn nhớ mốt bị đủi em wa	text	[]	f	\N	2026-05-02 15:51:23.957	\N	2026-05-02 15:51:24.426
a454f073-00d7-4bfc-9837-d9d4901dcebf	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784771651519	contact	2320230736563113524	Lương Minh Khoa	Đồ này trâu quá	text	[]	f	\N	2026-05-02 15:51:39.196	\N	2026-05-02 15:51:39.58
af72d175-def3-4e9f-8083-ed2b9b8f02a2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784775847605	contact	826306325505433968	Nana	@Lương Minh Khoa tại ở mấy bang khác r4 nt riêng mà acc e bị khóa sao rep đc	text	[]	f	\N	2026-05-02 15:53:43.802	\N	2026-05-02 15:53:44.076
408b9817-d29d-42d1-94b3-b3d990b40487	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784776222798	contact	3391365375455109655	Huy	@Nana king nào d b	text	[]	f	\N	2026-05-02 15:53:55.061	\N	2026-05-02 15:53:55.486
f1b3cdbe-8f94-4b45-9659-712f49b37ead	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784776236428	contact	826306325505433968	Nana	Z là họ đủi	text	[]	f	\N	2026-05-02 15:53:55.518	\N	2026-05-02 15:53:55.649
60d6c90d-98d4-41db-a8fa-260dcf85a7b0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784776733921	contact	826306325505433968	Nana	@Huy 1631 thì phải	text	[]	f	\N	2026-05-02 15:54:10.403	\N	2026-05-02 15:54:10.627
a4ab04c1-c6d4-458b-8c7b-24259f214cf4	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784776973403	contact	826306325505433968	Nana	Mới di trú xuống	text	[]	f	\N	2026-05-02 15:54:17.494	\N	2026-05-02 15:54:17.728
85fbaa80-770d-4c38-aeab-7fe5c9c87d29	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784777792650	contact	826306325505433968	Nana	Acc e bị khóa tiếng nên on mà mn hỏi k trả lời	text	[]	f	\N	2026-05-02 15:54:42.001	\N	2026-05-02 15:54:42.244
6d0437f5-3b27-44a2-ade6-814266c92d80	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784778061443	contact	826306325505433968	Nana	Họ kích liền á	text	[]	f	\N	2026-05-02 15:54:50.036	\N	2026-05-02 15:54:50.41
85b80827-3a5f-43bd-9144-df7d8f376d5f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784781245709	contact	4881617662073102521	Nguyễn Minh Tuan	@Nana xịn thế mà	text	[]	f	\N	2026-05-02 15:56:25.105	\N	2026-05-02 15:56:25.54
b987ea5b-d6ce-4cb5-a050-708a861a5588	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784781638537	contact	826306325505433968	Nana	@Nguyễn Minh Tuan nhưng k chát đc	text	[]	f	\N	2026-05-02 15:56:36.926	\N	2026-05-02 15:56:37.26
888cdb94-c4cc-4daf-b6c7-f30e9103a7d5	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784782441799	contact	826306325505433968	Nana	Ở bang nào cũng bị đủi tại vì k trả lời	text	[]	f	\N	2026-05-02 15:57:00.86	\N	2026-05-02 15:57:01.111
f575c5f5-9e1e-475f-9745-440e9d3edc4e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784783165485	contact	826306325505433968	Nana	Acc e trap nữa	text	[]	f	\N	2026-05-02 15:57:22.751	\N	2026-05-02 15:57:23.03
f9e8c52d-316a-4186-bd98-d17e7c2c4e27	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784783450949	contact	826306325505433968	Nana	Chỉ def vs join lính	text	[]	f	\N	2026-05-02 15:57:31.292	\N	2026-05-02 15:57:31.5
e634ad0c-1eec-4db8-99e5-91642d506936	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784784260297	contact	826306325505433968	Nana	Từ 17xx đi xuống 16xx	text	[]	f	\N	2026-05-02 15:57:55.769	\N	2026-05-02 15:57:56.05
cb8b97ff-0e3e-4fa4-b5e6-ac3a37337f04	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784784375971	contact	4881617662073102521	Nguyễn Minh Tuan	K nhắn đỡ bị bot check	text	[]	f	\N	2026-05-02 15:57:59.317	\N	2026-05-02 15:57:59.46
7b362d16-c0f6-4021-afba-89a25e40a449	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784784809084	contact	2320230736563113524	Lương Minh Khoa	mục đích chính	text	[]	f	\N	2026-05-02 15:58:12.443	\N	2026-05-02 15:58:12.839
b317efdf-fda1-4d7a-92e3-e0157ca9cef0	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784784926756	contact	4881617662073102521	Nguyễn Minh Tuan	Gửi thư riêng thì có đc k	text	[]	f	\N	2026-05-02 15:58:15.915	\N	2026-05-02 15:58:16.058
96c49bf5-9825-4033-8e22-29968fb05345	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784785250369	contact	826306325505433968	Nana	K chat đc	text	[]	f	\N	2026-05-02 15:58:25.841	\N	2026-05-02 15:58:26.124
8edfc28e-6ece-4dd5-b177-a1d352c27672	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784785299243	contact	2320230736563113524	Lương Minh Khoa	chắc nhắn riêng zalo dx	text	[]	f	\N	2026-05-02 15:58:27.467	\N	2026-05-02 15:58:27.577
a735c304-ee79-4609-91d1-9715780343aa	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784785574253	contact	826306325505433968	Nana	@Lương Minh Khoa đr	text	[]	f	\N	2026-05-02 15:58:35.677	\N	2026-05-02 15:58:35.897
c98dd455-0e07-4533-a979-75701e8ffa93	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784785597970	contact	2320230736563113524	Lương Minh Khoa	chỉ sợ vợ thôi	text	[]	f	\N	2026-05-02 15:58:36.704	\N	2026-05-02 15:58:36.822
27d8779c-d9fe-4d29-8826-861581e89bd2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784786864153	contact	826306325505433968	Nana	E nhìu nhóm nên k tiện vào nhóm bang	text	[]	f	\N	2026-05-02 15:59:15.126	\N	2026-05-02 15:59:15.356
313e2fd0-f595-4c02-846a-b9b5971457fb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784786910104	contact	2320230736563113524	Lương Minh Khoa	như vậy, sẽ cần 1 acc khác cùng kênh, để biết ?	text	[]	f	\N	2026-05-02 15:59:16.715	\N	2026-05-02 15:59:16.835
77a82013-617d-428c-868b-9a4e095c6e5b	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784803124364	contact	386507739282916698	Tuấn Peodethuong	@Nana đồ này là ổn rồi, nhưng kể cả có là đế mà ko mở mồm đc thì cũng bye bye	text	[]	f	\N	2026-05-02 16:07:45.68	\N	2026-05-02 16:07:46.147
028fdf46-f1a5-4e82-a6cd-ce47b1f281fc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784803301766	contact	386507739282916698	Tuấn Peodethuong	{"id":30809,"catId":10961,"type":3}	sticker	[]	f	\N	2026-05-02 16:07:51.39	\N	2026-05-02 16:07:51.609
b63638e5-88da-4aa6-9c43-8462b210e99f	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784804154341	contact	1453308858166125100	Phú Nguyễn	{"title":"","description":"","href":"https://photo-stal-3.zdn.vn/gr/jpg/b76234ac6733a66dff22/211260925237182644.jpg","thumb":"https://photo-stal-3.zdn.vn/gr/jpg/b76234ac6733a66dff22/211260925237182644.jpg","childnumber":0,"action":"","params":"{\\"width\\":2460,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-3.zdn.vn\\\\/gr\\\\/jpg\\\\/b76234ac6733a66dff22\\\\/211260925237182644.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777738098670,\\"id_in_group\\":1,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000007851\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 16:08:19.266	\N	2026-05-02 16:08:19.64
14b1cdc6-ca39-438d-afa3-5c0bd0e2bfc1	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784804154537	contact	1453308858166125100	Phú Nguyễn	{"title":"","description":"","href":"https://photo-stal-37.zdn.vn/gr/jpg/61caf615a58a64d43d9b/4221256544153036868.jpg","thumb":"https://photo-stal-37.zdn.vn/gr/jpg/61caf615a58a64d43d9b/4221256544153036868.jpg","childnumber":0,"action":"","params":"{\\"width\\":2460,\\"height\\":1080,\\"hd\\":\\"https:\\\\/\\\\/photo-stal-37.zdn.vn\\\\/gr\\\\/jpg\\\\/61caf615a58a64d43d9b\\\\/4221256544153036868.jpg\\",\\"is_group_layout\\":1,\\"group_layout_id\\":1777738098670,\\"id_in_group\\":0,\\"total_item_in_group\\":2,\\"contentId\\":\\"1000007850\\",\\"convertible\\":\\"jxl\\",\\"is_original\\":0}","type":""}	image	[]	f	\N	2026-05-02 16:08:19.216	\N	2026-05-02 16:08:19.67
c15a6165-dfb0-432e-be5d-92908526c499	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784804531673	contact	386507739282916698	Tuấn Peodethuong	Cấm chat này đã bị cầm đến mức kể cả  lên làm r4 r5 cũng ko ghim đc chưa	text	[]	f	\N	2026-05-02 16:08:31.541	\N	2026-05-02 16:08:31.827
12ef9ea6-3310-42ac-8b60-552f3bca0210	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784804560150	contact	1453308858166125100	Phú Nguyễn	7/11/2 def 569 :)	text	[]	f	\N	2026-05-02 16:08:32.45	\N	2026-05-02 16:08:32.577
de16816a-09b0-4634-afd2-7fbafc1b1afb	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784805073222	contact	386507739282916698	Tuấn Peodethuong	Hay vẫn xài ghim pin để thay chat	text	[]	f	\N	2026-05-02 16:08:49.33	\N	2026-05-02 16:08:49.646
5c3f5048-1151-4f08-bb72-f0e085805bdc	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784805243444	contact	3874537684008431042	Trang Thành Lộc	{"title":"","description":"","href":"https://photo-stal-20.zdn.vn/gr/jpg/195a6bbc9a2c5b72023d/1736839623870036428.jpg","thumb":"https://photo-stal-20.zdn.vn/gr/jpg/195a6bbc9a2c5b72023d/1736839623870036428.jpg","childnumber":0,"action":"","params":"{\\"height\\":1284,\\"thumb_width\\":778,\\"thumb_height\\":360,\\"tracking\\":{\\"subsource\\":\\"0\\",\\"source\\":0},\\"hd\\":\\"https:\\\\/\\\\/photo-stal-20.zdn.vn\\\\/gr\\\\/jpg\\\\/195a6bbc9a2c5b72023d\\\\/1736839623870036428.jpg\\",\\"width\\":2778,\\"convertible\\":\\"jxl\\"}","type":""}	image	[]	f	\N	2026-05-02 16:08:54.901	\N	2026-05-02 16:08:55.277
5c5931b4-14ee-4651-8ef9-c439a221631a	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784805671328	contact	3874537684008431042	Trang Thành Lộc	Acc 600m out được được 7 cái zero	text	[]	f	\N	2026-05-02 16:09:08.988	\N	2026-05-02 16:09:09.299
baa3844a-a418-43fd-940f-4b83e00321d2	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784806444007	contact	3874537684008431042	Trang Thành Lộc	Offline mà trâu vl	text	[]	f	\N	2026-05-02 16:09:34.551	\N	2026-05-02 16:09:34.793
533adfc1-263b-41a6-9603-021be29052da	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784807047096	contact	4881617662073102521	Nguyễn Minh Tuan	Build lên 1b3, online def phê ấy chứ	text	[]	f	\N	2026-05-02 16:09:54.656	\N	2026-05-02 16:09:55.069
5d07f62e-181e-42b6-8a73-00a0e885f8af	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784808947953	contact	3874537684008431042	Trang Thành Lộc	Xác 130m	text	[]	f	\N	2026-05-02 16:10:58.383	\N	2026-05-02 16:10:58.595
80b4c425-0a7c-4a82-a0ba-5311cfc1216e	3df1a9b9-89db-40e1-bfd2-f7d3cfbf3387	7784809043069	contact	3874537684008431042	Trang Thành Lộc	:~ :~	text	[]	f	\N	2026-05-02 16:11:01.582	\N	2026-05-02 16:11:01.735
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.orders (id, org_id, contact_id, created_by_user_id, conversation_id, order_code, total_amount, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.organizations (id, name, created_at, updated_at) FROM stdin;
ecae3be0-2ff7-4547-bf7a-308be16a20ad	1car	2026-05-02 04:55:34.533	2026-05-02 04:55:34.533
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.teams (id, org_id, name, created_at) FROM stdin;
9f96990a-679a-4962-8451-25d7d683ed47	ecae3be0-2ff7-4547-bf7a-308be16a20ad	makeeting	2026-05-02 06:05:19.012
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.users (id, org_id, team_id, email, password_hash, full_name, role, is_active, created_at, updated_at) FROM stdin;
e533888b-4c79-42d5-ab7b-7c25b35d6bc8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	\N	hiephiep1002@gmail.com	$2b$12$0eaUaEl86Kxp8ex34agFAOcxfLv2pYaXL78NL7YU2jYkTxKANjuae	hiep	owner	t	2026-05-02 04:55:34.563	2026-05-02 04:55:34.563
fffd31b7-2279-4069-b124-6ef85d977285	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9f96990a-679a-4962-8451-25d7d683ed47	hiephiep10023@gmail.com	$2b$10$kiXYOPwRgx14/gFMuWhDd..4oFvfS9s0yhD2iTJLMofabwxJg3oEa	trần nghĩa hiệp	member	t	2026-05-02 06:05:00.419	2026-05-02 06:05:27.091
\.


--
-- Data for Name: zalo_account_access; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.zalo_account_access (id, zalo_account_id, user_id, permission, created_at) FROM stdin;
\.


--
-- Data for Name: zalo_accounts; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.zalo_accounts (id, org_id, owner_user_id, zalo_uid, display_name, avatar_url, phone, status, session_data, last_connected_at, created_at) FROM stdin;
3b0f3596-7f25-4548-ab4e-dca73e7be21c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	e533888b-4c79-42d5-ab7b-7c25b35d6bc8	117555250217991590	Trần Nghĩa Hiệp	https://s160-ava-talk.zadn.vn/default	\N	qr_pending	{"imei": "e585898f-9426-4a60-a0f7-c3d4ee592b4b-a69b52f9d7f760edf3fd052bcda2542f", "cookie": [{"key": "zpdid", "path": "/", "value": "41NybLVpepuL5PkHL_VBEHiLcv9NyCez", "domain": "id.zalo.me", "maxAge": 157680000, "secure": true, "creation": "2026-05-02T04:55:59.106Z", "hostOnly": false, "httpOnly": true, "sameSite": "lax", "lastAccessed": "2026-05-02T04:56:34.902Z"}, {"key": "zlogin_session", "path": "/", "value": "kW4JGLyjCnIxFnDDLXTbH-Tj1a1H6ML7v6qTLGrGQr-lB0zS0L1jMgyi0Ly1K6PDVG", "domain": "id.zalo.me", "maxAge": 3600, "secure": true, "creation": "2026-05-02T04:55:59.106Z", "hostOnly": false, "httpOnly": true, "sameSite": "lax", "lastAccessed": "2026-05-02T04:56:34.902Z"}, {"key": "_zlang", "path": "/", "value": "vn", "domain": "zalo.me", "maxAge": 86400, "secure": true, "expires": "2026-05-03T04:56:35.000Z", "creation": "2026-05-02T04:55:59.196Z", "hostOnly": false, "lastAccessed": "2026-05-02T04:56:35.437Z"}, {"key": "zpsid", "path": "/", "value": "w5yI.305260274.10.41M2P0YULTJwU6J619vLr7tj9-SugsVYEAnYu6yuxDdGuG2j2PpH8M6ULTG", "domain": "zalo.me", "maxAge": 31536000, "secure": true, "creation": "2026-05-02T04:56:34.897Z", "hostOnly": false, "httpOnly": true, "sameSite": "none", "lastAccessed": "2026-05-02T04:56:35.397Z"}, {"key": "__zi", "path": "/", "value": "3000.QOBlzDCV2uGerkFzm09Mr6RJu_h501hNPj2e_Si06jXhtwZo.1", "domain": "zalo.me", "maxAge": 63072000, "secure": true, "creation": "2026-05-02T04:56:34.898Z", "hostOnly": false, "sameSite": "none", "lastAccessed": "2026-05-02T04:56:35.397Z"}, {"key": "zlogtype", "path": "/", "value": "EXPIRED", "domain": "id.zalo.me", "maxAge": 0, "secure": true, "expires": "1970-01-01T00:00:00.000Z", "creation": "2026-05-02T04:56:34.898Z", "hostOnly": false, "httpOnly": true, "lastAccessed": "2026-05-02T04:56:34.941Z"}, {"key": "zpsid", "path": "/", "value": "eMKnVcAlVqAZUYmFTlLh9VfyPNDgy6iY_tvxS6tgSIA2OXznUOrjHf501XDvp0b9hJf57NlgGbEA9Hj3ViPWOR8bApHfwcqJhnScDp_7AWJjDImgUTfU7KS", "domain": "zaloapp.com", "maxAge": 31536000, "secure": true, "creation": "2026-05-02T04:56:35.084Z", "hostOnly": false, "httpOnly": true, "sameSite": "none", "lastAccessed": "2026-05-02T04:56:35.084Z"}, {"key": "__zi", "path": "/", "value": "3000.QOBlzDCV2uGerkFzm09Mr6RJu_h501hNPj2e_Si06jXhtgpr.1", "domain": "zaloapp.com", "maxAge": 63072000, "secure": true, "creation": "2026-05-02T04:56:35.084Z", "hostOnly": false, "sameSite": "none", "lastAccessed": "2026-05-02T04:56:35.084Z"}, {"key": "zpw_sek", "path": "/", "value": "sgzC.305260274.a0.D86RxexAqvnyBEAEhyhJdFNejlUiyF7M-RA9-DYQdANClBQprgQZwxYdvTdFz-w-ywrr9OCIhCdtoz0OUwFJd0", "domain": "chat.zalo.me", "maxAge": 7776000, "secure": true, "creation": "2026-05-02T04:56:35.237Z", "hostOnly": false, "httpOnly": true, "sameSite": "lax", "lastAccessed": "2026-05-02T04:56:35.397Z"}], "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0"}	2026-05-02 04:56:36.436	2026-05-02 04:55:52.673
\.


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: daily_message_stats daily_message_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: zalo_account_access zalo_account_access_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_pkey PRIMARY KEY (id);


--
-- Name: zalo_accounts zalo_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_pkey PRIMARY KEY (id);


--
-- Name: app_settings_org_id_setting_key_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX app_settings_org_id_setting_key_key ON public.app_settings USING btree (org_id, setting_key);


--
-- Name: conversations_zalo_account_id_external_thread_id_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX conversations_zalo_account_id_external_thread_id_key ON public.conversations USING btree (zalo_account_id, external_thread_id);


--
-- Name: daily_message_stats_user_id_zalo_account_id_stat_date_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX daily_message_stats_user_id_zalo_account_id_stat_date_key ON public.daily_message_stats USING btree (user_id, zalo_account_id, stat_date);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: zalo_account_access_zalo_account_id_user_id_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX zalo_account_access_zalo_account_id_user_id_key ON public.zalo_account_access USING btree (zalo_account_id, user_id);


--
-- Name: zalo_accounts_zalo_uid_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX zalo_accounts_zalo_uid_key ON public.zalo_accounts USING btree (zalo_uid);


--
-- Name: activity_logs activity_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: app_settings app_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contacts contacts_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contacts contacts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: conversations conversations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: daily_message_stats daily_message_stats_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: daily_message_stats daily_message_stats_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_replied_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_replied_by_user_id_fkey FOREIGN KEY (replied_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: teams teams_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: zalo_account_access zalo_account_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_account_access zalo_account_access_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_accounts zalo_accounts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_accounts zalo_accounts_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict rdxrjVG5V1HZrxww94jXvourK4CtyJ5b47j67tYh3ybzvl3ZwPjgPPfTK0Ykw5S

