--
-- PostgreSQL database dump
--

\restrict fGMot6HPmhtbnojvST5opxGTL9DmixeuUWlyQL2OWmoxzhMjG2MLeAU6Z0IaFGW

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.activity_logs (
    id text NOT NULL,
    org_id text NOT NULL,
    user_id text,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.activity_logs OWNER TO crmuser;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.app_settings (
    id text NOT NULL,
    org_id text NOT NULL,
    setting_key text NOT NULL,
    value_plain text,
    value_encrypted bytea,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.app_settings OWNER TO crmuser;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.appointments (
    id text NOT NULL,
    org_id text NOT NULL,
    contact_id text NOT NULL,
    assigned_user_id text,
    appointment_date timestamp(3) without time zone NOT NULL,
    appointment_time text,
    type text,
    status text DEFAULT 'scheduled'::text NOT NULL,
    notes text,
    reminder_sent boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.appointments OWNER TO crmuser;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.contacts (
    id text NOT NULL,
    org_id text NOT NULL,
    zalo_uid text,
    phone text,
    email text,
    full_name text,
    avatar_url text,
    source text,
    source_date timestamp(3) without time zone,
    first_contact_date timestamp(3) without time zone,
    status text DEFAULT 'new'::text,
    next_appointment timestamp(3) without time zone,
    assigned_user_id text,
    notes text,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contacts OWNER TO crmuser;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.conversations (
    id text NOT NULL,
    org_id text NOT NULL,
    zalo_account_id text NOT NULL,
    contact_id text,
    "threadType" text DEFAULT 'user'::text NOT NULL,
    external_thread_id text,
    last_message_at timestamp(3) without time zone,
    unread_count integer DEFAULT 0 NOT NULL,
    is_replied boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversations OWNER TO crmuser;

--
-- Name: daily_message_stats; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.daily_message_stats (
    id text NOT NULL,
    org_id text NOT NULL,
    user_id text NOT NULL,
    zalo_account_id text NOT NULL,
    stat_date date NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    messages_received integer DEFAULT 0 NOT NULL,
    messages_unread integer DEFAULT 0 NOT NULL,
    messages_unreplied integer DEFAULT 0 NOT NULL,
    avg_response_time_seconds integer
);


ALTER TABLE public.daily_message_stats OWNER TO crmuser;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.messages (
    id text NOT NULL,
    conversation_id text NOT NULL,
    zalo_msg_id text,
    sender_type text NOT NULL,
    sender_uid text,
    sender_name text,
    content text,
    content_type text DEFAULT 'text'::text NOT NULL,
    attachments jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(3) without time zone,
    sent_at timestamp(3) without time zone NOT NULL,
    replied_by_user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.messages OWNER TO crmuser;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.orders (
    id text NOT NULL,
    org_id text NOT NULL,
    contact_id text NOT NULL,
    created_by_user_id text NOT NULL,
    conversation_id text,
    order_code text NOT NULL,
    total_amount double precision NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO crmuser;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.organizations (
    id text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.organizations OWNER TO crmuser;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.teams (
    id text NOT NULL,
    org_id text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.teams OWNER TO crmuser;

--
-- Name: users; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.users (
    id text NOT NULL,
    org_id text NOT NULL,
    team_id text,
    email text NOT NULL,
    password_hash text NOT NULL,
    full_name text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO crmuser;

--
-- Name: zalo_account_access; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.zalo_account_access (
    id text NOT NULL,
    zalo_account_id text NOT NULL,
    user_id text NOT NULL,
    permission text DEFAULT 'read'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.zalo_account_access OWNER TO crmuser;

--
-- Name: zalo_accounts; Type: TABLE; Schema: public; Owner: crmuser
--

CREATE TABLE public.zalo_accounts (
    id text NOT NULL,
    org_id text NOT NULL,
    owner_user_id text NOT NULL,
    zalo_uid text,
    display_name text,
    avatar_url text,
    phone text,
    status text DEFAULT 'disconnected'::text NOT NULL,
    session_data jsonb,
    last_connected_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.zalo_accounts OWNER TO crmuser;

--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.activity_logs (id, org_id, user_id, action, entity_type, entity_id, details, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.app_settings (id, org_id, setting_key, value_plain, value_encrypted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.appointments (id, org_id, contact_id, assigned_user_id, appointment_date, appointment_time, type, status, notes, reminder_sent, created_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.contacts (id, org_id, zalo_uid, phone, email, full_name, avatar_url, source, source_date, first_contact_date, status, next_appointment, assigned_user_id, notes, tags, metadata, created_at, updated_at) FROM stdin;
38fd2550-b5cc-4b25-aad2-261494be2147	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8590853056949506623	\N	\N	Vu Xuân Trường	https://s120-25-ava-talk.zadn.vn/50/a5d7279981b52c6e0d13934ee683f43f.jpg?key=BwYZvmwBODscPe88wrKAZg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.501	2026-05-04 02:46:13.501
2853cbcb-93ad-49e8-993d-a78e992a7514	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3365195044584063156	\N	\N	Thành Vinh	https://s120-25-ava-talk.zadn.vn/9/1d82a952930a2f7e1e417707bcf59421.jpg?key=Kk2VebyuUZ4VllCfqZCobg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.54	2026-05-04 02:46:13.54
d7895e02-a228-4f3a-8d45-c904e245e74e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5199815831260101678	\N	\N	Bảo Vân	https://s120-25-ava-talk.zadn.vn/17/a468f65558656518657f74b04c96fc04.jpg?key=dBnBEM1nl21R__PpQZmWUA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.555	2026-05-04 02:46:13.555
5bf0e2a3-3d0e-4fe9-8053-83bbacb4e18e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2377225580510953722	\N	\N	Bình Hải	https://s120-25-ava-talk.zadn.vn/8/c069d8aa8b7ea7b9e058e0a4fd0183d1.jpg?key=vRv6TpZpFcoYRemBfL2oOQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.568	2026-05-04 02:46:13.568
ecbd92df-a6d0-47c2-95f7-3592f75a444e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6997004832864396829	\N	\N	Tuấn Phương	https://s120-25-ava-talk.zadn.vn/11/45a05f856c50c2937080a9760d831f75.jpg?key=1zMYQxy3pfBPusUbQ7tsiA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.578	2026-05-04 02:46:13.578
24df0eb3-f670-49ed-a118-99a110c09feb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4363568070414806921	\N	\N	Lê Trung Hiếu	https://s120-25-ava-talk.zadn.vn/9/34c8c15b2c3ef696ccf2ea1951a13000.jpg?key=NMOaeZHHz9OTWebJNgM6cg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.586	2026-05-04 02:46:13.586
531b091d-2852-4b81-af7a-992d79b8693b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1318766047664325194	\N	\N	Minh Lâm	https://s120-25-ava-talk.zadn.vn/19/300552fa1e5fb484e2413f5804e9b6f4.jpg?key=BR1wg02mt0WaCmGwHFEk6g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.594	2026-05-04 02:46:13.594
1772f6a4-8a38-486a-9573-64b988d3be8a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3370964796099328975	\N	\N	Tuan	https://s120-25-ava-talk.zadn.vn/13/9fc14af5f6785d0521689c41b6e931b9.jpg?key=V1ZWoPhovEUScV0jYRnHOA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.6	2026-05-04 02:46:13.6
f5c4be65-d5d4-4fe8-810e-0684c13efa9a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1130453685897962167	\N	\N	Bhuy	https://s120-25-ava-talk.zadn.vn/7/047d22584e3688d5ccf226f7e4e99ece.jpg?key=KXRgTy1PbwUXb2ZKBVI6eQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.606	2026-05-04 02:46:13.606
a0fb7f51-eb1d-4789-a7d2-3d37dbdef149	ecae3be0-2ff7-4547-bf7a-308be16a20ad	892335756337869669	\N	\N	Học Giếng Khoan	https://s120-25-ava-talk.zadn.vn/57/ccbe5080d90c0609b23fb70b9da336cb.jpg?key=NQhI1nVtOY2yOgtZaZ1UBg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.613	2026-05-04 02:46:13.613
fb548f4e-94ad-4fb5-928f-aabf505c2d61	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5874788356599630720	\N	\N	Thắng Trần	https://s120-25-ava-talk.zadn.vn/21/f715c38edb2c4cae7d124f45276c8f40.jpg?key=vI_NtteF8pwJ7lgBMVvRlA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.62	2026-05-04 02:46:13.62
288a6492-1754-438b-b4e8-18a6546179e1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7533351490509930124	\N	\N	Quân	https://s120-25-ava-talk.zadn.vn/35/c316e9cfd6db16597a42c91a1085b9f2.jpg?key=Af5piiZr0U2A_lZn0MP_WA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.638	2026-05-04 02:46:13.638
056ae7a4-b1d2-404f-af94-d2c122b6ccdd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5529985907955986361	\N	\N	Thanh Huyền	https://s120-25-ava-talk.zadn.vn/139/698427b826a07cb208e62e1bd6747ae4.jpg?key=2Ezn_iZQeopD6rUV68LLUQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.651	2026-05-04 02:46:13.651
bc22012e-399d-4400-aaf8-6bb19a3d8914	ecae3be0-2ff7-4547-bf7a-308be16a20ad	968339493716156535	\N	\N	Phạm Anh Tuấn	https://s120-25-ava-talk.zadn.vn/45/245be5efe0ece3eb6989d8c0ece1bdd1.jpg?key=AQpQkA3ACOf5rwDhmIs_TQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.667	2026-05-04 02:46:13.667
37e18989-f91e-4dc5-8ac4-baac76afe98d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9112994558292890736	\N	\N	tung phat	https://s120-25-ava-talk.zadn.vn/2/4743bf5f3fc59ddd0caf006f4e9418de.jpg?key=kXDglAsOIBy_p0vn-1eGlQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.676	2026-05-04 02:46:13.676
b0d0fac3-ba33-495e-9a98-fb88f11f3d98	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7491386531983166705	\N	\N	Hùng	https://s120-25-ava-talk.zadn.vn/1/16f15a2c7f8714a28efcc01e8e546145.jpg?key=dGtyuUsj9XAL_Z7P5NLjMQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.684	2026-05-04 02:46:13.684
598f079c-9423-4488-8338-673d762118cc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1391940534205472598	\N	\N	Nguyễn Văn Quyết	https://s120-25-ava-talk.zadn.vn/18/10822971154fd0ce762285e8f382e45a.jpg?key=ZU1YuEkCCCoVw_7xT1RizA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.69	2026-05-04 02:46:13.69
47e138af-b4de-40f6-8e5e-1c7cf90ec917	ecae3be0-2ff7-4547-bf7a-308be16a20ad	106465284304135805	\N	\N	Minh Vương	https://s120-25-ava-talk.zadn.vn/21/7421420438ee8cf99f808f581b5a7f15.jpg?key=1NGTNbQYYXCMv2bG_IfZ5g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.695	2026-05-04 02:46:13.695
bc337a04-7c4f-499e-b0b0-eee163c576c3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5027984576024583873	\N	\N	Nguyễn Đình Thuật	https://s120-25-ava-talk.zadn.vn/10/6317ec417b8dd4df39a8048ac3bb3463.jpg?key=DkifDKLlfAxoJ0CyPHq5Eg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.7	2026-05-04 02:46:13.7
e341c945-3a7f-4b73-9f62-1df1f4c1903e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7973708775326145455	\N	\N	Hưng Nguyễn	https://s120-25-ava-talk.zadn.vn/3/24db55890f4814b7044aa6f9797dd838.jpg?key=U5hMPGAlDMTjYdjGjg-M-w&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.705	2026-05-04 02:46:13.705
ece0f557-ff74-425f-8844-6f62c83922f6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5843532481371558943	\N	\N	Zalo	https://s120-25-ava-talk.zadn.vn/36/16782d311b12da6d28daa13e343986b8.jpg?key=OTUaPptq6lZULMEXjNAHsQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.712	2026-05-04 02:46:13.712
37605307-e718-466c-849c-8f5f1a98e854	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1020544710927759918	\N	\N	Đati	https://s120-25-ava-talk.zadn.vn/37/0bf74bd37a074d1e9f0d545e07755798.jpg?key=KgojBiShsfxiHUnEPvn83Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.724	2026-05-04 02:46:13.724
04889a8f-1603-4a2b-a838-2e4dfb4f072d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	813938803663625548	\N	\N	Huệ	https://s120-25-ava-talk.zadn.vn/101/a61a879fda9581de34de1b23d1634170.jpg?key=Wg6E6pgTIrMBScoO8JkYrA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.731	2026-05-04 02:46:13.731
043b2e0c-eb3a-471a-bdbc-7ec6a35a595c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5589094428963815575	\N	\N	An Nguyễn	https://s120-25-ava-talk.zadn.vn/1/87495ea8651a2c11c861bde3a502c6f4.jpg?key=2bwGBZXTVrvkNGe4h53bCA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.736	2026-05-04 02:46:13.736
f2e776db-580d-4440-99ac-c467416377fd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6663625746799179902	\N	\N	Bao Bao	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.741	2026-05-04 02:46:13.741
8fc9e7ee-646c-45af-96b4-37cb4777c8b3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5227378038088588940	\N	\N	Nguyễn Sỹ Hiển	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.746	2026-05-04 02:46:13.746
2f8c4bc5-fea1-4f9c-8f21-7bd4352de60e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8810000927059780676	\N	\N	Team Thực tập	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-02 14:14:26.559	2026-05-11 08:54:39.804
23d3d1b9-a59b-4ab1-bf32-ac4737a40438	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6142746758236927800	\N	\N	Nguyễn Nhật Huỳnh	https://s120-25-ava-talk.zadn.vn/14/100eedf230c8fcc7a2d5f1c5091a721e.jpg?key=njyT7sLznmPf9RLlpLAWMA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.751	2026-05-04 02:46:13.751
18dae6d2-40b0-4934-96f4-603137263691	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8652078511014082325	\N	\N	Tiến Lộc	https://s120-25-ava-talk.zadn.vn/6/961eb945114df9ff085bb84343eaf0c6.jpg?key=qpeUvZDQX6F-HKCIAgX4TQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.759	2026-05-04 02:46:13.759
62271160-a4f7-4b31-b1e6-f522e568c5b4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6918032632913067014	\N	\N	Đình Ngân	https://s120-25-ava-talk.zadn.vn/4/dd103a5fcdc46b42458a6e03d3a85d8a.jpg?key=N7rzGsKh9LGMxRt1jzbaKg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.769	2026-05-04 02:46:13.769
e97244c8-c51a-4195-88a5-4ec4ebcc57ec	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7624815288856388823	\N	\N	David Lee	https://s120-25-ava-talk.zadn.vn/8/a334ef703a73fcb0379f2ba1c037c16c.jpg?key=HwqdHwoB2RKtLouxTipqZA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.775	2026-05-04 02:46:13.775
8cab9e0f-dfe9-4575-9296-7ff83c2dd61b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	442689131821776675	\N	\N	Trân	https://s120-25-ava-talk.zadn.vn/100/b1d08d2df83aab4633f925411628ee9d.jpg?key=Y_r34wnXAAY11eE79g3new&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.782	2026-05-04 02:46:13.782
f18cd854-a4c8-41b2-81ec-c6effc1d0296	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2075914187392143048	\N	\N	Trần Anh	https://s120-25-ava-talk.zadn.vn/22/713eb3a5350638c062edcdfc57215ad8.jpg?key=A6CJGST-yvulEw0dNtfdOQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.789	2026-05-04 02:46:13.789
d4719b63-e866-4004-b967-c7658e424f05	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5531375484717339332	\N	\N	Nguyễn	https://s120-25-ava-talk.zadn.vn/2/01072ef43e0d3554e40a419973036a88.jpg?key=kfCzUVreXdz6V1NPxJwu-Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.794	2026-05-04 02:46:13.794
f96ae4e7-af46-4ff3-b877-ce3c7537eed7	ecae3be0-2ff7-4547-bf7a-308be16a20ad	810978846930818886	\N	\N	Larry Nguyễn Hà	https://s120-25-ava-talk.zadn.vn/13/e7dddbbe91176868021bbe76cac86219.jpg?key=9ktmOSdztKZILL3zSvb7Qw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.798	2026-05-04 02:46:13.798
badebfff-4793-48e0-a703-c5c992698743	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7826078619176594076	\N	\N	Trần Trọng Phúc	https://s120-25-ava-talk.zadn.vn/10/67e43fa6c8ff94903f55c347a1a69ba3.jpg?key=V_2lFqvJzRmK8_6Zz1YtTg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.803	2026-05-04 02:46:13.803
496ac803-d14b-498e-8b0c-bf120a6f3f5b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9155780683281460488	\N	\N	Thuần	https://s120-25-ava-talk.zadn.vn/92/4d0dd370c6222f4d89b5eee3409ff6b8.jpg?key=Tqe8yeJS1R0-zUfBOFOgTQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.808	2026-05-04 02:46:13.808
daeb12c2-4895-4046-8a9d-712a7c573298	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1824701401457481301	\N	\N	Nghĩa Nv	https://s120-25-ava-talk.zadn.vn/6/17598219110c7a6719e15f93358e45e0.jpg?key=W-lbyI2FOUsoYRfXCAdP6g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.812	2026-05-04 02:46:13.812
8b70da1a-b73b-4493-82a5-24162d7eb55f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6659667179765541484	\N	\N	Ms Loan Giảng Viên Tiếng Anh	https://s120-25-ava-talk.zadn.vn/321/86de4bf90952554691e221b8cf232de1.jpg?key=-4DpGTxhaXhgX8H1esKRfA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.819	2026-05-04 02:46:13.819
8bf07684-6b35-4655-9000-5a9e5db08d5d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3510152909233036209	\N	\N	Vân nguyễn	https://s120-25-ava-talk.zadn.vn/12/7ade927de5dd3f61c699b8c28cc84c94.jpg?key=U56NJ16EWFZmKi7HmAFF9Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.824	2026-05-04 02:46:13.824
29691e33-46d3-4cf4-b370-1441912b5cd3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6794776306049124428	\N	\N	Mai Văn Minh	https://s120-25-ava-talk.zadn.vn/13/a4718df15a7c580add89b78633be2cc4.jpg?key=R58Jmz5KP4QALBsXQZkTiw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.828	2026-05-04 02:46:13.828
938be2c1-208c-4150-863c-6ccd0b0cb282	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4422396749875642200	\N	\N	Khánh Huy	https://s120-25-ava-talk.zadn.vn/11/194efd5652ad9c6facf07b36717f0d9d.jpg?key=jCvkJ0OVzAd8bubGOMBvPg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.835	2026-05-04 02:46:13.835
644c2723-fb12-4c36-9e10-5d15a2aee155	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5436396812168505206	\N	\N	Huy	https://s120-25-ava-talk.zadn.vn/26/31d4e9d2ff38e158584691184cdd1bcc.jpg?key=Z7ybNbBFb6-0XlJkItOU1Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.842	2026-05-04 02:46:13.842
5ef79c56-726a-4f8a-82df-3b671c2dfa12	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4719316730111107705	\N	\N	Phạm Mỹ Linh 美玲	https://s120-25-ava-talk.zadn.vn/83/9596d80db8b425deabc87ff49b5f833c.jpg?key=c0bsrWWa6N8CN5qTVgIbGg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.851	2026-05-04 02:46:13.851
fcd70979-0579-4c77-8fc1-5fb4110f84a9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2040756076357997397	84902430743	\N	Minh Nghĩa	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.877	2026-05-04 02:46:13.877
38590d90-e132-4db2-8887-b3e0d535966f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7282564884786440215	\N	\N	Lê Thế Dũng	https://s120-25-ava-talk.zadn.vn/3/b4f4cb28e8af27925360db5b6c5dd2c3.jpg?key=-HvY2Hcr9zDBvxKR58iVlA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.899	2026-05-04 02:46:13.899
33b2039e-0535-4edb-bca2-0cf5adb79f40	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7354752719437490710	\N	\N	Chàng Khờ Thủy Chung	https://s120-25-ava-talk.zadn.vn/18/dd7c8335ec4eb496e730ed7235a32263.jpg?key=6B3TA86-qaGulUcrckr2Ww&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.91	2026-05-04 02:46:13.91
acc2ecce-0ad6-48ea-be26-6c8a93844a61	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4849218015667787084	84794695728	\N	Lê Q Phú	https://s120-25-ava-talk.zadn.vn/13/4478b811c9463e4ca424f77482ccfdfe.jpg?key=8ss6qk_segMbh810A_UQmw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.929	2026-05-04 02:46:13.929
ef09ddcd-862a-4214-aa46-cf706d845c94	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5040625366319279092	\N	\N	Quang	https://s120-25-ava-talk.zadn.vn/15/fcd7749f0ccc73889166db174fe8737e.jpg?key=FP7rfkXguTThr9M8fk2o-g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.937	2026-05-04 02:46:13.937
11db9069-8490-41ae-b9a6-39a5333eae98	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1096119383979435057	\N	\N	Quốc Trung	https://s120-25-ava-talk.zadn.vn/21/cbea508cdef4e463f2f785e6c8a5034b.jpg?key=sKx615yJR0Oob2qVNMcVVA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.946	2026-05-04 02:46:13.946
a8dccc00-fdc6-484b-a9cb-1e20e9e0b777	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3575175767328469402	\N	\N	Nguyễn Hương	https://s120-25-ava-talk.zadn.vn/64/d699749a3bd6474b4e61e826c99953f2.jpg?key=ISWeXcDFlso-kBd1f5GsLg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.953	2026-05-04 02:46:13.953
486e0338-c5d5-43bd-a097-1f5f4f067af0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4552437174917173034	\N	\N	Bùi Minh Hiếu	https://s120-25-ava-talk.zadn.vn/16/585c0cf1796f4af4899ef3b2381cd817.jpg?key=t96nIMJ4iZIKb-wWMBFZSg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.969	2026-05-04 02:46:13.969
f86834b0-a8af-4ec0-bb3f-06e3cb05c7f9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2533279186909697583	\N	\N	Lê Đình Quang	https://s120-25-ava-talk.zadn.vn/2/f2ac5fcb311f3834945606f81e0749e4.jpg?key=7rrvTT_G61rpb_lWMJcpww&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.982	2026-05-04 02:46:13.982
ac181ede-3900-46b7-9e25-bdab949b730e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3571090561630184328	\N	\N	Phan Bá Bình	https://s120-25-ava-talk.zadn.vn/5/83485c8d4d762b75a28654e15cacf949.jpg?key=iQM-e3OzYoCZ134nqmWp1g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.989	2026-05-04 02:46:13.989
bc3c5456-dedb-4c9b-bd39-5f463ae9b3da	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6976290491141041623	\N	\N	Kim Duy	https://s120-25-ava-talk.zadn.vn/24/b79a18d00fd5959a2fdf85118f751504.jpg?key=OK8pwXcKjS4Ken7fBLUtTw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:13.995	2026-05-04 02:46:13.995
7429421c-051c-492b-ba9b-9d8d1082c712	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4032279182712627186	84909735707	\N	Van Anh	https://s120-25-ava-talk.zadn.vn/1/38ead18addf174ae886e85f97f2c6149.jpg?key=1oGImPXcCcohN9smr0cViQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.004	2026-05-04 02:46:14.004
5b2f058c-c260-43d7-b4ed-1aeb91c1bf3d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3115939052991645753	84363633072	\N	Phạm Huy Hoàng	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.01	2026-05-04 02:46:14.01
95730d4b-7a75-4a0e-99a1-17c4fa22aa19	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7180921203648944544	\N	\N	Lê Quốc Kỳ	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.016	2026-05-04 02:46:14.016
1ec4acb7-a8e8-4d1c-b655-32d85ea30c33	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2781427507630744222	\N	\N	Huỳnh Anh	https://s120-25-ava-talk.zadn.vn/153/a759af2c1ec546f8e7ffbe0fa48a2ce6.jpg?key=5oVBoasV_zHPJpbaF7M8fg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.022	2026-05-04 02:46:14.022
83fe060e-4d72-4e7d-969b-56ea3315538f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	542162771176889473	\N	\N	Nguyễn Thị Tú Trinh	https://s120-25-ava-talk.zadn.vn/38/72c95b3f34b3929d3021e70c158255f0.jpg?key=0JkNnLL1jc7CSR7CIvxe-Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.037	2026-05-04 02:46:14.037
2bd5f205-1d7e-49fe-a050-a2f0f44c7e42	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5957113213587088556	\N	\N	Lieu Nguyen	https://s120-25-ava-talk.zadn.vn/13/73d937a55b7cfef46c71b5f6e1cac14a.jpg?key=6qmbDnjnrJsPD1pE3Jhu2g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.05	2026-05-04 02:46:14.05
38f33647-d81e-4af8-9e5b-3371c2e6c64d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9034324555011293287	\N	\N	Thu Hà	https://s120-25-ava-talk.zadn.vn/8/36034afbeb33a8543ef31db9a9eeea95.jpg?key=hMMjnGG6tj-HAR1U8lqGbw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.063	2026-05-04 02:46:14.063
e17e80d0-4c8b-406d-bddf-0e2cc1599b8d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3856501922686217602	\N	\N	Nguyễn Nhật Hiếu	https://s120-25-ava-talk.zadn.vn/77/e24ff516cc6af3a82cdba2f9d189009e.jpg?key=G5_LUD8zMiv5vp9aG61SzA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.075	2026-05-04 02:46:14.075
903bfba9-dd84-4fba-9883-6ade7caaac25	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6339501809145327869	\N	\N	Kim Thoa- Đào Tạo Lái Xe	https://s120-25-ava-talk.zadn.vn/33/ac2275d7667a59584e10fba08bce1e7b.jpg?key=RbskoPXAslD8F3a_FsJMVQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.081	2026-05-04 02:46:14.081
7fe71d4d-84cf-4e87-a3e6-6de70113fddc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1064450961613248194	\N	\N	Kiều My	https://s120-25-ava-talk.zadn.vn/43/ff87850e46c85968f9f0f62ccb37b076.jpg?key=GlgL2hIbD0a1uBa0U277aA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.086	2026-05-04 02:46:14.086
67d41cab-da0e-4e77-8f36-67a497e83217	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2452072241461835776	\N	\N	Le Van Dang	https://s120-25-ava-talk.zadn.vn/4/1e86c2a82aca74bc02a65d33cd564f63.jpg?key=Oxh4zqTT7-rh4yE1YsaI3A&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.091	2026-05-04 02:46:14.091
9124af08-d273-4f01-93d0-24fa620dc568	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1326355304159373167	\N	\N	Thomnguyen	https://s120-25-ava-talk.zadn.vn/54/393299a6d410ac513dc0ff1675284287.jpg?key=koTZE3PzfUkcOx7ovWexiQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.096	2026-05-04 02:46:14.096
d6929b00-c2b3-4cc6-8133-869358feb623	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4674710980990436056	\N	\N	Nguyễn Duy Thắng	https://s120-25-ava-talk.zadn.vn/2/3475481e43644b83753687e9189bc13b.jpg?key=Yp1YcFUPvw7CiGZmrXAg5g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.104	2026-05-04 02:46:14.104
7d4a47e0-934c-4e9d-828f-6d648b03f17d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7057244415670324471	\N	\N	Jackie	https://s120-25-ava-talk.zadn.vn/18/9572a966315c623fe33252787844ef66.jpg?key=k3OSbjAxJBhB0BjfsZntoQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.113	2026-05-04 02:46:14.113
35542fad-3130-489b-aa7a-b1d74d100b9c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3429230737531381136	84385099660	\N	Nguyễn Nhật Tân	https://s120-25-ava-talk.zadn.vn/22/9c63e1ee30951fde9a97fa8a161d4f8a.jpg?key=0xusOdJCoiThL_YhXlrgMQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.131	2026-05-04 02:46:14.131
cdf8da9d-5ab7-47dc-bc02-6514b38d2d34	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8876243584966445097	\N	\N	Lê Hoàn Khôi	https://s120-25-ava-talk.zadn.vn/82/4bc99d7bc4326cb188f3fe348f36facc.jpg?key=qqn8X5L8yOobwdpjzH5Bcw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.136	2026-05-04 02:46:14.136
51e07482-0a66-4441-bee4-317f852259e8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5551645509194865420	\N	\N	Minh Hiêp Qwertyuiop	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.142	2026-05-04 02:46:14.142
7e02e7da-695e-4599-8d4e-c124c941b98e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	901340546993263493	\N	\N	Tú Tú	https://s120-25-ava-talk.zadn.vn/145/655eee16b34b7dfe6bdc8de4aba71061.jpg?key=_vfjNKEPHIllr0mlOa9lYA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.152	2026-05-04 02:46:14.152
4ffbb4be-3acc-4686-99e3-55e4849f2133	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5654813209257618046	\N	\N	Mạnh Dũng	https://s120-25-ava-talk.zadn.vn/6/4ad5ad1b223d1deb998f7727e0290405.jpg?key=Pp86zmh3GO7ukRilPIQFQA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.162	2026-05-04 02:46:14.162
87e72a63-c2a4-449b-b2eb-b1505361537b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6927341688400109349	\N	\N	Nguyễn Ngọc Thiên	https://s120-25-ava-talk.zadn.vn/4/5d252266f109e179b49a6fc989a90b4d.jpg?key=QiaFdLgaSNEI6ieXO24wSw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.171	2026-05-04 02:46:14.171
4b11736b-2761-4568-b529-5a7f357fc282	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4044237181756998951	\N	\N	Nguyễn Phước Thảo Prateek Dhavan Desai	https://s120-25-ava-talk.zadn.vn/83/246875e6df4d788016454091e08c54f7.jpg?key=_16jEQmAhxsVD-ZnAQ9Idw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.181	2026-05-04 02:46:14.181
b9cb44c8-2272-4e13-bd1a-af8888945994	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5952478041105487004	\N	\N	Phạm Thu Hà	https://s120-25-ava-talk.zadn.vn/9/f12b11659b403f48723c2bc8ba997e4f.jpg?key=FaHcJGKLG8a1TGl0WQH3Hw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.192	2026-05-04 02:46:14.192
2ed15bd3-bb66-4a70-97fe-cade0dd8611b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	275744278983921108	\N	\N	Lương Quỳnh Như	https://s120-25-ava-talk.zadn.vn/27/da0c2937489cff379e8883df17a731f8.jpg?key=fkyp0RFGnHzkqxpZld6MMw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.208	2026-05-04 02:46:14.208
292f34b3-c363-4d3e-ae9a-f013fddd87cf	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3910120434033879108	\N	\N	Phạm Quang Bảo	https://s120-25-ava-talk.zadn.vn/12/7ac29eab2b8dcee40e919b43c89c4cbe.jpg?key=GL8p9j_q0-ytE-6TuFwLkw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.221	2026-05-04 02:46:14.221
e1ec30eb-2c6c-44f6-9f1b-8036ab4885cc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5490717712440025909	\N	\N	Trần Ngọc Vân Anh	https://s120-25-ava-talk.zadn.vn/49/30981082c519f13477671964342451d8.jpg?key=KUEnMxA_NfbFWDP8r7DF_Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.225	2026-05-04 02:46:14.225
d57d5c0d-3518-44e5-abc6-2a8c135b89a0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6430549551320135994	\N	\N	Thu Dung	https://s120-25-ava-talk.zadn.vn/5/cd60de0b0f9595fe2c5e9a14add418aa.jpg?key=ktTcz0PBPsaudyoHQZLmrg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.231	2026-05-04 02:46:14.231
8351f2d5-11c0-4de2-9a2f-39e1f03624c4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8591273844798509117	\N	\N	Đặng Đức Minh Quang	https://s120-25-ava-talk.zadn.vn/14/571d1d240bfb31b814eb8880b2d76c66.jpg?key=p_wV5B5dCS6JnNgiL4yEKQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.235	2026-05-04 02:46:14.235
ae34b58c-9fdb-4a9c-9e65-0e122b9dff31	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7438063194402374462	\N	\N	Đào Ngọc Huy	https://s120-25-ava-talk.zadn.vn/13/7063441ea3f8f5e42d7b69b2bff858aa.jpg?key=hjbC27b-xgxgKsoIYLQXqA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.245	2026-05-04 02:46:14.245
b23f0485-9bf0-4cfa-8382-41c41130c263	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8342727054413244864	\N	\N	Trần Nguyễn Ngọc Quý	https://s120-25-ava-talk.zadn.vn/2/6fd61835f2f1207733488db75eec7a65.jpg?key=564V2c7bGxV8Me0wkz3WHg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.258	2026-05-04 02:46:14.258
69296328-5815-4a3f-bae0-f0bc3311191b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6491652595667357969	\N	\N	Triệu Hoàng Vinh	https://s120-25-ava-talk.zadn.vn/4/142786e2e28893f800bd68c5fd174cc5.jpg?key=wsejnMZ6A_wXbSGeekITVA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.274	2026-05-04 02:46:14.274
db42ee72-6b12-43c9-a38f-e95c3f91812f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7024021364864157309	\N	\N	Kim Tiền 阿銭	https://s120-25-ava-talk.zadn.vn/60/1ee3ebfbe6a912159ed4fa0cc1df90bd.jpg?key=6TVmTURyQnADt4xgKXZtTQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.279	2026-05-04 02:46:14.279
bb27d378-6492-4666-a783-d7e2f2c85844	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8489507024238786775	\N	\N	Lê Thị Khánh Ly	https://s120-25-ava-talk.zadn.vn/18/c85e9004e94778ffa4379bd46b2e292a.jpg?key=-R3OU1lbNtGW2bmK0fbuPw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.285	2026-05-04 02:46:14.285
e3e6fb31-48b6-450d-9a9b-cec9da93d1d0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3307485938597615329	\N	\N	Gạch men Tài Phát Lộc	https://s120-25-ava-talk.zadn.vn/7/0f19a7a96d742a8865aa35b726e02d71.jpg?key=d3g1HiKntCLaHLUwL8QkMg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.291	2026-05-04 02:46:14.291
4a49ef64-b46a-45a8-b5ed-890e9860fa51	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8574809374670427384	\N	\N	Hoàng Quốc Tú	https://s120-25-ava-talk.zadn.vn/5/deb324c989c197b41d04a2385801efd7.jpg?key=n7GYfrp4BI7ILgTDk94Ezg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.295	2026-05-04 02:46:14.295
f95e7ad4-4626-4abd-a290-de9a1e4e07e8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8222811147174081050	\N	\N	Thanh Trần	https://s120-25-ava-talk.zadn.vn/6/78ed14391a8ec8488e9d2026c8644c0e.jpg?key=vPMH3ViUhZ_3MGE8icNs6g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.303	2026-05-04 02:46:14.303
55f320f3-2ddf-49d9-89d6-074cf39b7f05	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8512023950613203751	\N	\N	Bích Ngọc	https://s120-25-ava-talk.zadn.vn/5/0c4b461d4d67106056d5c0787872024a.jpg?key=5qrJcQi1clH4TEaK11-l9w&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.311	2026-05-04 02:46:14.311
6ab896ff-244b-45f6-a521-27859d9cd818	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3617953891114654258	\N	\N	Mẫn Trần	https://s120-25-ava-talk.zadn.vn/44/f107b26f61e71aaa9a17e938bcc605eb.jpg?key=HRNhpsepu48Ftlb3K7ha0Q&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.323	2026-05-04 02:46:14.323
8a9c841e-91f0-4977-bbf9-77f27addc206	ecae3be0-2ff7-4547-bf7a-308be16a20ad	750600057280920941	\N	\N	Phạm Văn Trường Sơn	https://s120-25-ava-talk.zadn.vn/16/855f61583995956a091f3b2161cb740a.jpg?key=1xFfv3_tMSadEdGa-l9ryg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.33	2026-05-04 02:46:14.33
c91e0399-9185-43ec-80d1-e534098adf49	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5930664149914059338	\N	\N	Hải Huy	https://s120-25-ava-talk.zadn.vn/8/66389049cb0bc56f850c7d8826af856e.jpg?key=h0198efczJnzkst9TCVKTg&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.341	2026-05-04 02:46:14.341
36543d4c-50b4-47a4-a429-ace3f6e76e67	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2880504870176932862	\N	\N	Hữu Toàn	https://s120-25-ava-talk.zadn.vn/51/6f9454a94f97fb371ec865e7f728b1bc.jpg?key=7dWBUbcm5p3oGjZNakMWuw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.346	2026-05-04 02:46:14.346
59bdc5ad-b68d-41cf-8ebc-b9501681e168	ecae3be0-2ff7-4547-bf7a-308be16a20ad	60130993113843922	\N	\N	Lam	https://s120-25-ava-talk.zadn.vn/13/08f26d1bd7e16d923ea1639160ccae6e.jpg?key=oj91Rb3pdb59NkUMR_rWHw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.353	2026-05-04 02:46:14.353
c519cd67-977c-4a55-b01f-e8973006c4e2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4149230829009219986	\N	\N	Lê Đức Huy	https://s120-25-ava-talk.zadn.vn/5/64bd5c2dc7c371a9d91c0c5396626472.jpg?key=wvWzHEMAsEUjP_4mYuDg8g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.356	2026-05-04 02:46:14.356
f2afd008-d38f-47a6-b3e2-b2a79652474b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6947579459661502317	\N	\N	Trương Luân	https://s120-25-ava-talk.zadn.vn/6/51d718484e2cc90f498c052d22b564b7.jpg?key=uaJ542VaGswwQqsiyJAnjQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.363	2026-05-04 02:46:14.363
fca685a6-2d69-4847-9294-23283f37a04d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3628368534594254173	\N	\N	Phạm Mỹ Cảnh	https://s120-25-ava-talk.zadn.vn/6/d5039db149b35bfc8432d84bb5f39a47.jpg?key=eKN1cbddaxXf_iK3xhJ0DA&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.37	2026-05-04 02:46:14.37
abeb2b3b-361d-4cb0-af36-5e4345420761	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8361295753266978830	\N	\N	Ngo Bao	https://s120-25-ava-talk.zadn.vn/26/480d9313ae1b2883e6267996593a5608.jpg?key=dByjA7gJjCVKUb0HkaXQgQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.379	2026-05-04 02:46:14.379
efa05a56-d0c5-4380-bb36-65313ad46e7d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3670032301056967145	\N	\N	Y O U R S A L E S	https://s120-25-ava-talk.zadn.vn/22/89f4dbf88e23d24da6f241f0ff7b9164.jpg?key=wc_8vTXXuwvoOEk77thagQ&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.391	2026-05-04 02:46:14.391
73dd3460-980a-4a90-9ab9-0ac0035b53c3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1336769012085064330	\N	\N	Thanh Phong	https://s120-25-ava-talk.zadn.vn/14/c55d9c9b477810e72376159304a525e8.jpg?key=ipyJMd3RIyikXrKeLZkq0w&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.396	2026-05-04 02:46:14.396
6ca23cbf-6944-4417-a29d-6d1b18a8d7c2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9056702170060804008	\N	\N	Nhân Thăng	https://s120-25-ava-talk.zadn.vn/1/7c003b200e72b237e2587055f1d34f72.jpg?key=L97IE_rpFAFTVZ_7vyWWFw&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.4	2026-05-04 02:46:14.4
690e664e-5852-433c-88ab-70c1ca02b133	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5899850777258929383	\N	\N	Hồng Phát - Mss Thảo	https://s120-25-ava-talk.zadn.vn/1/88bd263651189baef401eb8f8a522233.jpg?key=XXUJu_7imKTM6zozwGSj2g&time=1783046773	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.404	2026-05-04 02:46:14.404
e67001a2-6228-4f5b-8204-155910c04ab6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1728961364013020409	\N	\N	Sinh viên tốt nghiệp đợt 3 2025-2026	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-05 08:51:58.606	2026-05-11 08:54:56.537
77a2b195-8a03-44cd-a43d-f7a2badebb2f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6212974401618113343	\N	\N	Thanh Ngọc	https://s120-25-ava-talk.zadn.vn/57/00dde02397d1580afedc1ddc2acdfea9.jpg?key=K7SR9OTpL5HpLpUF69ygNg&time=1783153078	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-05 02:43:40.688	2026-05-05 08:17:58.11
73f2a81e-4a8b-4704-89da-268f8b05d7fa	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5860025765213937237	\N	\N	Thi Tiếng Anh CDR- TTNN-TH	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 11:37:07.469	2026-05-11 08:54:55.122
c201b98e-c402-42ad-8bde-5b99ba7104ef	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1051917401023679134	\N	\N	Cung ứng việc làm DNTU 4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 02:54:42.583	2026-05-11 08:54:41.326
d7c3ebd4-46d4-4c4e-b02e-b633d8204c72	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1151566821602093564	\N	\N	Cung ứng việc làm DNTU 6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 09:24:02.898	2026-05-11 08:54:47.907
1d17d3c1-1fa9-4270-b074-e9332916f60e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7907981006912605881	\N	\N	ĐOÀN THANH NIÊN - KHOA -CNTT -TT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 07:57:45.758	2026-05-11 08:54:54.147
ff3a72d4-7cdf-4c0d-8e8a-df24ca4cf296	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2919054366868027269	\N	\N	Quách Thị Bích Nhường	https://s120-25-ava-talk.zadn.vn/4/64b8b22af4367be45ff4a8cffea9295f.jpg?key=N-agUEKKoAgE16Y_FmdDmA&time=1783581958	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-10 07:25:59.012	2026-05-10 07:26:10.067
dd7f59ce-338e-49dd-8e6e-9d433ce2c6c0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5611606458481225959	84764390598	\N	Hồng Cẩm	https://s120-25-ava-talk.zadn.vn/1/721f4322f62b1a1407322b6c47e0f376.jpg?key=fn4rlJGy7iZhwvKY0dApvA&time=1783046773	\N	\N	2026-05-11 02:18:36.888	new	\N	\N	\N	[]	{}	2026-05-04 02:46:14.125	2026-05-11 02:18:37.383
70dabc0a-f4e5-4d63-b87e-1bbde496c8fc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1378859464005364773	\N	\N	3 Thằng Nhóc	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:06:57.73	2026-05-11 08:54:22.213
26c941f4-4a34-431f-8b4d-5dac8159dccc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3983472672505193039	\N	\N	Đề tài tốt nghiệp Ai agent - 2025-2026	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-05 23:03:32.275	2026-05-11 08:54:22.693
fa28430a-5fe8-4235-968e-8c9e35bd4b8e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8094742771760347985	\N	\N	Đầu Tư Kiếm Thu Nhập	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:06:59.84	2026-05-11 08:54:23.18
d4b817f8-7ca0-4fdc-9a36-a094fe8e94f3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7046568866673571533	\N	\N	XẾP CHỮ 30-4 (NHÓM 2)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:00.534	2026-05-11 08:54:23.655
f3ff2727-819b-4c5a-8818-1e56a4326f1f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3801643491372886981	\N	\N	Bot_Fb_CmtNew	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:01.216	2026-05-11 08:54:24.123
76755379-4edb-48f0-8ed8-7a6ee807049b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5422166373520501048	\N	\N	PLĐC tiết 101112 ( group 2)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:02.565	2026-05-11 08:54:24.593
c9671033-dafb-4005-bbae-5fea0e8b77ea	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8824073806647235186	\N	\N	Ngày hội việc làm Sân bay Long Thành	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:03.336	2026-05-11 08:54:25.065
7b0b4961-1105-4078-b2be-79c99e402d21	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9094124477512472371	\N	\N	TA chuyên ngành CNTT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:04.706	2026-05-11 08:54:26.001
0bb0c50d-43e2-4533-b3fc-07afb4c416d1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7092169329974023019	\N	\N	Ốc Tiêu ( Thông Báo )	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:05.397	2026-05-11 08:54:26.47
8ef2c08c-7220-4805-ac8f-b186ffbd575e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7562604454813992692	\N	\N	Thứ 4-Lớp GDTC2 Bóng Đá(789)⚽️	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:06.084	2026-05-11 08:54:26.939
4be15d06-8470-4a57-9232-a250480e9680	ecae3be0-2ff7-4547-bf7a-308be16a20ad	89833810979300152	\N	\N	chơi game free không tốn lòn gì hết	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:08.473	2026-05-11 08:54:27.892
f0fd594f-fab1-4ac5-bb13-de292df7dd3f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1066570097551269578	\N	\N	Minh Lâm, Nguyễn Trinh, Trần Vy	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:09.196	2026-05-11 08:54:28.358
a00ee101-a1d6-47ba-bdae-565b9e8e2ce8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1501168729895460050	\N	\N	Nam tước	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:09.886	2026-05-11 08:54:28.826
61b808c1-903b-41cf-b66c-d97bbd051256	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1775609764151337379	\N	\N	TKW_K17_ChiềuT3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:10.57	2026-05-11 08:54:29.299
170eaf08-ba2f-4ad8-bc5f-b4e2b26e8d87	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4080573729362445478	\N	\N	tiểu đội 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:11.263	2026-05-11 08:54:29.779
1c601923-e0a2-4985-98a0-59f2a66f5521	ecae3be0-2ff7-4547-bf7a-308be16a20ad	194539214468000948	\N	\N	Gia đình iu thương	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:11.944	2026-05-11 08:54:30.281
7d386393-a933-4f07-b519-c63fe7a50b3f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4071421918013728135	\N	\N	Nhóm 1 anh văn	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:12.629	2026-05-11 08:54:30.748
a8ab9231-3248-4ace-bd5e-d5b77ea6473f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8873600464055681826	\N	\N	BAN CHẤP HÀNH _ ĐOÀN KHOA CNTT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:13.313	2026-05-11 08:54:31.223
e24643b2-8a5f-4337-8d61-4921fd289ce3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2371019760478378720	\N	\N	Rss	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:13.997	2026-05-11 08:54:31.696
f148ed28-bba5-4095-874e-e0224cc9609c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2079734372083228123	\N	\N	Nhóm Kỹ Năng Mềm Real	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:16.392	2026-05-11 08:54:32.672
cd683344-120c-4d6a-b54f-feac960f7f7a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7543749161732064695	\N	\N	Iot chiều thứ 5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:17.073	2026-05-11 08:54:33.139
c6baf205-241c-47ef-8f45-10f43d954edd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6124175347389412602	\N	\N	Nhóm làm TKHTM	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:17.758	2026-05-11 08:54:33.607
1f69865c-9fdc-44f3-9c92-f80bf136c896	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2722567677942886607	\N	\N	22_23_Hệ quản trị Cơ sở dữ liệu_sáng thứ 3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:18.455	2026-05-11 08:54:34.08
cda781f4-c5f6-49e3-8def-6af32ac2a82e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	590289547735442486	\N	\N	Nhóm 2 (51-100)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:19.143	2026-05-11 08:54:34.56
bd2f4a6e-3734-4062-82c2-c61637d6e394	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8595229808384254543	\N	\N	Test5s	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:19.833	2026-05-11 08:54:35.028
3aef65ae-a6b1-46ee-b249-fb4788038c83	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5331263858931509499	\N	\N	THDC-K21-CT5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:20.535	2026-05-11 08:54:35.498
2751c5b2-aadd-43d9-a9d9-0652f0443a3c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2609045895282789426	\N	\N	Báo con 🐆🐆🐆	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:21.224	2026-05-11 08:54:35.97
eb2d3d1a-8631-43a3-9b3c-e82237a6aece	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3649196476822293411	\N	\N	CTV	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:21.908	2026-05-11 08:54:36.447
52be5f0c-e638-4d2f-9b31-ba216dd24ebc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1153111552709004551	\N	\N	21DTH1_DNTU	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-08 00:07:41.244	2026-05-11 08:54:45.561
9c004615-7359-49ae-bb3e-56f9437e67e3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3746463315222450425	\N	\N	Fitness T1-3 Thứ 6(09/01/26)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-07 23:44:16.28	2026-05-11 08:54:50.306
7608f110-63f2-4e03-ae63-79033b23c4e2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1188675449747403384	\N	\N	K17_NHÓM TRƯỞNG KHÓA LUẬN	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-10 02:01:30.574	2026-05-11 08:54:56.06
2a69c9b1-0c35-4daa-81e4-aa3deda2db68	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5296627932035274118	\N	\N	GIẢI TRÍ - 1CAR	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-07 04:25:10.638	2026-05-11 08:55:07.86
5a045a6b-d3ab-4229-a148-7cb70b92ca85	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4577395869554549889	\N	\N	21DTH3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-05 09:14:06.097	2026-05-11 08:54:20.8
dcfb3ea5-ecde-4c5e-8e1b-018a9c5e9615	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6378755474033425	\N	\N	CNXHKH_0070173.4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:06:56.33	2026-05-11 08:54:21.271
9b28bee6-af2d-4def-81ea-7d3bc7e0b345	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6177519038509347517	\N	\N	phương pháp tính	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:06:57.026	2026-05-11 08:54:21.74
e1dd22eb-051a-44bb-a1af-3898912ad5b3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8696121609163951017	\N	\N	CHUYÊN ĐỀ CÔNG NGHỆ MẠNG	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:27.096	2026-05-11 08:54:39.335
624f5916-dc63-448c-831c-343ed760fed0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8063689222712825312	\N	\N	Website 1CAR Talent - HIỆP IT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:29.719	2026-05-11 08:54:40.276
61796b3e-f5db-469f-8ed7-ee0a2f19c1f0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7271754842298225645	\N	\N	Training 3D - Online	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:31.102	2026-05-11 08:54:40.816
ce7cb1a2-8882-4bab-894a-540144f50409	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4051302576088915006	\N	\N	PT_TK_Hệ Thống 😗	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:32.512	2026-05-11 08:54:41.797
aa51de0a-ed75-4ad6-b47d-8b4cbe378fe3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9159988405536881689	\N	\N	HỖ TRỢ BỔ SUNG NGÀY CTXH CHO SINH VIÊN KHÓA CŨ	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:33.193	2026-05-11 08:54:42.271
233e79aa-4d6c-4b18-93e7-36563ca0d226	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6554847223799984368	\N	\N	Đội Nhóm Trưởng	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:33.903	2026-05-11 08:54:42.743
04064197-487e-4473-a0ad-eed40b15df8e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2472482735985192791	\N	\N	Quản trị mạng Tối 3 - 2023	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:34.582	2026-05-11 08:54:43.218
b3cb3a50-130e-4a6f-9c89-e774c4b9f26f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3395217839606115353	\N	\N	NGÀY HỘI VIỆC LÀM 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:35.262	2026-05-11 08:54:43.689
bab1031e-1ff5-429f-984c-1cb7cfe552c0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5004171251156036213	\N	\N	scam	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:35.986	2026-05-11 08:54:44.158
4008e350-e6e0-45bb-bc29-7ffd73c7b02e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3629778638870278232	\N	\N	CTDL_GT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:36.67	2026-05-11 08:54:44.626
2b365607-4631-4932-926d-3524dd217459	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9003638150981980916	\N	\N	nhóm kỹ năng lãnh đạo và quản lý	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:37.347	2026-05-11 08:54:45.093
44ec4380-44f8-4b32-97bc-3e044f28ac74	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5329419338022822386	\N	\N	Nhóm 6 công nghệ mạng nâng cao	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:38.708	2026-05-11 08:54:46.031
5a457421-13ce-4a29-a583-ffabdff837e3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1747311573792176696	\N	\N	Ngọc Rồng Origin - Box Chat	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:39.393	2026-05-11 08:54:46.499
798031d3-01d9-4003-81e2-7af9773f77f0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3103705119462499349	\N	\N	Chúng tớ là 12A3🤟🤟🤟	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:40.081	2026-05-11 08:54:46.969
ad0a8b0d-c229-43d6-9fc8-499296798944	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8701468137926403270	\N	\N	Nhóm 1600-1592	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:40.76	2026-05-11 08:54:47.438
3264d860-5cda-470e-8d8e-a4459dd5f6e9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	98134877466640475	\N	\N	nhóm kn khởi nghiệp	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:42.846	2026-05-11 08:54:48.375
ee3c3024-8059-441a-94d5-c23f508463f3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2001866012699840207	\N	\N	1CAR - YOURSALES - SMS OTP	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:43.527	2026-05-11 08:54:48.856
b799ab83-d7af-4a6f-a93a-e6b6b6728f6b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6762098583920416720	\N	\N	CloudFly - Hỗ trợ sử dụng N8N DashBoard	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:44.208	2026-05-11 08:54:49.329
02d678dc-7c75-4812-8e51-3a88782ea927	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7252331083136097442	\N	\N	VPBank Technology Hackathon 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:44.887	2026-05-11 08:54:49.83
e7e6dd64-e456-4a19-a0ad-5cf995acf54c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1756471503292523879	\N	\N	HK2.2223 TT3-G303 Quản Lý 0879163839 Lt đ Hoài	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:46.941	2026-05-11 08:54:50.805
2e4f117d-c3a2-4283-9df8-9f0b72e69d3f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	997865888976390622	\N	\N	NTB 1633	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:47.645	2026-05-11 08:54:51.272
241953bf-37cd-4783-ac50-b78ae2ca8f32	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5698296576008898067	\N	\N	nhóm 3, công nghệ phần mền	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:48.356	2026-05-11 08:54:51.754
b1930f41-ca15-4141-8aae-e53a4231f054	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2118997815892830319	\N	\N	Check bot	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:49.05	2026-05-11 08:54:52.229
85d27597-b5bd-4e1d-ba5b-be94e09783d6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1647900920563946969	\N	\N	1CAR - Phòng IT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:49.731	2026-05-11 08:54:52.699
54bb73b3-849c-4e48-923f-915f3cecee83	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2101414264399767854	\N	\N	Đại đội 5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:51.079	2026-05-11 08:54:53.175
59a28497-e117-4ab5-a5f9-7e0c88e6c0c4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2435749988293865930	\N	\N	THIẾT KẾ HỆ THỐNG MẠNG_SÁNG 4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:56.342	2026-05-11 08:54:55.591
ea9b933a-d622-49d1-9170-4ba25b0edd8c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5689422030318315507	\N	\N	Chém gió 1580	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:54.18	2026-05-11 08:54:54.614
72c1235d-d05e-4153-8f20-1ec012bdb6c8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1243418431723785542	\N	\N	K17_HỖ TRỢ XIN THỰC TẬP_KHOA CNTT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:59.643	2026-05-11 08:54:57.006
60168ce5-19a7-461e-a901-dd4bf47189f8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2428851805107554738	\N	\N	ppnckh nhóm 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:00.339	2026-05-11 08:54:57.473
fa1971a2-06b8-45a4-a6a9-58cb9639d393	ecae3be0-2ff7-4547-bf7a-308be16a20ad	138255639096981484	\N	\N	Nhóm 1| Bockchain	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:01.036	2026-05-11 08:54:57.946
7aab5b0b-d862-4a3a-a63e-858b9f28e77e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1342984663005375652	\N	\N	2025 TACN Chieu T4 T6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:01.76	2026-05-11 08:54:58.412
323f1d11-a027-476f-aa79-278133101695	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7911211198102223565	\N	\N	Registration: VPBank Technology Hackathon 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:03.178	2026-05-11 08:54:59.375
d1d9d5c3-0822-4c8e-92df-824a7efb2d4d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	343302843501501124	\N	\N	Ae T4 VnH kingdom 1600	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:02.45	2026-05-11 08:54:58.877
75a3be9d-b507-414e-8a5b-fde0934a500c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6825624186729331390	\N	\N	Bơi Lội - Thứ 4 - Tiết 7-10	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:03.876	2026-05-11 08:54:59.841
6665f9f9-ef57-45bc-8816-b8355eab1844	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5665346085205363864	\N	\N	Cô Liệu hướng dẫn thực tập 25_26	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:25.032	2026-05-11 08:54:37.894
46872119-9c1e-46be-99eb-5e91b632938b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4448177584679525308	\N	\N	Nhóm 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:25.726	2026-05-11 08:54:38.394
0c19d285-d92d-4871-aae8-18dee98b5b7f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5716733438302127954	\N	\N	HK2.2223 TT3. LĐQL Kết Thúc hP	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:26.414	2026-05-11 08:54:38.866
77119c33-e676-4377-8607-fca06c2dea64	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3365195044584063156	\N	\N	Thành Vinh	https://s120-25-ava-talk.zadn.vn/9/1d82a952930a2f7e1e417707bcf59421.jpg?key=CmKD-5APpbGOk6hYRTj3hA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:27:28.171	2026-05-11 09:27:28.171
dccb9714-7fd2-4b2a-9df2-191efe0ac642	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5199815831260101678	\N	\N	Bảo Vân	https://s120-25-ava-talk.zadn.vn/18/a468f65558656518657f74b04c96fc04.jpg?key=uIGvW4MjZJEangjq3RRzLg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:27:32.793	2026-05-11 09:27:32.793
86894f6e-b0c2-41c7-891d-71ebbef1633f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2377225580510953722	\N	\N	Bình Hải	https://s120-25-ava-talk.zadn.vn/8/c069d8aa8b7ea7b9e058e0a4fd0183d1.jpg?key=a-Jfa1-7bRGc8conLbUo-A&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:27:37.412	2026-05-11 09:27:37.412
0e73599d-e0ab-49c8-ab95-f5bd16919929	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6997004832864396829	\N	\N	Tuấn Phương	https://s120-25-ava-talk.zadn.vn/11/45a05f856c50c2937080a9760d831f75.jpg?key=cJJpCLVhE3FIbGV0ywo9Yw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:27:42.034	2026-05-11 09:27:42.034
a1d913af-008a-48d5-aca6-2965ae0ac99e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4363568070414806921	\N	\N	Lê Trung Hiếu	https://s120-25-ava-talk.zadn.vn/9/34c8c15b2c3ef696ccf2ea1951a13000.jpg?key=DXR_ruZRE7dEu9gAh6-ThA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:27:46.649	2026-05-11 09:27:46.649
08982a8d-f4df-4e44-86ea-9c986e8d2ccb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5899788998825389287	\N	\N	THỰC TẬP - 1CAR GARA BIÊN HÒA	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:22.602	2026-05-11 08:54:36.958
b4ca4af2-1778-448e-8426-e85e6fdb3b74	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1909286789282003064	\N	\N	CNTT_Khóa 17 (21DTH)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-04 06:14:57.559	2026-05-11 08:54:37.424
3574d3af-9757-4303-b7ba-033ab4740734	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9157460395104401170	\N	\N	Ngọc Rồng Private - Hỗ Trợ	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:51.768	2026-05-11 08:54:53.646
47094333-0304-4779-be0c-0909571b243b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3166179562918692599	\N	\N	HK1_2025_ThiGiaMayTinh_8.5 Chieu T5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:04.569	2026-05-11 08:55:00.312
05c4b4bf-7495-447a-8d14-2f769f15982d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7249519188486840988	\N	\N	Thực tập IMT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:05.258	2026-05-11 08:55:00.782
1d3aa64b-5fb0-4320-bc68-6ea0479a0784	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6046630024602298350	\N	\N	PPNCKH thứ 3, 4,5,6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:05.94	2026-05-11 08:55:01.249
d3534673-fbf5-4d4b-afad-4d26c2133108	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5898439783757551580	\N	\N	Chiều thứ 2_Phân tích thiết kế hệ thống	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:06.627	2026-05-11 08:55:01.735
c41c43a3-5916-4107-8a08-752a4fc066d9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4527671274784814802	\N	\N	Lư Văn Anh Tứ, Đình Trường, Nhật Nguyễn	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:09.405	2026-05-11 08:55:03.627
2058baad-ba6a-4759-86ff-7552b0c6ef77	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5388660826290233295	\N	\N	test5s-2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:10.101	2026-05-11 08:55:04.094
65e6ee3b-0ec3-4370-8c29-eec8e2d7ac27	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8231969568510759482	\N	\N	Khôi Bad, Trần Nghĩa Hiệp,...	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:12.151	2026-05-11 08:55:05.047
a46d9b00-609e-4738-9f3c-80f9a4914d80	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8894569411149203816	\N	\N	nhóm làm bài	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:12.831	2026-05-11 08:55:05.514
3ae27e7b-21b2-45c6-a7e6-4d6425e14d92	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3372361451628068554	\N	\N	Huy, Đậu, Trần Nghĩa Hiệp	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:13.516	2026-05-11 08:55:05.981
d31f92cc-7a40-4cc2-90a0-da9c6b2020ba	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3607273294922883080	\N	\N	Nhóm 8 CSDL nâng cao	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:14.196	2026-05-11 08:55:06.446
bd3efe93-9ea9-45ec-84c2-fd6cbce02a60	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1523818911020526882	\N	\N	Trí tuệ nhân tạo 123	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:14.882	2026-05-11 08:55:06.918
70ae531c-06a7-4fda-8a8a-81c5f18a3716	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5193452114407638805	\N	\N	A1 thi 17/6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:15.564	2026-05-11 08:55:07.393
c31680a8-2a6c-4566-8541-cc47358f9693	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2334852433584249440	\N	\N	CNMNC2 s56 g202	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:17.926	2026-05-11 08:55:08.326
803a872d-d3e0-40af-8c97-9c5c1b34bd49	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3395582845455412504	\N	\N	Hết Cứu 🧠🧠🧠🧠🧠	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:18.641	2026-05-11 08:55:08.845
d6657f80-e75d-4cfb-adcd-ca05812e6231	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1318766047664325194	\N	\N	Minh Lâm	https://s120-25-ava-talk.zadn.vn/19/300552fa1e5fb484e2413f5804e9b6f4.jpg?key=iRDz3-8z7m1vg5hyFDXqUw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:27:51.257	2026-05-11 09:27:51.257
0b38071b-24e6-450a-8cdd-cdc329081199	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3370964796099328975	\N	\N	Tuan	https://s120-25-ava-talk.zadn.vn/13/9fc14af5f6785d0521689c41b6e931b9.jpg?key=Get45qBfRdBoTioJ7DIGLg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:27:55.863	2026-05-11 09:27:55.863
1087adff-a5b8-42c5-9769-ca50eddb665d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8511069149540513306	\N	\N	Technology NGICORP	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:10.833	2026-05-11 08:50:27.562
24442792-1db0-4ff7-9655-9a280b2191cc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1130453685897962167	\N	\N	Bhuy	https://s120-25-ava-talk.zadn.vn/7/047d22584e3688d5ccf226f7e4e99ece.jpg?key=pycVPfdiMMGYn4ehxOdEjw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:00.465	2026-05-11 09:28:00.465
bc1343ea-3c23-4915-948d-5969210133ee	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4071421918013728135	\N	\N	Nhóm 1 anh văn	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:07.278	2026-05-11 09:37:07.278
6baa7c4d-ba2b-4304-8f67-8a856613cf5f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	247597133607989608	\N	\N	Lập_Trình_Web_ChiềuT4😗	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:06:54.19	2026-05-11 08:54:20.325
fbf7df03-dc08-4a4b-a987-f049b58b4358	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2341451846483559289	\N	\N	NHÓM HỖ TRỢ CÔNG TÁC NHẬP HỌC	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:07:04.016	2026-05-11 08:54:25.534
3818c757-0a5c-4139-848f-1c8c94a9d267	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4860181653371989109	\N	\N	KHOÁ LUẬN K17	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-02 07:09:03.168	2026-05-11 08:54:27.409
bd7af861-3466-4c49-bfbd-fcc12733f9ca	ecae3be0-2ff7-4547-bf7a-308be16a20ad	246336029840242028	0925525263	hiephiep1002@gmail.com	LEO SLAYER VÀ NHỮNG NGƯỜI BẠN LORDS MOBILE	\N	FB	\N	2222-01-20 17:00:00	new	2323-03-01 17:00:00	\N	\N	[]	{"isGroup": true}	2026-05-02 04:58:31.389	2026-05-11 08:54:32.204
12f3556f-33b1-42d4-afe7-421f431fb920	ecae3be0-2ff7-4547-bf7a-308be16a20ad	461662787190518639	\N	\N	Gia đình mình	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:07.307	2026-05-11 08:55:02.214
4ddb66e2-a98f-416d-a23d-79e088d79a65	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8483183673842586301	\N	\N	Nhóm tài liêu	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:07.998	2026-05-11 08:55:02.689
1c6487ec-2b88-4a76-b0ad-8382a4fd94e0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4355685771079308149	\N	\N	Cấu trúc rời rạc	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 07:08:08.705	2026-05-11 08:55:03.16
3d192e86-5ede-4c06-8ddf-5cb047090f6e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8590853056949506623	\N	\N	Vu Xuân Trường	https://s120-25-ava-talk.zadn.vn/50/a5d7279981b52c6e0d13934ee683f43f.jpg?key=nqiaLf-tg7zBrujj6Gq6iw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:27:23.401	2026-05-11 09:27:23.401
d2144fad-6f83-4786-a62b-5fbf1b428504	ecae3be0-2ff7-4547-bf7a-308be16a20ad	892335756337869669	\N	\N	Học Giếng Khoan	https://s120-25-ava-talk.zadn.vn/57/ccbe5080d90c0609b23fb70b9da336cb.jpg?key=_EVgyM6_M5L4h3zPRngndw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:05.073	2026-05-11 09:28:05.073
9d006627-52d3-49aa-acb2-b50a22150cbf	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5874788356599630720	\N	\N	Thắng Trần	https://s120-25-ava-talk.zadn.vn/21/f715c38edb2c4cae7d124f45276c8f40.jpg?key=yWAAgiLW_J8OhiyAcQ_HEg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:09.684	2026-05-11 09:28:09.684
828927be-0b2e-45e6-8fe6-c1933ef14097	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7533351490509930124	\N	\N	Quân	https://s120-25-ava-talk.zadn.vn/35/c316e9cfd6db16597a42c91a1085b9f2.jpg?key=DY7_0jNNIeS0z5tYUznMeA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:14.294	2026-05-11 09:28:14.294
eeccc221-4efa-493d-8745-0cd4914b9ed1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5529985907955986361	\N	\N	Thanh Huyền	https://s120-25-ava-talk.zadn.vn/139/698427b826a07cb208e62e1bd6747ae4.jpg?key=noMgws962scTMW3oG6jkJg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:18.898	2026-05-11 09:28:18.898
8e779835-38ba-484d-9579-fd98e1ec8f21	ecae3be0-2ff7-4547-bf7a-308be16a20ad	968339493716156535	\N	\N	Phạm Anh Tuấn	https://s120-25-ava-talk.zadn.vn/45/245be5efe0ece3eb6989d8c0ece1bdd1.jpg?key=5ISj8EgDUSDvBNGnBJftLA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:23.507	2026-05-11 09:28:23.507
dbcc0a6f-bf28-40a3-9f72-0ae033d1410f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9112994558292890736	\N	\N	tung phat	https://s120-25-ava-talk.zadn.vn/2/4743bf5f3fc59ddd0caf006f4e9418de.jpg?key=vZ-4Z4MVVMk1s4JusNzVxA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:28.112	2026-05-11 09:28:28.112
9f8663dd-0b85-4b3d-a0b6-64eed1a1791a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7491386531983166705	\N	\N	Hùng	https://s120-25-ava-talk.zadn.vn/1/16f15a2c7f8714a28efcc01e8e546145.jpg?key=VbZPulDrMDJ8Zqqmb2Vx7A&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:32.718	2026-05-11 09:28:32.718
86b10ccf-ac0f-44d3-9c11-5ad12b828ad4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1391940534205472598	\N	\N	Nguyễn Văn Quyết	https://s120-25-ava-talk.zadn.vn/18/10822971154fd0ce762285e8f382e45a.jpg?key=dZd1yf4FENAa2zoFTQRBLQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:37.323	2026-05-11 09:28:37.323
1e659aa5-08c8-4db5-9787-86ea507e13bb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	106465284304135805	\N	\N	Minh Vương	https://s120-25-ava-talk.zadn.vn/21/7421420438ee8cf99f808f581b5a7f15.jpg?key=J1zcuHwRITg43lA-dyK_JQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:41.93	2026-05-11 09:28:41.93
4d5e48c1-ced6-4ad0-bc6e-d41a6400de25	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5027984576024583873	\N	\N	Nguyễn Đình Thuật	https://s120-25-ava-talk.zadn.vn/11/6317ec417b8dd4df39a8048ac3bb3463.jpg?key=MVv0KmYqVShHpAJe2ku_Ew&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:46.547	2026-05-11 09:28:46.547
b80f9bff-fa79-422b-a3dc-9daaa9edeade	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7973708775326145455	\N	\N	Hưng Nguyễn	https://s120-25-ava-talk.zadn.vn/3/24db55890f4814b7044aa6f9797dd838.jpg?key=2k9jpOEhnsDLrw7YB0gODg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:51.157	2026-05-11 09:28:51.157
7dbd93f0-5ad6-4422-a410-02de1b628d03	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5843532481371558943	\N	\N	Zalo	https://s120-25-ava-talk.zadn.vn/36/16782d311b12da6d28daa13e343986b8.jpg?key=YPcCUZ9BzrDGSTUFpciPAw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:28:55.757	2026-05-11 09:28:55.757
d74913f4-ddc5-4ec6-b420-6c7dd66e7e41	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1020544710927759918	\N	\N	Đati	https://s120-25-ava-talk.zadn.vn/37/0bf74bd37a074d1e9f0d545e07755798.jpg?key=7NCfOazVnXgtnDyuOsi_lg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:00.358	2026-05-11 09:29:00.358
179b4437-63c9-419d-ab96-ea6f6082e3ad	ecae3be0-2ff7-4547-bf7a-308be16a20ad	813938803663625548	\N	\N	Huệ	https://s120-25-ava-talk.zadn.vn/101/a61a879fda9581de34de1b23d1634170.jpg?key=7H9A60zdC4f76xJGVxMo0A&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:04.966	2026-05-11 09:29:04.966
c02e926c-4f5f-4462-a16d-a980aab0b683	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5589094428963815575	\N	\N	An Nguyễn	https://s120-25-ava-talk.zadn.vn/1/87495ea8651a2c11c861bde3a502c6f4.jpg?key=rTgQX1jdeDy7caB5o9d0eQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:09.576	2026-05-11 09:29:09.576
98d0554e-a302-42b2-9b5c-db52b1fe883e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6663625746799179902	\N	\N	Bao Bao	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:14.184	2026-05-11 09:29:14.184
1ab5f197-7369-48e7-ac3d-2630806daf93	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5227378038088588940	\N	\N	Nguyễn Sỹ Hiển	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:18.781	2026-05-11 09:29:18.781
3a4450f6-4c2f-4f52-960d-b46ad395fb07	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6142746758236927800	\N	\N	Nguyễn Nhật Huỳnh	https://s120-25-ava-talk.zadn.vn/14/100eedf230c8fcc7a2d5f1c5091a721e.jpg?key=IGVDIAxjHE8ewdBij6V9Og&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:23.384	2026-05-11 09:29:23.384
34077eb2-9f38-449f-a7e8-8ea26228726f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8652078511014082325	\N	\N	Tiến Lộc	https://s120-25-ava-talk.zadn.vn/6/961eb945114df9ff085bb84343eaf0c6.jpg?key=GA_N_aCZGk0KpD6Jaj9sAQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:27.99	2026-05-11 09:29:27.99
5ee8864e-393b-41ef-adb2-3e8a98b386b2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6918032632913067014	\N	\N	Đình Ngân	https://s120-25-ava-talk.zadn.vn/4/dd103a5fcdc46b42458a6e03d3a85d8a.jpg?key=_jAwG2RcW8_CypP8ma1BQQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:32.594	2026-05-11 09:29:32.594
d8ccc4b5-05c7-40f5-bbf3-8b942a8e5b19	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7624815288856388823	\N	\N	David Lee	https://s120-25-ava-talk.zadn.vn/8/a334ef703a73fcb0379f2ba1c037c16c.jpg?key=-6LWYozlQb8eGsBDPmuLRQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:37.193	2026-05-11 09:29:37.193
490d2a6f-7b78-46fa-aa13-875ae372b319	ecae3be0-2ff7-4547-bf7a-308be16a20ad	442689131821776675	\N	\N	Trân	https://s120-25-ava-talk.zadn.vn/100/b1d08d2df83aab4633f925411628ee9d.jpg?key=d-E43yjZUgx96HCWjPxrfw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:41.798	2026-05-11 09:29:41.798
6b1d9e3d-b4a1-4ab6-92dc-02186b628241	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2075914187392143048	\N	\N	Trần Anh	https://s120-25-ava-talk.zadn.vn/22/713eb3a5350638c062edcdfc57215ad8.jpg?key=HernHjvE5fNzlXx7Rr2OEA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:46.47	2026-05-11 09:29:46.47
44cc9365-e34a-4e60-a1be-024885048bc2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5531375484717339332	\N	\N	Nguyễn	https://s120-25-ava-talk.zadn.vn/2/01072ef43e0d3554e40a419973036a88.jpg?key=QLiitnkO-IUbWvMMIjp2kA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:51.085	2026-05-11 09:29:51.085
b196a6b6-cce5-4792-ab90-e8a3255f307e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	810978846930818886	\N	\N	Larry Nguyễn Hà	https://s120-25-ava-talk.zadn.vn/13/e7dddbbe91176868021bbe76cac86219.jpg?key=KiH_7snHvrpCpdLgWK3Hvw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:29:55.71	2026-05-11 09:29:55.71
d0c301f3-6cb6-480b-9bb5-9f25718eeed7	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7826078619176594076	\N	\N	Trần Trọng Phúc	https://s120-25-ava-talk.zadn.vn/10/67e43fa6c8ff94903f55c347a1a69ba3.jpg?key=PHjJrTGyaSQds-tJjbrTSA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:00.319	2026-05-11 09:30:00.319
f47354a1-bed0-43e5-9b24-efd6569c55d6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9155780683281460488	\N	\N	Thuần	https://s120-25-ava-talk.zadn.vn/92/4d0dd370c6222f4d89b5eee3409ff6b8.jpg?key=BqTC5HwUBpnbHeWTaIRG5g&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:04.924	2026-05-11 09:30:04.924
037e2298-1774-4907-9788-a13529a0bfc0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1824701401457481301	\N	\N	Nghĩa Nv	https://s120-25-ava-talk.zadn.vn/6/17598219110c7a6719e15f93358e45e0.jpg?key=QXNcrBccI9OMXV-WsRvhQw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:09.546	2026-05-11 09:30:09.546
38144bec-b65a-48fe-afbd-7e4b4cb6c96b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6659667179765541484	\N	\N	Ms Loan Giảng Viên Tiếng Anh	https://s120-25-ava-talk.zadn.vn/321/86de4bf90952554691e221b8cf232de1.jpg?key=PzCiG50JKicchjhkVQ93pQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:14.168	2026-05-11 09:30:14.168
b9fd8792-a463-45a5-bffa-4a9b3b22b6bd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3510152909233036209	\N	\N	Vân nguyễn	https://s120-25-ava-talk.zadn.vn/12/7ade927de5dd3f61c699b8c28cc84c94.jpg?key=8mqREXpKBq5UPgve2bRsKQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:18.765	2026-05-11 09:30:18.765
65a2332f-22d4-4452-8eac-e97ad109347c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6794776306049124428	\N	\N	Mai Văn Minh	https://s120-25-ava-talk.zadn.vn/13/a4718df15a7c580add89b78633be2cc4.jpg?key=tCWz0ZL6GGFHuJvpZbNrAw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:23.384	2026-05-11 09:30:23.384
3a0c1096-2479-4116-b153-d1c42d455b2d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4422396749875642200	\N	\N	Khánh Huy	https://s120-25-ava-talk.zadn.vn/11/194efd5652ad9c6facf07b36717f0d9d.jpg?key=rXpi7kRdU290kNZiI25WTg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:27.986	2026-05-11 09:30:27.986
803f7a3c-d2fa-4b32-ad06-9c49ee290257	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5436396812168505206	\N	\N	Huy	https://s120-25-ava-talk.zadn.vn/26/31d4e9d2ff38e158584691184cdd1bcc.jpg?key=U0beqRr-vfm-iMru8ZNwaQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:32.59	2026-05-11 09:30:32.59
da101975-a89c-4c20-8b45-185fb60f9da0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4719316730111107705	\N	\N	Phạm Mỹ Linh 美玲	https://s120-25-ava-talk.zadn.vn/84/9596d80db8b425deabc87ff49b5f833c.jpg?key=OoAWCs-tCBjA5A7MxqvpGw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:37.208	2026-05-11 09:30:37.208
f0667a87-0864-4710-b434-a132e22e4056	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2040756076357997397	\N	\N	Minh Nghĩa	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:41.821	2026-05-11 09:30:41.821
089dd894-4f02-48d8-8b4a-9a1707819c67	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7282564884786440215	\N	\N	Lê Thế Dũng	https://s120-25-ava-talk.zadn.vn/3/b4f4cb28e8af27925360db5b6c5dd2c3.jpg?key=Ni5HXwawpHPpp5zqcCAL5g&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:46.422	2026-05-11 09:30:46.422
5ae6975b-c199-4ef9-aa56-6e74b520f3a1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7354752719437490710	\N	\N	Chàng Khờ Thủy Chung	https://s120-25-ava-talk.zadn.vn/18/dd7c8335ec4eb496e730ed7235a32263.jpg?key=H0VvXNV44imul7gJwyCnGw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:51.039	2026-05-11 09:30:51.039
2eb468a7-d19d-4891-b1a6-67fd1ab057bc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4849218015667787084	\N	\N	Lê Q Phú	https://s120-25-ava-talk.zadn.vn/13/4478b811c9463e4ca424f77482ccfdfe.jpg?key=7kjGO1BdigRLhyUYXKZ3Nw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:30:55.638	2026-05-11 09:30:55.638
37db978b-34d1-424e-bf4a-9391e1f42607	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5040625366319279092	\N	\N	Quang	https://s120-25-ava-talk.zadn.vn/15/fcd7749f0ccc73889166db174fe8737e.jpg?key=aYkTnYfvS2S5V-_GbKsreQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:00.24	2026-05-11 09:31:00.24
46bee89c-133a-4b81-8e72-a38f7298a577	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1096119383979435057	\N	\N	Quốc Trung	https://s120-25-ava-talk.zadn.vn/21/cbea508cdef4e463f2f785e6c8a5034b.jpg?key=f0kThXiWAICQY0V_pgfJwQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:04.849	2026-05-11 09:31:04.849
d9d4192d-3770-4b0e-9b92-4e6cebdcd8fe	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3575175767328469402	\N	\N	Nguyễn Hương	https://s120-25-ava-talk.zadn.vn/66/d699749a3bd6474b4e61e826c99953f2.jpg?key=4i3E3FEiCs0GMr2H3J3-uQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:09.457	2026-05-11 09:31:09.457
75727ae7-0892-4f73-8445-1488c2871a1f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4552437174917173034	\N	\N	Bùi Minh Hiếu	https://s120-25-ava-talk.zadn.vn/16/585c0cf1796f4af4899ef3b2381cd817.jpg?key=o0Rs9G1kcjESb9LodSsQFw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:14.065	2026-05-11 09:31:14.065
17aa2f4c-ce53-43ca-8476-ab06d4d7c26b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2533279186909697583	\N	\N	Lê Đình Quang	https://s120-25-ava-talk.zadn.vn/2/f2ac5fcb311f3834945606f81e0749e4.jpg?key=_cLqvk1d_PhyPZT4M6GGKQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:18.668	2026-05-11 09:31:18.668
c90ab10a-48d5-4524-835c-de48fe06c144	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3571090561630184328	\N	\N	Phan Bá Bình	https://s120-25-ava-talk.zadn.vn/5/83485c8d4d762b75a28654e15cacf949.jpg?key=D_K85sFeZBjmPUczfYOuJg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:23.272	2026-05-11 09:31:23.272
b0f6a804-4551-453b-adf1-0f991979524e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6976290491141041623	\N	\N	Kim Duy	https://s120-25-ava-talk.zadn.vn/24/b79a18d00fd5959a2fdf85118f751504.jpg?key=HGS1CQ34vVxfMyRKW2tqkg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:27.871	2026-05-11 09:31:27.871
0b7eb110-6e59-426a-8840-74effff57c3f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4032279182712627186	\N	\N	Van Anh	https://s120-25-ava-talk.zadn.vn/1/38ead18addf174ae886e85f97f2c6149.jpg?key=Pu8pi2r0NoKolyF2crLxFg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:32.477	2026-05-11 09:31:32.477
f75c33d4-fde8-499c-84f5-d45c7625d137	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3115939052991645753	\N	\N	Phạm Huy Hoàng	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:37.08	2026-05-11 09:31:37.08
9386b17c-bf30-41c9-a3bc-dd118c1d277e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7180921203648944544	\N	\N	Lê Quốc Kỳ	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:41.692	2026-05-11 09:31:41.692
a57d8593-1ef3-4a9d-8453-4f23d9b55f08	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2781427507630744222	\N	\N	Huỳnh Anh	https://s120-25-ava-talk.zadn.vn/153/a759af2c1ec546f8e7ffbe0fa48a2ce6.jpg?key=-ObnHX75LioMLW4lgYNqow&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:46.299	2026-05-11 09:31:46.299
9be04eca-affa-477d-9c35-55f189af1e56	ecae3be0-2ff7-4547-bf7a-308be16a20ad	542162771176889473	\N	\N	Nguyễn Thị Tú Trinh	https://s120-25-ava-talk.zadn.vn/38/72c95b3f34b3929d3021e70c158255f0.jpg?key=nGfEkNUSbCir6YuSJBlRfA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:50.91	2026-05-11 09:31:50.91
e69aec77-b265-4c0b-8930-8e47226f67ae	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5957113213587088556	\N	\N	Lieu Nguyen	https://s120-25-ava-talk.zadn.vn/13/73d937a55b7cfef46c71b5f6e1cac14a.jpg?key=LqkfECTCmUp0XwhkCm78sw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:31:55.514	2026-05-11 09:31:55.514
80142fdf-3ff8-4de6-87d8-08ec7a34da92	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9034324555011293287	\N	\N	Thu Hà	https://s120-25-ava-talk.zadn.vn/8/36034afbeb33a8543ef31db9a9eeea95.jpg?key=5LRVqNdsaWgKLFeVPNKJKg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:00.116	2026-05-11 09:32:00.116
3c561d2c-9d3a-4256-a207-27236fa10aa5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3856501922686217602	\N	\N	Nguyễn Nhật Hiếu	https://s120-25-ava-talk.zadn.vn/77/e24ff516cc6af3a82cdba2f9d189009e.jpg?key=siV7THlQKbxVN45B4AZtvw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:04.718	2026-05-11 09:32:04.718
8c480d54-75fb-43a3-862c-73f05b856ce4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6339501809145327869	\N	\N	Kim Thoa- Đào Tạo Lái Xe	https://s120-25-ava-talk.zadn.vn/33/ac2275d7667a59584e10fba08bce1e7b.jpg?key=FVR2myJj5sXzxvag3Q6Nzw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:09.321	2026-05-11 09:32:09.321
73524fb6-a73b-45c5-881b-ab0de822c4e4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1064450961613248194	\N	\N	Kiều My	https://s120-25-ava-talk.zadn.vn/43/ff87850e46c85968f9f0f62ccb37b076.jpg?key=Xp5uNiOqzuL5sOaYdo1mdw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:13.922	2026-05-11 09:32:13.922
9eda6797-32cd-4501-9ad0-c22022902a27	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2452072241461835776	\N	\N	Le Van Dang	https://s120-25-ava-talk.zadn.vn/4/1e86c2a82aca74bc02a65d33cd564f63.jpg?key=nAfPCvZcOfwArhGo9Lv72A&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:18.521	2026-05-11 09:32:18.521
4221d41f-ce25-469e-93b7-ab48e511e256	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1326355304159373167	\N	\N	Thomnguyen	https://s120-25-ava-talk.zadn.vn/54/393299a6d410ac513dc0ff1675284287.jpg?key=zmlVINwIS3qn-3GllM-MWg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:23.121	2026-05-11 09:32:23.121
5b113d6a-4ff4-40d1-a601-8474fc32bf5d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4674710980990436056	\N	\N	Nguyễn Duy Thắng	https://s120-25-ava-talk.zadn.vn/2/3475481e43644b83753687e9189bc13b.jpg?key=UThEFL4w23BspvFiZIdnpg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:27.733	2026-05-11 09:32:27.733
806709c7-95c4-462c-a0dd-6cffddd7ec42	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7057244415670324471	\N	\N	Jackie	https://s120-25-ava-talk.zadn.vn/19/9572a966315c623fe33252787844ef66.jpg?key=aS8e44BiL8ptFW9Jps0wFw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:32.332	2026-05-11 09:32:32.332
acd8a7c8-10fb-446d-9071-b7ebddaa741a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5611606458481225959	\N	\N	Hồng Cẩm	https://s120-25-ava-talk.zadn.vn/1/721f4322f62b1a1407322b6c47e0f376.jpg?key=K_KqF55HMo3mcW6S2EbW7g&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:36.963	2026-05-11 09:32:36.963
865c6ac9-3f77-4003-b2bf-247b1f2043d9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3429230737531381136	\N	\N	Nguyễn Nhật Tân	https://s120-25-ava-talk.zadn.vn/22/9c63e1ee30951fde9a97fa8a161d4f8a.jpg?key=JN0e8bDjZnx0s8IhXD3jXA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:41.568	2026-05-11 09:32:41.568
f4e7374f-87f6-4dfb-97a0-9c21e215b1b1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8876243584966445097	\N	\N	Lê Hoàn Khôi	https://s120-25-ava-talk.zadn.vn/82/4bc99d7bc4326cb188f3fe348f36facc.jpg?key=MGi-3-K_4kFyZRbXOSBs4w&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:46.166	2026-05-11 09:32:46.166
354421e6-8073-46f9-a1e3-17f221cad7de	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5551645509194865420	\N	\N	Minh Hiêp Qwertyuiop	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:50.767	2026-05-11 09:32:50.767
79e66aa2-f657-44c4-985a-b581c9782150	ecae3be0-2ff7-4547-bf7a-308be16a20ad	901340546993263493	\N	\N	Tú Tú	https://s120-25-ava-talk.zadn.vn/145/655eee16b34b7dfe6bdc8de4aba71061.jpg?key=jKRa8y3C28_hMJcyS7mIZw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:55.377	2026-05-11 09:32:55.377
8e9873ed-ec46-4a25-8793-6344d0f9f858	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5654813209257618046	\N	\N	Mạnh Dũng	https://s120-25-ava-talk.zadn.vn/6/4ad5ad1b223d1deb998f7727e0290405.jpg?key=jsbROWZYvOTY-47DF2R1sA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:32:59.996	2026-05-11 09:32:59.996
c3eb4c40-a2e7-43a4-986a-844ee3d67702	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6927341688400109349	\N	\N	Nguyễn Ngọc Thiên	https://s120-25-ava-talk.zadn.vn/4/5d252266f109e179b49a6fc989a90b4d.jpg?key=FRTXJxUDZ-kgTWxRz6U0mQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:04.604	2026-05-11 09:33:04.604
9e2580e2-b24d-4663-9087-76a50ffdc988	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4044237181756998951	\N	\N	Nguyễn Phước Thảo Prateek Dhavan Desai	https://s120-25-ava-talk.zadn.vn/83/246875e6df4d788016454091e08c54f7.jpg?key=Mv_AEWftAlTSIS5Do2TslA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:09.207	2026-05-11 09:33:09.207
3dfe1144-1959-4fda-b198-ef3858397183	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5952478041105487004	\N	\N	Phạm Thu Hà	https://s120-25-ava-talk.zadn.vn/9/f12b11659b403f48723c2bc8ba997e4f.jpg?key=XINOtqwuMGL41ohH27f1bA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:13.806	2026-05-11 09:33:13.806
d559e8e8-0545-4021-a7a1-056ae6e5a808	ecae3be0-2ff7-4547-bf7a-308be16a20ad	275744278983921108	\N	\N	Lương Quỳnh Như	https://s120-25-ava-talk.zadn.vn/27/da0c2937489cff379e8883df17a731f8.jpg?key=HdXzJEeLQ06EG1nE6dAN0A&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:18.423	2026-05-11 09:33:18.423
30c669af-6777-4bad-9102-26671f554d1b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3910120434033879108	\N	\N	Phạm Quang Bảo	https://s120-25-ava-talk.zadn.vn/12/7ac29eab2b8dcee40e919b43c89c4cbe.jpg?key=XQ2DgBLdvgdnWGVRfP_i-w&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:23.027	2026-05-11 09:33:23.027
639bdb49-61d7-4578-bfde-8d12bf6ce1a3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5490717712440025909	\N	\N	Trần Ngọc Vân Anh	https://s120-25-ava-talk.zadn.vn/49/30981082c519f13477671964342451d8.jpg?key=iSQW1KPCUjG0ng21rsZaig&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:27.625	2026-05-11 09:33:27.625
b6ae8bb3-d64b-4739-9094-0152a20e5f44	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6430549551320135994	\N	\N	Thu Dung	https://s120-25-ava-talk.zadn.vn/5/cd60de0b0f9595fe2c5e9a14add418aa.jpg?key=P9Jo5M6eU-QiXdE2zO68Hg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:32.222	2026-05-11 09:33:32.222
6f27d40e-f731-4650-a23b-e3628f83aa50	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8591273844798509117	\N	\N	Đặng Đức Minh Quang	https://s120-25-ava-talk.zadn.vn/14/571d1d240bfb31b814eb8880b2d76c66.jpg?key=xIx_jYYhwJTYfejVsjglxA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:36.821	2026-05-11 09:33:36.821
9c4358a8-d281-486c-bbf2-f9d7c4f8d2fe	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7438063194402374462	\N	\N	Đào Ngọc Huy	https://s120-25-ava-talk.zadn.vn/13/7063441ea3f8f5e42d7b69b2bff858aa.jpg?key=NiEMj4iYxf-NN1B85Phx7Q&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:41.419	2026-05-11 09:33:41.419
9764289f-282e-4bfe-a6d8-4b8debaf3b94	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8342727054413244864	\N	\N	Trần Nguyễn Ngọc Quý	https://s120-25-ava-talk.zadn.vn/2/6fd61835f2f1207733488db75eec7a65.jpg?key=mA18O9Bj2RPSlyAk9zNSWg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:46.025	2026-05-11 09:33:46.025
e5f978f5-33c3-4807-83ed-cde3f2526cef	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6491652595667357969	\N	\N	Triệu Hoàng Vinh	https://s120-25-ava-talk.zadn.vn/4/142786e2e28893f800bd68c5fd174cc5.jpg?key=6aNO59TiLtlmtlTbHWtXDQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:50.622	2026-05-11 09:33:50.622
64084092-1b0b-45dd-a9fb-4fd7dcf3b786	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7024021364864157309	\N	\N	Kim Tiền 阿銭	https://s120-25-ava-talk.zadn.vn/60/1ee3ebfbe6a912159ed4fa0cc1df90bd.jpg?key=ZoQbeQSlGe_42pUUi8N6KQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:55.225	2026-05-11 09:33:55.225
113b5657-832b-4d10-9053-78bc2bbc9754	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8489507024238786775	\N	\N	Lê Thị Khánh Ly	https://s120-25-ava-talk.zadn.vn/18/c85e9004e94778ffa4379bd46b2e292a.jpg?key=LUQy7qs9xsCECqmdj6gFJg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:33:59.83	2026-05-11 09:33:59.83
2139b9f8-a537-4cf2-8e0e-e2e2ced94e32	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3307485938597615329	\N	\N	Gạch men Tài Phát Lộc	https://s120-25-ava-talk.zadn.vn/7/0f19a7a96d742a8865aa35b726e02d71.jpg?key=pl9QRQKGnkr_emdKEPBfow&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:04.433	2026-05-11 09:34:04.433
aa4adc65-75fa-484e-a816-c1bd0b96ce1d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8574809374670427384	\N	\N	Hoàng Quốc Tú	https://s120-25-ava-talk.zadn.vn/5/deb324c989c197b41d04a2385801efd7.jpg?key=NDSjBA1SBbMlBcb7hEMvMQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:09.038	2026-05-11 09:34:09.038
7b112360-9e38-4a60-aa3e-4e9bdcdfb9ca	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8222811147174081050	\N	\N	Thanh Trần	https://s120-25-ava-talk.zadn.vn/6/78ed14391a8ec8488e9d2026c8644c0e.jpg?key=qEKmMzzLfWp2TrrbVz0vog&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:13.64	2026-05-11 09:34:13.64
7fe6403e-a8e8-4230-b4b6-3295d657fb71	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8512023950613203751	\N	\N	Bích Ngọc	https://s120-25-ava-talk.zadn.vn/5/0c4b461d4d67106056d5c0787872024a.jpg?key=yCtxMan_Qai3xxmM9y9pAw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:18.243	2026-05-11 09:34:18.243
92a7e5d2-7d86-48ee-8183-bece872e103c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3617953891114654258	\N	\N	Mẫn Trần	https://s120-25-ava-talk.zadn.vn/44/f107b26f61e71aaa9a17e938bcc605eb.jpg?key=eJrM38YzKyt67GxjY9GY4g&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:22.847	2026-05-11 09:34:22.847
9ef13cf2-9242-4eac-9a71-f67cf117ba8f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2334852433584249440	\N	\N	CNMNC2 s56 g202	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:43:21.373	2026-05-11 09:43:21.373
e8b0cfb0-596b-4739-8e64-0574ab72e5c2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	750600057280920941	\N	\N	Phạm Văn Trường Sơn	https://s120-25-ava-talk.zadn.vn/16/855f61583995956a091f3b2161cb740a.jpg?key=pp2KUKTEihoaqcmq6hgnjA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:27.442	2026-05-11 09:34:27.442
4c3192fa-c487-488c-a069-17c0e67aeae2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5930664149914059338	\N	\N	Hải Huy	https://s120-25-ava-talk.zadn.vn/8/66389049cb0bc56f850c7d8826af856e.jpg?key=d3jNUW3BjZQT61MoJg3W7Q&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:32.043	2026-05-11 09:34:32.043
a614bf9d-acf7-4761-a924-fe2868b83fb0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2880504870176932862	\N	\N	Hữu Toàn	https://s120-25-ava-talk.zadn.vn/51/6f9454a94f97fb371ec865e7f728b1bc.jpg?key=ud_8nx7iWX68JIyrZ2kpAA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:36.645	2026-05-11 09:34:36.645
cdde9514-db1f-4f8b-a5bf-9294a4f7564d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	60130993113843922	\N	\N	Lam	https://s120-25-ava-talk.zadn.vn/14/08f26d1bd7e16d923ea1639160ccae6e.jpg?key=ZGrQRR-00J7sOLHDsZLnEQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:41.242	2026-05-11 09:34:41.242
2131b76a-c5be-45b2-bc17-7aaa8d589878	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4149230829009219986	\N	\N	Lê Đức Huy	https://s120-25-ava-talk.zadn.vn/5/64bd5c2dc7c371a9d91c0c5396626472.jpg?key=zvAEcVt3B1kRjSxCXo9PQA&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:45.845	2026-05-11 09:34:45.845
77512f10-88bc-4522-a15b-f809e02f564a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6947579459661502317	\N	\N	Trương Luân	https://s120-25-ava-talk.zadn.vn/6/51d718484e2cc90f498c052d22b564b7.jpg?key=dudx3VRb2HfniE99HUK65A&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:50.444	2026-05-11 09:34:50.444
68f3ea02-fa3f-4674-b571-412a3e7e8e15	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3628368534594254173	\N	\N	Phạm Mỹ Cảnh	https://s120-25-ava-talk.zadn.vn/6/d5039db149b35bfc8432d84bb5f39a47.jpg?key=cUlfwLpv4xywzrID059hIQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:55.053	2026-05-11 09:34:55.053
5d733319-a11a-4a78-84c0-d64db2b80ec3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8361295753266978830	\N	\N	Ngo Bao	https://s120-25-ava-talk.zadn.vn/26/480d9313ae1b2883e6267996593a5608.jpg?key=dDmoikNKjIpVpqI0Q9-ngQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:34:59.654	2026-05-11 09:34:59.654
0db7020f-bb4c-411c-be4c-86d46823a68c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3670032301056967145	\N	\N	Y O U R S A L E S	https://s120-25-ava-talk.zadn.vn/22/89f4dbf88e23d24da6f241f0ff7b9164.jpg?key=CajsV81FgaWjrR_cC77HUQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:35:04.263	2026-05-11 09:35:04.263
458e17cd-0851-4d5d-806e-1eb28fefe565	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1336769012085064330	\N	\N	Thanh Phong	https://s120-25-ava-talk.zadn.vn/14/c55d9c9b477810e72376159304a525e8.jpg?key=o33DT1UlJ4JG8P9fxSo8Qw&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:35:08.866	2026-05-11 09:35:08.866
95051ca3-524b-4f11-be14-bb0cf7eca479	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9056702170060804008	\N	\N	Nhân Thăng	https://s120-25-ava-talk.zadn.vn/1/7c003b200e72b237e2587055f1d34f72.jpg?key=Fx73DHlUufhks2r9wqymnQ&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:35:13.474	2026-05-11 09:35:13.474
d69d6e09-3b53-422d-b0fd-3939c94af238	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5899850777258929383	\N	\N	Hồng Phát - Mss Thảo	https://s120-25-ava-talk.zadn.vn/1/88bd263651189baef401eb8f8a522233.jpg?key=MLoPoHDAf4HbnxDE1vLbzg&time=1783675642	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:35:18.082	2026-05-11 09:35:18.082
b52a058b-a051-4f39-a14b-7e78aaa914ff	ecae3be0-2ff7-4547-bf7a-308be16a20ad	247597133607989608	\N	\N	Lập_Trình_Web_ChiềuT4😗	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:35:22.873	2026-05-11 09:35:22.873
89f7497a-8162-4133-b476-56bd86e3ddeb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4577395869554549889	\N	\N	21DTH3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:35:27.615	2026-05-11 09:35:27.615
0a629d9c-45ca-44f6-9ae8-99f9cb281691	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6378755474033425	\N	\N	CNXHKH_0070173.4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:35:32.328	2026-05-11 09:35:32.328
a948d416-252d-4fcd-8689-b726c3123f77	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6177519038509347517	\N	\N	phương pháp tính	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:35:37.063	2026-05-11 09:35:37.063
acc6c135-eecd-4ff5-819e-7179d325ca0e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1378859464005364773	\N	\N	3 Thằng Nhóc	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:35:41.806	2026-05-11 09:35:41.806
1c348c7f-ae8d-408d-9356-0c779a642083	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3983472672505193039	\N	\N	Đề tài tốt nghiệp Ai agent - 2025-2026	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:35:46.541	2026-05-11 09:35:46.541
37e6183f-f4ca-4acf-af40-db4118030374	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8094742771760347985	\N	\N	Đầu Tư Kiếm Thu Nhập	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:35:51.302	2026-05-11 09:35:51.302
a1f6c092-bece-43fe-9f3c-05a48a79a563	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7046568866673571533	\N	\N	XẾP CHỮ 30-4 (NHÓM 2)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:35:56.115	2026-05-11 09:35:56.115
ee6da87a-21fc-4e3a-9a58-c14fe6c03d1e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3801643491372886981	\N	\N	Bot_Fb_CmtNew	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:00.929	2026-05-11 09:36:00.929
72df1697-b6c2-4f7a-ab13-b33298510507	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5422166373520501048	\N	\N	PLĐC tiết 101112 ( group 2)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:05.689	2026-05-11 09:36:05.689
40df0973-51ee-428a-b2be-b299b9b15662	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8824073806647235186	\N	\N	Ngày hội việc làm Sân bay Long Thành	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:10.426	2026-05-11 09:36:10.426
a8383eb3-a0e1-4a3b-a71d-d349c75c44e1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2341451846483559289	\N	\N	NHÓM HỖ TRỢ CÔNG TÁC NHẬP HỌC	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:15.212	2026-05-11 09:36:15.212
fabfaca1-142c-482c-a17f-513834135493	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9094124477512472371	\N	\N	TA chuyên ngành CNTT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:19.935	2026-05-11 09:36:19.935
3c25fd94-ea08-4ee4-85cc-1e7cd26030cd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7092169329974023019	\N	\N	Ốc Tiêu ( Thông Báo )	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:24.683	2026-05-11 09:36:24.683
fe9cd245-6053-488c-9fc4-1e7f3de195c0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7562604454813992692	\N	\N	Thứ 4-Lớp GDTC2 Bóng Đá(789)⚽️	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:29.396	2026-05-11 09:36:29.396
b2aeb9f3-4de5-4f65-8c91-9bcdeb45361e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4860181653371989109	\N	\N	KHOÁ LUẬN K17	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:34.108	2026-05-11 09:36:34.108
bea8271d-ca1d-4ecd-a586-1deeaa391304	ecae3be0-2ff7-4547-bf7a-308be16a20ad	89833810979300152	\N	\N	chơi game free không tốn lòn gì hết	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:38.812	2026-05-11 09:36:38.812
1d56738c-92c8-4d78-8e60-64c60027d92d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1066570097551269578	\N	\N	Minh Lâm, Nguyễn Trinh, Trần Vy	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:43.558	2026-05-11 09:36:43.558
04499c5f-a14d-43dd-8209-c16053796c36	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1501168729895460050	\N	\N	Nam tước	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:48.264	2026-05-11 09:36:48.264
f5a882dc-30c4-4bab-a639-5085afcda89c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1775609764151337379	\N	\N	TKW_K17_ChiềuT3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:52.98	2026-05-11 09:36:52.98
3e59d959-800b-4a6c-a701-66baa8f1e574	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4080573729362445478	\N	\N	tiểu đội 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:36:57.718	2026-05-11 09:36:57.718
c2528ace-e490-49b2-b367-98e4dd34002e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	194539214468000948	\N	\N	Gia đình iu thương	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:02.519	2026-05-11 09:37:02.519
06bd8434-b709-4210-9297-b1e41836fdd7	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8873600464055681826	\N	\N	BAN CHẤP HÀNH _ ĐOÀN KHOA CNTT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:12.016	2026-05-11 09:37:12.016
139dfbab-d878-49ca-9fbf-39797bee4221	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2371019760478378720	\N	\N	Rss	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:16.722	2026-05-11 09:37:16.722
0c91166d-38ac-4606-8e82-bcfb34281dc2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	246336029840242028	\N	\N	LEO SLAYER VÀ NHỮNG NGƯỜI BẠN LORDS MOBILE	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:21.476	2026-05-11 09:37:21.476
7dd972aa-0246-4398-af04-3010c27ea08d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2079734372083228123	\N	\N	Nhóm Kỹ Năng Mềm Real	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:26.2	2026-05-11 09:37:26.2
2e0963c3-bb13-4d98-ad6d-7f7a899b2495	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7543749161732064695	\N	\N	Iot chiều thứ 5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:30.957	2026-05-11 09:37:30.957
d2015fd0-1fc4-4535-af97-ac3209f30a13	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6124175347389412602	\N	\N	Nhóm làm TKHTM	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:35.698	2026-05-11 09:37:35.698
fe9d3460-7630-4ea6-a64c-adf889e8d7e8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2722567677942886607	\N	\N	22_23_Hệ quản trị Cơ sở dữ liệu_sáng thứ 3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:40.429	2026-05-11 09:37:40.429
121d1a49-8094-46b7-b69e-815c8d5c394b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	590289547735442486	\N	\N	Nhóm 2 (51-100)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:45.144	2026-05-11 09:37:45.144
d3124aa0-97ea-4853-89ac-e708bb60f01e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8595229808384254543	\N	\N	Test5s	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:49.914	2026-05-11 09:37:49.914
ab51099d-502d-4791-b44f-2570bedee020	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5331263858931509499	\N	\N	THDC-K21-CT5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:54.613	2026-05-11 09:37:54.613
5ab335be-5837-45d9-8d26-a9ea5bf49774	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2609045895282789426	\N	\N	Báo con 🐆🐆🐆	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:37:59.353	2026-05-11 09:37:59.353
91c2f816-5fba-46cc-92c2-ff12157bdf57	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3649196476822293411	\N	\N	CTV	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:04.075	2026-05-11 09:38:04.075
fc24214e-6482-4c89-9897-599d1a296eca	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5899788998825389287	\N	\N	THỰC TẬP - 1CAR GARA BIÊN HÒA	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:08.827	2026-05-11 09:38:08.827
68d85496-bdb8-4cca-a52a-7765d3d64d78	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1909286789282003064	\N	\N	CNTT_Khóa 17 (21DTH)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:13.553	2026-05-11 09:38:13.553
465aa03b-764d-4aed-9099-0552173c3472	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5665346085205363864	\N	\N	Cô Liệu hướng dẫn thực tập 25_26	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:18.29	2026-05-11 09:38:18.29
f84e4a9d-31d6-4e7a-bc00-e635f839d00e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4448177584679525308	\N	\N	Nhóm 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:23.026	2026-05-11 09:38:23.026
d1470f4c-d7a6-46ab-91ac-8b23311cff63	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5716733438302127954	\N	\N	HK2.2223 TT3. LĐQL Kết Thúc hP	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:27.791	2026-05-11 09:38:27.791
e398211a-4d99-4129-8e22-e4b6613278a0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8696121609163951017	\N	\N	CHUYÊN ĐỀ CÔNG NGHỆ MẠNG	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:32.504	2026-05-11 09:38:32.504
71eaa8e5-6582-451c-b959-431c2b3474ad	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8810000927059780676	\N	\N	Team Thực tập	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:37.233	2026-05-11 09:38:37.233
27954006-43d8-4032-afd1-b53157fd2f6e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8063689222712825312	\N	\N	Website 1CAR Talent - HIỆP IT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:41.945	2026-05-11 09:38:41.945
928d77cc-7274-4dd2-b574-6edfbc60dfec	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7271754842298225645	\N	\N	Training 3D - Online	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:46.764	2026-05-11 09:38:46.764
79f4b957-06a2-4409-9397-a6044bb3929b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1051917401023679134	\N	\N	Cung ứng việc làm DNTU 4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:51.571	2026-05-11 09:38:51.571
cf93ff6e-c1fa-4cae-9a85-796594e84b4e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4051302576088915006	\N	\N	PT_TK_Hệ Thống 😗	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:38:56.376	2026-05-11 09:38:56.376
4d3621bd-d96d-48e5-9d65-830e7d4bcd95	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9159988405536881689	\N	\N	HỖ TRỢ BỔ SUNG NGÀY CTXH CHO SINH VIÊN KHÓA CŨ	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:01.078	2026-05-11 09:39:01.078
19ad3a9d-c9a6-4da3-8712-675389de9622	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6554847223799984368	\N	\N	Đội Nhóm Trưởng	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:05.768	2026-05-11 09:39:05.768
23163161-e314-41c2-af0a-f4e65f2abb5e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2472482735985192791	\N	\N	Quản trị mạng Tối 3 - 2023	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:10.543	2026-05-11 09:39:10.543
98ac6341-332b-4eac-b445-058792cc82e3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3395217839606115353	\N	\N	NGÀY HỘI VIỆC LÀM 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:15.232	2026-05-11 09:39:15.232
faf313d5-8236-41a7-a4e4-1e985bb9086d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5004171251156036213	\N	\N	scam	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:19.982	2026-05-11 09:39:19.982
86bfffd9-5f63-4fc1-82a5-765572126764	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3629778638870278232	\N	\N	CTDL_GT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:24.7	2026-05-11 09:39:24.7
a5fb8171-ec1c-47ac-a0a8-ff78c5a276c4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9003638150981980916	\N	\N	nhóm kỹ năng lãnh đạo và quản lý	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:29.429	2026-05-11 09:39:29.429
e4df37cc-70ec-443e-ae6a-88cc55398357	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1153111552709004551	\N	\N	21DTH1_DNTU	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:34.11	2026-05-11 09:39:34.11
4f4e2da3-d127-4621-a041-89f420f17ddc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5329419338022822386	\N	\N	Nhóm 6 công nghệ mạng nâng cao	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:38.861	2026-05-11 09:39:38.861
3be0b635-f1f9-4b54-a5a8-fbc991198510	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1747311573792176696	\N	\N	Ngọc Rồng Origin - Box Chat	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:43.585	2026-05-11 09:39:43.585
80ab61fc-e1cf-488a-8ffd-e4013b76f3df	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3103705119462499349	\N	\N	Chúng tớ là 12A3🤟🤟🤟	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:48.316	2026-05-11 09:39:48.316
b0ff4707-fe27-4018-808f-a394f9307382	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8701468137926403270	\N	\N	Nhóm 1600-1592	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:53.029	2026-05-11 09:39:53.029
aadddadb-8476-40a8-b626-a761ae63d785	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1151566821602093564	\N	\N	Cung ứng việc làm DNTU 6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:39:57.809	2026-05-11 09:39:57.809
4d2f588b-a3b8-48fe-85bd-9137bfc61aaf	ecae3be0-2ff7-4547-bf7a-308be16a20ad	98134877466640475	\N	\N	nhóm kn khởi nghiệp	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:02.565	2026-05-11 09:40:02.565
95865808-2ccd-4db3-9be0-1beb18ec7a2a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2001866012699840207	\N	\N	1CAR - YOURSALES - SMS OTP	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:07.278	2026-05-11 09:40:07.278
06cfba4e-d9c0-4715-b2c0-e40d0df7703e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6762098583920416720	\N	\N	CloudFly - Hỗ trợ sử dụng N8N DashBoard	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:12.022	2026-05-11 09:40:12.022
cf525c21-46f1-40b9-bbd3-48d2fb1295d0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7252331083136097442	\N	\N	VPBank Technology Hackathon 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:16.818	2026-05-11 09:40:16.818
658f2054-b5ae-40ef-8c8a-ed10f0fa68f9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3746463315222450425	\N	\N	Fitness T1-3 Thứ 6(09/01/26)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:21.538	2026-05-11 09:40:21.538
496d4132-e91e-4df8-9dba-2241e4103264	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1756471503292523879	\N	\N	HK2.2223 TT3-G303 Quản Lý 0879163839 Lt đ Hoài	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:26.234	2026-05-11 09:40:26.234
98b76dfe-a134-4571-8701-30f864874222	ecae3be0-2ff7-4547-bf7a-308be16a20ad	997865888976390622	\N	\N	NTB 1633	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:30.964	2026-05-11 09:40:30.964
d9b1b81e-06da-41fa-8bec-0fc5b15ddd28	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5698296576008898067	\N	\N	nhóm 3, công nghệ phần mền	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:35.689	2026-05-11 09:40:35.689
ae08107e-dd2e-423d-b8d1-995b6445e005	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2118997815892830319	\N	\N	Check bot	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:40.398	2026-05-11 09:40:40.398
0f4119cd-5ada-4787-9751-e76529cb0af2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1647900920563946969	\N	\N	1CAR - Phòng IT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:45.123	2026-05-11 09:40:45.123
01901ff3-f7db-4d16-a7ab-f56a5512ab90	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2101414264399767854	\N	\N	Đại đội 5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:49.856	2026-05-11 09:40:49.856
c102c09e-9cdc-48c6-a62f-90967b5915e0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9157460395104401170	\N	\N	Ngọc Rồng Private - Hỗ Trợ	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:54.593	2026-05-11 09:40:54.593
67b98688-e487-4fff-a01a-78a6910e4671	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7907981006912605881	\N	\N	ĐOÀN THANH NIÊN - KHOA -CNTT -TT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:40:59.357	2026-05-11 09:40:59.357
5eeb562a-780e-4b12-9a49-8cb55caa8bea	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5689422030318315507	\N	\N	Chém gió 1580	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:04.067	2026-05-11 09:41:04.067
6de70631-fb42-4742-a4d3-a77eea2bf171	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5860025765213937237	\N	\N	Thi Tiếng Anh CDR- TTNN-TH	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:08.885	2026-05-11 09:41:08.885
1eb4c346-b6f6-4a2d-83de-e33a52d4b596	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2435749988293865930	\N	\N	THIẾT KẾ HỆ THỐNG MẠNG_SÁNG 4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:13.564	2026-05-11 09:41:13.564
5a3f0a26-bf2f-4311-b5c7-22c2ba8ab21f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1188675449747403384	\N	\N	K17_NHÓM TRƯỞNG KHÓA LUẬN	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:18.279	2026-05-11 09:41:18.279
9b25ac85-de6d-421c-8765-ffd9988e94c4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1728961364013020409	\N	\N	Sinh viên tốt nghiệp đợt 3 2025-2026	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:22.979	2026-05-11 09:41:22.979
16cdb188-9bfe-4c69-9794-6f58f02458a5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1243418431723785542	\N	\N	1243418431723785542	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:27.717	2026-05-11 09:41:27.717
9b7073a2-a974-4f8a-8004-7939d1fcbf89	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2428851805107554738	\N	\N	ppnckh nhóm 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:32.469	2026-05-11 09:41:32.469
c0cb974b-3cb9-48ad-b4ba-d2cfa1eede70	ecae3be0-2ff7-4547-bf7a-308be16a20ad	138255639096981484	\N	\N	Nhóm 1| Bockchain	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:37.188	2026-05-11 09:41:37.188
0de02346-2041-418c-9498-39df34f85539	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1342984663005375652	\N	\N	2025 TACN Chieu T4 T6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:41.928	2026-05-11 09:41:41.928
8e145276-8ab0-4ea2-beb9-11a6d0c57b82	ecae3be0-2ff7-4547-bf7a-308be16a20ad	343302843501501124	\N	\N	Ae T4 VnH kingdom 1600	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:46.643	2026-05-11 09:41:46.643
69c92547-0fb7-4ff1-a515-ad3335944a81	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7911211198102223565	\N	\N	Registration: VPBank Technology Hackathon 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:51.422	2026-05-11 09:41:51.422
1c0acbd9-09cd-4f68-b321-934c71fbda4d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6825624186729331390	\N	\N	Bơi Lội - Thứ 4 - Tiết 7-10	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:41:56.179	2026-05-11 09:41:56.179
82448bdc-eddc-4ed2-9aa5-4001c400f6e8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3166179562918692599	\N	\N	HK1_2025_ThiGiaMayTinh_8.5 Chieu T5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:00.948	2026-05-11 09:42:00.948
685ac37b-d27b-40f9-b8f5-228db0f2dc75	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7249519188486840988	\N	\N	7249519188486840988	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:05.743	2026-05-11 09:42:05.743
8ff76676-50ef-4653-b7fe-0a8dbcce5b07	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6046630024602298350	\N	\N	PPNCKH thứ 3, 4,5,6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:10.47	2026-05-11 09:42:10.47
e3d4d599-453d-418e-ac8a-cf7342a81964	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5898439783757551580	\N	\N	Chiều thứ 2_Phân tích thiết kế hệ thống	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:15.196	2026-05-11 09:42:15.196
a4502d74-35e4-41d5-b1f6-6af8a4803884	ecae3be0-2ff7-4547-bf7a-308be16a20ad	461662787190518639	\N	\N	Gia đình mình	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:19.889	2026-05-11 09:42:19.889
13746670-efdf-40c6-be64-a26d08e481e9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8483183673842586301	\N	\N	Nhóm tài liêu	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:24.623	2026-05-11 09:42:24.623
4f5f8ddc-1c6e-4b3e-af1e-769c167d90de	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4355685771079308149	\N	\N	Cấu trúc rời rạc	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:29.32	2026-05-11 09:42:29.32
f2afc999-28c9-427a-96f2-69792be0d2bc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4527671274784814802	\N	\N	Lư Văn Anh Tứ, Đình Trường, Nhật Nguyễn	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:34.056	2026-05-11 09:42:34.056
87aeface-79a6-4d1c-8e6b-946326657f0d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5388660826290233295	\N	\N	test5s-2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:38.785	2026-05-11 09:42:38.785
09d6b9a3-aeac-4e78-bba1-f444f2f10fdd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8511069149540513306	\N	\N	Technology NGICORP	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:43.551	2026-05-11 09:42:43.551
864bcf59-2bad-4d09-bc6a-1509d862340c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8231969568510759482	\N	\N	Khôi Bad, Trần Nghĩa Hiệp,...	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:48.274	2026-05-11 09:42:48.274
91199d72-a816-40e5-b80c-a0240fe7f912	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8894569411149203816	\N	\N	nhóm làm bài	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:53.024	2026-05-11 09:42:53.024
d30c8397-15a5-460a-9479-29059a443947	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3372361451628068554	\N	\N	Huy, Đậu, Trần Nghĩa Hiệp	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:42:57.777	2026-05-11 09:42:57.777
5017eaff-7c14-47ca-9a24-db044c211a68	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3607273294922883080	\N	\N	3607273294922883080	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:43:02.552	2026-05-11 09:43:02.552
44ffc87a-82db-4604-ba8e-c770c27935ba	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1523818911020526882	\N	\N	Trí tuệ nhân tạo 123	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:43:07.264	2026-05-11 09:43:07.264
5f4cfd96-ee7a-47ee-91ed-91cf6e1ce80d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5193452114407638805	\N	\N	A1 thi 17/6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:43:11.984	2026-05-11 09:43:11.984
92bde477-c786-4cce-8c2c-2aa4d3e717df	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5296627932035274118	\N	\N	GIẢI TRÍ - 1CAR	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:43:16.696	2026-05-11 09:43:16.696
066eda1d-160d-42a0-b482-82ce2eb601b2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3395582845455412504	\N	\N	Hết Cứu 🧠🧠🧠🧠🧠	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 09:43:26.098	2026-05-11 09:43:26.098
f1af3726-8b0e-4ae1-82a5-e824a89d5098	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8590853056949506623	\N	\N	Vu Xuân Trường	https://s120-25-ava-talk.zadn.vn/50/a5d7279981b52c6e0d13934ee683f43f.jpg?key=nLNuBKCSkArYnnk7UIo9uQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:15.111	2026-05-11 09:57:15.111
dd18dbfb-3a90-4838-87f6-b3e67e383bce	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3365195044584063156	\N	\N	Thành Vinh	https://s120-25-ava-talk.zadn.vn/9/1d82a952930a2f7e1e417707bcf59421.jpg?key=998Qg-sl-fLXlys8jayLsQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:19.886	2026-05-11 09:57:19.886
b7845134-7522-49f1-b52e-2aae6cf315d4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5199815831260101678	\N	\N	Bảo Vân	https://s120-25-ava-talk.zadn.vn/18/a468f65558656518657f74b04c96fc04.jpg?key=tSsNkeR1hSMfA2DVYnfYfw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:24.526	2026-05-11 09:57:24.526
f6281822-d027-46f7-973e-f57dd305fd66	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2377225580510953722	\N	\N	Bình Hải	https://s120-25-ava-talk.zadn.vn/8/c069d8aa8b7ea7b9e058e0a4fd0183d1.jpg?key=Nmx3rNAOF_ICUvtx9D8xLQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:29.163	2026-05-11 09:57:29.163
3400dfbd-f622-4a01-a49d-5c0f7fad3ff5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6997004832864396829	\N	\N	Tuấn Phương	https://s120-25-ava-talk.zadn.vn/11/45a05f856c50c2937080a9760d831f75.jpg?key=h1txc63zLIOT19dXsdjEWg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:33.783	2026-05-11 09:57:33.783
3a5dac81-ff32-4da1-9cc6-ef7e570bc773	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4363568070414806921	\N	\N	Lê Trung Hiếu	https://s120-25-ava-talk.zadn.vn/9/34c8c15b2c3ef696ccf2ea1951a13000.jpg?key=0uMyn1x7pHAe-5pg7vU1ew&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:38.397	2026-05-11 09:57:38.397
7dce6912-f3de-401f-8b01-92999c1ec13d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1318766047664325194	\N	\N	Minh Lâm	https://s120-25-ava-talk.zadn.vn/19/300552fa1e5fb484e2413f5804e9b6f4.jpg?key=C9NriMEPzRagqB2E7QqW1Q&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:42.998	2026-05-11 09:57:42.998
841f872d-2dea-401d-b9de-1ad7d27f6925	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3370964796099328975	\N	\N	Tuan	https://s120-25-ava-talk.zadn.vn/13/9fc14af5f6785d0521689c41b6e931b9.jpg?key=DNhhr-KnYjnsmwqaQ4wCIg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:47.601	2026-05-11 09:57:47.601
f0657dc3-d645-4239-a70f-33ca66f2ddf2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1130453685897962167	\N	\N	Bhuy	https://s120-25-ava-talk.zadn.vn/7/047d22584e3688d5ccf226f7e4e99ece.jpg?key=E5w8bWdnLlBilXhJ1GOiNw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:52.199	2026-05-11 09:57:52.199
1bf128bd-8417-4f06-9416-e92f46bcb087	ecae3be0-2ff7-4547-bf7a-308be16a20ad	892335756337869669	\N	\N	Học Giếng Khoan	https://s120-25-ava-talk.zadn.vn/57/ccbe5080d90c0609b23fb70b9da336cb.jpg?key=6Ar3MhQLJANG4j8xSXJYmg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:57:56.797	2026-05-11 09:57:56.797
22900a09-b3f7-438c-adea-b13ed9c8fded	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5874788356599630720	\N	\N	Thắng Trần	https://s120-25-ava-talk.zadn.vn/21/f715c38edb2c4cae7d124f45276c8f40.jpg?key=9inH9SUqqnlnd8m9gIl3fg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:01.394	2026-05-11 09:58:01.394
00722ab9-0fa3-42c2-9700-fbfddb6c58eb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7533351490509930124	\N	\N	Quân	https://s120-25-ava-talk.zadn.vn/35/c316e9cfd6db16597a42c91a1085b9f2.jpg?key=T44f1tYRK0kYKxX9RcL9CQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:05.991	2026-05-11 09:58:05.991
d9f0597c-4800-4771-8a76-c87cf23508ae	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5529985907955986361	\N	\N	Thanh Huyền	https://s120-25-ava-talk.zadn.vn/139/698427b826a07cb208e62e1bd6747ae4.jpg?key=b781sdH6NMtpqKv51kgxyA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:10.596	2026-05-11 09:58:10.596
a22e883b-675f-4247-94b3-a6defd6ce011	ecae3be0-2ff7-4547-bf7a-308be16a20ad	968339493716156535	\N	\N	Phạm Anh Tuấn	https://s120-25-ava-talk.zadn.vn/45/245be5efe0ece3eb6989d8c0ece1bdd1.jpg?key=NWbSvKLmQpNHW861E5jlmg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:15.222	2026-05-11 09:58:15.222
0df9582c-5f25-4e84-97d3-6f04a0eb2b5e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9112994558292890736	\N	\N	tung phat	https://s120-25-ava-talk.zadn.vn/2/4743bf5f3fc59ddd0caf006f4e9418de.jpg?key=KkMXCO_NgnUZMm1pPhml9A&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:19.859	2026-05-11 09:58:19.859
5c1668ea-704d-469f-bee8-3b862a99ea11	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7491386531983166705	\N	\N	Hùng	https://s120-25-ava-talk.zadn.vn/1/16f15a2c7f8714a28efcc01e8e546145.jpg?key=n6JPCslw_IrqtVhVPSVyJA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:24.463	2026-05-11 09:58:24.463
37295234-0c59-4cd1-ac19-4006dc6d62e6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1391940534205472598	\N	\N	Nguyễn Văn Quyết	https://s120-25-ava-talk.zadn.vn/18/10822971154fd0ce762285e8f382e45a.jpg?key=5QWCQj9RHUQtvvJlun_26A&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:29.068	2026-05-11 09:58:29.068
766a86b9-9ff6-4635-8076-9805a4bda840	ecae3be0-2ff7-4547-bf7a-308be16a20ad	106465284304135805	\N	\N	Minh Vương	https://s120-25-ava-talk.zadn.vn/21/7421420438ee8cf99f808f581b5a7f15.jpg?key=ARaseI5Ta87itp3hP5paEw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:33.678	2026-05-11 09:58:33.678
68e1ce7d-d0d4-4fb7-9009-38ca7c145196	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5027984576024583873	\N	\N	Nguyễn Đình Thuật	https://s120-25-ava-talk.zadn.vn/11/6317ec417b8dd4df39a8048ac3bb3463.jpg?key=EZ8gnAJlYrUCBWGMrIBkCg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:38.283	2026-05-11 09:58:38.283
ca6a80fc-6400-4916-a369-412858132c26	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7973708775326145455	\N	\N	Hưng Nguyễn	https://s120-25-ava-talk.zadn.vn/3/24db55890f4814b7044aa6f9797dd838.jpg?key=Eqeg-vanqvuB0yoJtFG8Ng&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:42.886	2026-05-11 09:58:42.886
38579555-ca23-4a1b-a077-629c432c4e33	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5843532481371558943	\N	\N	Zalo	https://s120-25-ava-talk.zadn.vn/36/16782d311b12da6d28daa13e343986b8.jpg?key=FjxhrP1j7bOA4E0IB-m6_A&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:47.486	2026-05-11 09:58:47.486
2d2352c4-9f67-4082-bb07-0c7969563a6f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1020544710927759918	\N	\N	Đati	https://s120-25-ava-talk.zadn.vn/37/0bf74bd37a074d1e9f0d545e07755798.jpg?key=j-F-sAvlA4V1AKcsrDQtRA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:52.084	2026-05-11 09:58:52.084
2bc7ba51-9809-48ed-bd91-e15186d2d94b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	813938803663625548	\N	\N	Huệ	https://s120-25-ava-talk.zadn.vn/101/a61a879fda9581de34de1b23d1634170.jpg?key=QiIIn5oRpiAQ6dWu_rZCnQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:58:56.681	2026-05-11 09:58:56.681
da39605f-d237-42ea-9f30-d33558425e0d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5589094428963815575	\N	\N	An Nguyễn	https://s120-25-ava-talk.zadn.vn/1/87495ea8651a2c11c861bde3a502c6f4.jpg?key=S8kNTv2ix_DnLlzemYZzXg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:01.278	2026-05-11 09:59:01.278
dd0cbbb2-32ef-46da-bc8f-4aed789f2edd	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6663625746799179902	\N	\N	Bao Bao	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:05.877	2026-05-11 09:59:05.877
b55f3c1c-32c3-4b37-9c84-afdd86db67e0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5227378038088588940	\N	\N	Nguyễn Sỹ Hiển	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:10.473	2026-05-11 09:59:10.473
d83a0893-a3b6-4d46-8089-17e83148b7bf	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6142746758236927800	\N	\N	Nguyễn Nhật Huỳnh	https://s120-25-ava-talk.zadn.vn/14/100eedf230c8fcc7a2d5f1c5091a721e.jpg?key=pgw-bkdRC3aMXlv1TMmWww&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:15.076	2026-05-11 09:59:15.076
e22a92d4-614d-4665-a94d-8f8aef9ac208	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3115939052991645753	\N	\N	Phạm Huy Hoàng	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:28.651	2026-05-11 10:01:28.651
ed7de90e-5ad3-447d-bee9-8413634ac0b1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8652078511014082325	\N	\N	Tiến Lộc	https://s120-25-ava-talk.zadn.vn/6/961eb945114df9ff085bb84343eaf0c6.jpg?key=dmWFXUkp9b-hdDnkpZur7Q&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:19.679	2026-05-11 09:59:19.679
8187a927-5ac4-49aa-a734-87d0d92dfe69	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6918032632913067014	\N	\N	Đình Ngân	https://s120-25-ava-talk.zadn.vn/4/dd103a5fcdc46b42458a6e03d3a85d8a.jpg?key=5F9lKSFUAzGXRGI1VPdK0Q&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:24.282	2026-05-11 09:59:24.282
03f629c2-10ff-44f9-b363-a8876d66242d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7624815288856388823	\N	\N	David Lee	https://s120-25-ava-talk.zadn.vn/8/a334ef703a73fcb0379f2ba1c037c16c.jpg?key=nDy-uFnw49l9mebgN067hA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:28.89	2026-05-11 09:59:28.89
3eacf417-2cd6-4926-9ae0-7035d556d357	ecae3be0-2ff7-4547-bf7a-308be16a20ad	442689131821776675	\N	\N	Trân	https://s120-25-ava-talk.zadn.vn/100/b1d08d2df83aab4633f925411628ee9d.jpg?key=j1PXVHYDZWgHQk_IIW24sg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:33.493	2026-05-11 09:59:33.493
1e1c7f33-a96a-4789-bad1-b322fe795b7a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2075914187392143048	\N	\N	Trần Anh	https://s120-25-ava-talk.zadn.vn/22/713eb3a5350638c062edcdfc57215ad8.jpg?key=9gmWHfWaF7lwju7gytgKRg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:38.097	2026-05-11 09:59:38.097
961e5e5a-4a45-42a5-9d63-62e3bf3eb7cc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5531375484717339332	\N	\N	Nguyễn	https://s120-25-ava-talk.zadn.vn/2/01072ef43e0d3554e40a419973036a88.jpg?key=GZqv9qbhXQugySoxyEKgvA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:42.695	2026-05-11 09:59:42.695
bbb0b6ff-7845-4169-ae3e-2463f31f1923	ecae3be0-2ff7-4547-bf7a-308be16a20ad	810978846930818886	\N	\N	Larry Nguyễn Hà	https://s120-25-ava-talk.zadn.vn/13/e7dddbbe91176868021bbe76cac86219.jpg?key=Vw0_0WeYwsKGQIcP8a8Ejw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:47.292	2026-05-11 09:59:47.292
6b0d9fcf-9b8f-4986-8757-70e053a853c3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7826078619176594076	\N	\N	Trần Trọng Phúc	https://s120-25-ava-talk.zadn.vn/10/67e43fa6c8ff94903f55c347a1a69ba3.jpg?key=cIe8GMR_31hZGPcM5LgeUw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:51.898	2026-05-11 09:59:51.898
277fb627-bc2c-430c-9051-5402915284e8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9155780683281460488	\N	\N	Thuần	https://s120-25-ava-talk.zadn.vn/92/4d0dd370c6222f4d89b5eee3409ff6b8.jpg?key=OjPN_BNiXgjst4Ns15OmfA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 09:59:56.5	2026-05-11 09:59:56.5
107069f4-8f72-4da1-bd68-30cd311d7f32	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1824701401457481301	\N	\N	Nghĩa Nv	https://s120-25-ava-talk.zadn.vn/6/17598219110c7a6719e15f93358e45e0.jpg?key=6pN7MWrjjuaZ8VTEKZNKXA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:01.105	2026-05-11 10:00:01.105
dfaee08c-11aa-4f86-985a-ab398f79c1f6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6659667179765541484	\N	\N	Ms Loan Giảng Viên Tiếng Anh	https://s120-25-ava-talk.zadn.vn/321/86de4bf90952554691e221b8cf232de1.jpg?key=4Da1NaztYMB3u1udjSsmJw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:05.718	2026-05-11 10:00:05.718
9794a7d5-0348-4a6f-9ecd-b1eff55c038e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3510152909233036209	\N	\N	Vân nguyễn	https://s120-25-ava-talk.zadn.vn/12/7ade927de5dd3f61c699b8c28cc84c94.jpg?key=n2usP1IX7gdxjNoeg_o1Sw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:10.325	2026-05-11 10:00:10.325
118c5639-5886-4bb6-ba94-dbf1955cfbaa	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6794776306049124428	\N	\N	Mai Văn Minh	https://s120-25-ava-talk.zadn.vn/13/a4718df15a7c580add89b78633be2cc4.jpg?key=KD3kybUnY8bxrOeT-Ixrzw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:14.932	2026-05-11 10:00:14.932
38bcd131-5c68-4ad1-ae5c-c9820cd7422b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4422396749875642200	\N	\N	Khánh Huy	https://s120-25-ava-talk.zadn.vn/11/194efd5652ad9c6facf07b36717f0d9d.jpg?key=gs8BsxovEFp7tUopyd2txA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:19.53	2026-05-11 10:00:19.53
3323157e-bde1-45df-929f-789e3b4be8e3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5436396812168505206	\N	\N	Huy	https://s120-25-ava-talk.zadn.vn/26/31d4e9d2ff38e158584691184cdd1bcc.jpg?key=RLkXO8mTOIk205y5RlHuUQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:24.143	2026-05-11 10:00:24.143
49277d8b-a0e0-4433-87ec-ef55db65adba	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4719316730111107705	\N	\N	Phạm Mỹ Linh 美玲	https://s120-25-ava-talk.zadn.vn/84/9596d80db8b425deabc87ff49b5f833c.jpg?key=1fs_Z4t1wk8yyGIoDPcfMQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:28.746	2026-05-11 10:00:28.746
30daa3ca-ffc8-4ff1-93e1-a8d9441fface	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2040756076357997397	\N	\N	Minh Nghĩa	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:33.353	2026-05-11 10:00:33.353
029e33e0-6c53-4852-9479-570aa5a20da8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7282564884786440215	\N	\N	Lê Thế Dũng	https://s120-25-ava-talk.zadn.vn/3/b4f4cb28e8af27925360db5b6c5dd2c3.jpg?key=_jB0figeAFKSvfhBYzfGFw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:38.024	2026-05-11 10:00:38.024
22dacc5d-55a1-47dc-bfdc-d0ecafc6af0d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7354752719437490710	\N	\N	Chàng Khờ Thủy Chung	https://s120-25-ava-talk.zadn.vn/18/dd7c8335ec4eb496e730ed7235a32263.jpg?key=kWBsYggOG9QSiTHQ9Dp3Yg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:42.639	2026-05-11 10:00:42.639
b899a902-6686-4002-960b-c10153ed7675	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4849218015667787084	\N	\N	Lê Q Phú	https://s120-25-ava-talk.zadn.vn/13/4478b811c9463e4ca424f77482ccfdfe.jpg?key=4A8VLeG_1L5LqoZMm4vhAg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:47.246	2026-05-11 10:00:47.246
cac63425-1476-4936-ad29-67bf9e23cdf0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5040625366319279092	\N	\N	Quang	https://s120-25-ava-talk.zadn.vn/15/fcd7749f0ccc73889166db174fe8737e.jpg?key=9IbU8z5ju9ie1sZLIUDUpw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:51.863	2026-05-11 10:00:51.863
67476a3f-4165-4e44-84f6-eecb82a9282b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1096119383979435057	\N	\N	Quốc Trung	https://s120-25-ava-talk.zadn.vn/21/cbea508cdef4e463f2f785e6c8a5034b.jpg?key=sdqEow34SI3c-NPyc1lN4A&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:00:56.465	2026-05-11 10:00:56.465
589de2ab-bb16-4808-bfae-ed79ca540da1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3575175767328469402	\N	\N	Nguyễn Hương	https://s120-25-ava-talk.zadn.vn/66/d699749a3bd6474b4e61e826c99953f2.jpg?key=x1oNFk5Ep1OwEp-CVed-Xg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:01.059	2026-05-11 10:01:01.059
1f9f785e-452b-4f7f-b0a6-c74bdd147864	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4552437174917173034	\N	\N	Bùi Minh Hiếu	https://s120-25-ava-talk.zadn.vn/16/585c0cf1796f4af4899ef3b2381cd817.jpg?key=kTU0qYdvxzMQPJnhcvXmPg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:05.655	2026-05-11 10:01:05.655
fc36676a-6d8a-451c-824c-e04270d05b94	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2533279186909697583	\N	\N	Lê Đình Quang	https://s120-25-ava-talk.zadn.vn/2/f2ac5fcb311f3834945606f81e0749e4.jpg?key=1RDNRud87Km0v_Yx6CBhtQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:10.251	2026-05-11 10:01:10.251
34f56c4e-4f8f-4b0d-a5d3-f8b35836eed4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3571090561630184328	\N	\N	Phan Bá Bình	https://s120-25-ava-talk.zadn.vn/5/83485c8d4d762b75a28654e15cacf949.jpg?key=LQYirXqZJQ3k8gORidcF7Q&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:14.851	2026-05-11 10:01:14.851
a6b18321-b435-4e77-80e4-60b348c46b08	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6976290491141041623	\N	\N	Kim Duy	https://s120-25-ava-talk.zadn.vn/24/b79a18d00fd5959a2fdf85118f751504.jpg?key=dssSPLeXhlTcWnI07Q3Oeg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:19.453	2026-05-11 10:01:19.453
9b3c0488-1c32-4031-9692-f3fa27ab200c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4032279182712627186	\N	\N	Van Anh	https://s120-25-ava-talk.zadn.vn/1/38ead18addf174ae886e85f97f2c6149.jpg?key=qgtQjpOQaURgkezjPzpANA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:24.052	2026-05-11 10:01:24.052
515eb90e-098c-4360-a0f2-81aed9a7c6be	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7180921203648944544	\N	\N	Lê Quốc Kỳ	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:33.264	2026-05-11 10:01:33.264
40450b45-83b9-4746-a4b8-87c1a1bffc16	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2781427507630744222	\N	\N	Huỳnh Anh	https://s120-25-ava-talk.zadn.vn/153/a759af2c1ec546f8e7ffbe0fa48a2ce6.jpg?key=FCrApA69HXPMh13vOZRleA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:37.868	2026-05-11 10:01:37.868
e71cae3e-b67e-4431-a0ba-a43bd99145e2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	542162771176889473	\N	\N	Nguyễn Thị Tú Trinh	https://s120-25-ava-talk.zadn.vn/38/72c95b3f34b3929d3021e70c158255f0.jpg?key=JphH6kd40dTo9xjvzuQPkw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:42.461	2026-05-11 10:01:42.461
511f92fa-d4ea-408b-bd30-933610978122	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5957113213587088556	\N	\N	Lieu Nguyen	https://s120-25-ava-talk.zadn.vn/13/73d937a55b7cfef46c71b5f6e1cac14a.jpg?key=2by7BuI6sSyrro95-4nYig&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:47.059	2026-05-11 10:01:47.059
9c8ac3fb-2235-405d-acd1-a81ec1bba311	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9034324555011293287	\N	\N	Thu Hà	https://s120-25-ava-talk.zadn.vn/8/36034afbeb33a8543ef31db9a9eeea95.jpg?key=s_uzt0vNQX4uisArl6ApCQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:51.659	2026-05-11 10:01:51.659
797c85b5-e46e-46d5-95a2-93b600f6e888	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3856501922686217602	\N	\N	Nguyễn Nhật Hiếu	https://s120-25-ava-talk.zadn.vn/77/e24ff516cc6af3a82cdba2f9d189009e.jpg?key=0Dwjhsz9sffqRIFQypL_2Q&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:01:56.263	2026-05-11 10:01:56.263
bce7e1b3-5c92-432c-9d49-5b622ee15d33	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6339501809145327869	\N	\N	Kim Thoa- Đào Tạo Lái Xe	https://s120-25-ava-talk.zadn.vn/33/ac2275d7667a59584e10fba08bce1e7b.jpg?key=mzVPWcjvWHctd25LqubHRA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:00.866	2026-05-11 10:02:00.866
18621407-84e2-47f2-ade9-1c1320944e4d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1064450961613248194	\N	\N	Kiều My	https://s120-25-ava-talk.zadn.vn/43/ff87850e46c85968f9f0f62ccb37b076.jpg?key=CbpnU54mBEe0reCLrGW88Q&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:05.465	2026-05-11 10:02:05.465
45bf501d-ccb6-4419-a99e-d1c5ea22f2c5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2452072241461835776	\N	\N	Le Van Dang	https://s120-25-ava-talk.zadn.vn/4/1e86c2a82aca74bc02a65d33cd564f63.jpg?key=zDP0NPivTF9tGmm0R1PvBw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:10.06	2026-05-11 10:02:10.06
10836c9d-e63f-4799-ac37-522a14ceaeaa	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1326355304159373167	\N	\N	Thomnguyen	https://s120-25-ava-talk.zadn.vn/54/393299a6d410ac513dc0ff1675284287.jpg?key=kC60iXTul3Z3bQIKwiDvfA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:14.655	2026-05-11 10:02:14.655
515f347d-759d-40a9-9306-067bfbe49969	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4674710980990436056	\N	\N	Nguyễn Duy Thắng	https://s120-25-ava-talk.zadn.vn/2/3475481e43644b83753687e9189bc13b.jpg?key=NiT3FGpUW6RVX-HWXvKEkQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:19.262	2026-05-11 10:02:19.262
cbc45cc5-5955-47d3-be6e-ba4d1c108a12	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7057244415670324471	\N	\N	Jackie	https://s120-25-ava-talk.zadn.vn/19/9572a966315c623fe33252787844ef66.jpg?key=pCZ1AxarDXP9NrNjKEbKTg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:23.861	2026-05-11 10:02:23.861
3c8bb8dc-1041-4b7b-8d02-a27a2ebe85bc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5611606458481225959	\N	\N	Hồng Cẩm	https://s120-25-ava-talk.zadn.vn/1/721f4322f62b1a1407322b6c47e0f376.jpg?key=-ETnRNfOFi6LPefFi6LoaQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:28.467	2026-05-11 10:02:28.467
36b6f26d-ea20-4501-8ae3-e738e103b312	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3429230737531381136	\N	\N	Nguyễn Nhật Tân	https://s120-25-ava-talk.zadn.vn/22/9c63e1ee30951fde9a97fa8a161d4f8a.jpg?key=GdSkL_NlMQkMGVTDNLwaYw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:33.07	2026-05-11 10:02:33.07
39b7db2d-aae0-4346-9e16-3898de05f057	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8876243584966445097	\N	\N	Lê Hoàn Khôi	https://s120-25-ava-talk.zadn.vn/82/4bc99d7bc4326cb188f3fe348f36facc.jpg?key=P0rva_NFRg1F_nY98HLYUA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:37.676	2026-05-11 10:02:37.676
3ab16a16-ebfe-4805-8898-24bfd1713a60	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5551645509194865420	\N	\N	Minh Hiêp Qwertyuiop	https://s160-ava-talk.zadn.vn/default	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:42.277	2026-05-11 10:02:42.277
5efeee58-20b9-4894-b078-63d5943a9a1e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	901340546993263493	\N	\N	Tú Tú	https://s120-25-ava-talk.zadn.vn/145/655eee16b34b7dfe6bdc8de4aba71061.jpg?key=hTuZTdxTu6vk0157OHp4SQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:46.875	2026-05-11 10:02:46.875
78c447db-f713-422b-ac18-26e2b37ef8d9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5654813209257618046	\N	\N	Mạnh Dũng	https://s120-25-ava-talk.zadn.vn/6/4ad5ad1b223d1deb998f7727e0290405.jpg?key=5t1nhcsWVWelHAO_gXh0bQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:51.48	2026-05-11 10:02:51.48
2bee99ee-8f6e-410c-aa76-090bdc5e1d72	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6927341688400109349	\N	\N	Nguyễn Ngọc Thiên	https://s120-25-ava-talk.zadn.vn/4/5d252266f109e179b49a6fc989a90b4d.jpg?key=igE2pSLqFmrM8XoESpGfZQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:02:56.078	2026-05-11 10:02:56.078
b48a8471-0b53-483f-ad63-c9adc2c77eeb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4044237181756998951	\N	\N	Nguyễn Phước Thảo Prateek Dhavan Desai	https://s120-25-ava-talk.zadn.vn/83/246875e6df4d788016454091e08c54f7.jpg?key=NpP0q6J9YpChGrYRbrdlfg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:00.676	2026-05-11 10:03:00.676
4934c522-601c-4207-88aa-736ce9580318	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5952478041105487004	\N	\N	Phạm Thu Hà	https://s120-25-ava-talk.zadn.vn/9/f12b11659b403f48723c2bc8ba997e4f.jpg?key=NeY19XFX81_R45G7IPGYcg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:05.268	2026-05-11 10:03:05.268
53aad87c-75fc-4a05-a90e-e986dba2bdad	ecae3be0-2ff7-4547-bf7a-308be16a20ad	275744278983921108	\N	\N	Lương Quỳnh Như	https://s120-25-ava-talk.zadn.vn/27/da0c2937489cff379e8883df17a731f8.jpg?key=KOyAWuDwziROSJsmtyL9yA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:09.863	2026-05-11 10:03:09.863
bd31bd8f-e345-4e55-a011-cdfc1e2f532b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3910120434033879108	\N	\N	Phạm Quang Bảo	https://s120-25-ava-talk.zadn.vn/12/7ac29eab2b8dcee40e919b43c89c4cbe.jpg?key=F0662STzQHuMPB2B_lyWLg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:14.458	2026-05-11 10:03:14.458
3a756dd8-6b5e-450e-862a-7f50f2249a42	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5490717712440025909	\N	\N	Trần Ngọc Vân Anh	https://s120-25-ava-talk.zadn.vn/49/30981082c519f13477671964342451d8.jpg?key=mswZUosP1bctZs8AE_KjoA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:19.057	2026-05-11 10:03:19.057
f57c4ae5-b0a9-4b89-8d25-53bc3e08ec68	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6430549551320135994	\N	\N	Thu Dung	https://s120-25-ava-talk.zadn.vn/5/cd60de0b0f9595fe2c5e9a14add418aa.jpg?key=hQNoJMWaMZl2NPDpOS1pBA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:23.653	2026-05-11 10:03:23.653
7259c99a-34aa-4aad-bc2c-04fdb79034e6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8591273844798509117	\N	\N	Đặng Đức Minh Quang	https://s120-25-ava-talk.zadn.vn/14/571d1d240bfb31b814eb8880b2d76c66.jpg?key=haNy-EfTn_cmSgZqwXFDjw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:28.255	2026-05-11 10:03:28.255
341f9234-5f34-4cfa-bb9a-2a741c3911be	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7438063194402374462	\N	\N	Đào Ngọc Huy	https://s120-25-ava-talk.zadn.vn/13/7063441ea3f8f5e42d7b69b2bff858aa.jpg?key=qKdvvw4t2fCq_LH9uPp5TA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:32.858	2026-05-11 10:03:32.858
20c13288-42fe-48b0-ab1d-88cdf717900d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8342727054413244864	\N	\N	Trần Nguyễn Ngọc Quý	https://s120-25-ava-talk.zadn.vn/2/6fd61835f2f1207733488db75eec7a65.jpg?key=rd5cnXLZ2As_SwZvGMJN4Q&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:37.462	2026-05-11 10:03:37.462
6d9a5797-79b2-4dc0-8557-7efc0204b535	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6491652595667357969	\N	\N	Triệu Hoàng Vinh	https://s120-25-ava-talk.zadn.vn/4/142786e2e28893f800bd68c5fd174cc5.jpg?key=rH8kzCIC-0etBfO2d6qD_Q&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:42.08	2026-05-11 10:03:42.08
cb65ca7a-8779-4e13-8c2e-0c3b2c1bb376	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7024021364864157309	\N	\N	Kim Tiền 阿銭	https://s120-25-ava-talk.zadn.vn/60/1ee3ebfbe6a912159ed4fa0cc1df90bd.jpg?key=oNgNNLzGLa3kprWuP5-8Rg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:46.685	2026-05-11 10:03:46.685
1a33ba2c-2daa-4631-9495-f0d09520eb9a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8489507024238786775	\N	\N	Lê Thị Khánh Ly	https://s120-25-ava-talk.zadn.vn/18/c85e9004e94778ffa4379bd46b2e292a.jpg?key=8ImCGQWiq_ITI3ZhDjD1WQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:51.299	2026-05-11 10:03:51.299
3a667ae2-e2c3-4ff3-abde-62e1f79677fa	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3307485938597615329	\N	\N	Gạch men Tài Phát Lộc	https://s120-25-ava-talk.zadn.vn/7/0f19a7a96d742a8865aa35b726e02d71.jpg?key=jT2WNcpvye-k4OB-LRxtVw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:03:55.892	2026-05-11 10:03:55.892
289542fd-f7d9-4cf7-aec2-64bfb62b9536	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8574809374670427384	\N	\N	Hoàng Quốc Tú	https://s120-25-ava-talk.zadn.vn/5/deb324c989c197b41d04a2385801efd7.jpg?key=gVm1qVtMCtZbS43M7gGiRQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:00.488	2026-05-11 10:04:00.488
44b0021d-c89a-4ec0-b1b5-62b5cbf4cc4b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8222811147174081050	\N	\N	Thanh Trần	https://s120-25-ava-talk.zadn.vn/6/78ed14391a8ec8488e9d2026c8644c0e.jpg?key=FR8ZkH4R4LUwoLLGg0jyGQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:05.094	2026-05-11 10:04:05.094
f8b1bf40-35f1-4f85-9ad4-327f906af23d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8512023950613203751	\N	\N	Bích Ngọc	https://s120-25-ava-talk.zadn.vn/5/0c4b461d4d67106056d5c0787872024a.jpg?key=dt99vrkIImaPPPfge0VndQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:09.695	2026-05-11 10:04:09.695
5395497b-1e05-45d4-bdd9-b77734b8b0b1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3617953891114654258	\N	\N	Mẫn Trần	https://s120-25-ava-talk.zadn.vn/44/f107b26f61e71aaa9a17e938bcc605eb.jpg?key=cx_4IIeRbA_f2ha9GvMiDg&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:14.298	2026-05-11 10:04:14.298
907712fd-ec75-411e-991f-cbe6b8e209c5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	750600057280920941	\N	\N	Phạm Văn Trường Sơn	https://s120-25-ava-talk.zadn.vn/16/855f61583995956a091f3b2161cb740a.jpg?key=GAE1mwHYhpowAFAe9rkOAQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:18.897	2026-05-11 10:04:18.897
1bffa299-131f-49aa-b019-b5d3e60a430a	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5930664149914059338	\N	\N	Hải Huy	https://s120-25-ava-talk.zadn.vn/8/66389049cb0bc56f850c7d8826af856e.jpg?key=gEE3JzXQbC9JwAgIWWssPA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:23.491	2026-05-11 10:04:23.491
39018dc1-1eb8-4a54-9cce-662cf3fa87ef	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2880504870176932862	\N	\N	Hữu Toàn	https://s120-25-ava-talk.zadn.vn/51/6f9454a94f97fb371ec865e7f728b1bc.jpg?key=8mppwNeLhG9Cx_tnfCNt6w&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:28.096	2026-05-11 10:04:28.096
5d396f79-c9a0-4513-8c9c-95b059d358c9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	60130993113843922	\N	\N	Lam	https://s120-25-ava-talk.zadn.vn/14/08f26d1bd7e16d923ea1639160ccae6e.jpg?key=DavSYJYwn-2BoX3EKmmlkQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:32.743	2026-05-11 10:04:32.743
4c985af6-df1c-4c66-82e3-3a29776c94a3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4149230829009219986	\N	\N	Lê Đức Huy	https://s120-25-ava-talk.zadn.vn/5/64bd5c2dc7c371a9d91c0c5396626472.jpg?key=LFVQO_CliNlzOLIoIEMQYQ&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:37.351	2026-05-11 10:04:37.351
488b1edb-4339-42b9-93b6-3c7273544494	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6947579459661502317	\N	\N	Trương Luân	https://s120-25-ava-talk.zadn.vn/6/51d718484e2cc90f498c052d22b564b7.jpg?key=sm0wi2c6yzPynIHmdRcG1A&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:41.948	2026-05-11 10:04:41.948
69974dc0-2482-4d01-82c1-dcbf52932cd4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3628368534594254173	\N	\N	Phạm Mỹ Cảnh	https://s120-25-ava-talk.zadn.vn/6/d5039db149b35bfc8432d84bb5f39a47.jpg?key=d6DSmtGYS7g94pCdJ4YFug&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:46.545	2026-05-11 10:04:46.545
b8b8f28d-181a-4d4f-8f33-760a9cfa6770	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8361295753266978830	\N	\N	Ngo Bao	https://s120-25-ava-talk.zadn.vn/26/480d9313ae1b2883e6267996593a5608.jpg?key=dtAITA7EUBtEqlYrsGPpOA&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:51.154	2026-05-11 10:04:51.154
da9ca3f0-d8ad-44c4-bd92-271e8a2fb91e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3670032301056967145	\N	\N	Y O U R S A L E S	https://s120-25-ava-talk.zadn.vn/22/89f4dbf88e23d24da6f241f0ff7b9164.jpg?key=Mc5StqE5tGjIJsHavfSagw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:04:55.752	2026-05-11 10:04:55.752
3aab0693-3131-4722-8d80-69d620e0f002	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1336769012085064330	\N	\N	Thanh Phong	https://s120-25-ava-talk.zadn.vn/14/c55d9c9b477810e72376159304a525e8.jpg?key=_Cbe_qczB2Kck5jbG8qp9A&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:05:00.352	2026-05-11 10:05:00.352
4a210a8f-7616-447c-8a2d-2b8acc58caa5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9056702170060804008	\N	\N	Nhân Thăng	https://s120-25-ava-talk.zadn.vn/1/7c003b200e72b237e2587055f1d34f72.jpg?key=DQ83A2gwgNf7F7bu4FTXQw&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:05:04.956	2026-05-11 10:05:04.956
2e0429ae-8d2b-499f-b410-3076f64ec09c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5899850777258929383	\N	\N	Hồng Phát - Mss Thảo	https://s120-25-ava-talk.zadn.vn/1/88bd263651189baef401eb8f8a522233.jpg?key=LInBvHRn24BltQr_dvMb4w&time=1783677434	\N	\N	\N	new	\N	\N	\N	[]	{}	2026-05-11 10:05:09.558	2026-05-11 10:05:09.558
fabaf9c3-39cd-4935-8153-8bc38d56f901	ecae3be0-2ff7-4547-bf7a-308be16a20ad	247597133607989608	\N	\N	Lập_Trình_Web_ChiềuT4😗	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:14.371	2026-05-11 10:05:14.371
724cac67-246f-499f-b98c-8f5a9174bf81	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4577395869554549889	\N	\N	21DTH3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:19.192	2026-05-11 10:05:19.192
f90e329c-c1e1-4289-9eb0-0d6af36ba191	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6378755474033425	\N	\N	CNXHKH_0070173.4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:23.891	2026-05-11 10:05:23.891
3e65d35e-771c-4e98-84d2-03ab010f89a0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6177519038509347517	\N	\N	phương pháp tính	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:28.648	2026-05-11 10:05:28.648
20457366-c7e4-4fd2-9e6b-17f52ce490c4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1378859464005364773	\N	\N	3 Thằng Nhóc	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:33.386	2026-05-11 10:05:33.386
bfe2efc6-adf0-485b-89db-10ecbada7d28	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3983472672505193039	\N	\N	Đề tài tốt nghiệp Ai agent - 2025-2026	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:38.151	2026-05-11 10:05:38.151
e8ded057-b410-4e0e-b251-e852fc0cc94d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8094742771760347985	\N	\N	Đầu Tư Kiếm Thu Nhập	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:42.89	2026-05-11 10:05:42.89
7ae9d3c0-701b-4cd6-a607-c2a8d8c03d0b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7046568866673571533	\N	\N	XẾP CHỮ 30-4 (NHÓM 2)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:47.629	2026-05-11 10:05:47.629
1ae41347-8633-4366-8b94-2ba0f6ab85ea	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3801643491372886981	\N	\N	Bot_Fb_CmtNew	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:52.4	2026-05-11 10:05:52.4
f03d823f-fd8d-426d-9638-fa99f0bead29	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5422166373520501048	\N	\N	PLĐC tiết 101112 ( group 2)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:05:57.177	2026-05-11 10:05:57.177
561b337a-2c16-4f51-9341-f558e4827a58	ecae3be0-2ff7-4547-bf7a-308be16a20ad	461662787190518639	\N	\N	Gia đình mình	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:11.23	2026-05-11 10:12:11.23
1c200ef2-5359-4bfc-b2be-134b2c805722	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8824073806647235186	\N	\N	Ngày hội việc làm Sân bay Long Thành	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:01.899	2026-05-11 10:06:01.899
7352cea5-f530-4778-b736-71d5fc58cd26	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2341451846483559289	\N	\N	NHÓM HỖ TRỢ CÔNG TÁC NHẬP HỌC	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:06.671	2026-05-11 10:06:06.671
c13bcc0a-64ef-48c9-bcae-3bebf125fac3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9094124477512472371	\N	\N	TA chuyên ngành CNTT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:11.394	2026-05-11 10:06:11.394
6a4a7a47-238a-4dce-b4f1-65964610ba89	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7092169329974023019	\N	\N	Ốc Tiêu ( Thông Báo )	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:16.087	2026-05-11 10:06:16.087
68e6110b-e2f4-448c-9ce7-f3f114f3b739	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7562604454813992692	\N	\N	Thứ 4-Lớp GDTC2 Bóng Đá(789)⚽️	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:20.784	2026-05-11 10:06:20.784
c6dc3d77-a102-4685-a18e-738248a18759	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4860181653371989109	\N	\N	KHOÁ LUẬN K17	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:25.518	2026-05-11 10:06:25.518
2667ea37-40e7-4229-a2c8-f19d974b70f0	ecae3be0-2ff7-4547-bf7a-308be16a20ad	89833810979300152	\N	\N	chơi game free không tốn lòn gì hết	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:30.207	2026-05-11 10:06:30.207
e891ca70-4766-4e22-b8aa-045d0674fb79	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1066570097551269578	\N	\N	Minh Lâm, Nguyễn Trinh, Trần Vy	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:34.933	2026-05-11 10:06:34.933
c3aebbcb-2825-4b36-ae82-d5b45b665eb5	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1501168729895460050	\N	\N	Nam tước	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:39.684	2026-05-11 10:06:39.684
7162e9e2-ef49-4253-a681-8679d544cecb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1775609764151337379	\N	\N	TKW_K17_ChiềuT3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:44.381	2026-05-11 10:06:44.381
625d5bb3-4e8e-4e32-8e22-e1fafb122ee4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4080573729362445478	\N	\N	tiểu đội 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:49.106	2026-05-11 10:06:49.106
cb16a4a0-3a0b-4e6d-a451-92bebbc7abfb	ecae3be0-2ff7-4547-bf7a-308be16a20ad	194539214468000948	\N	\N	Gia đình iu thương	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:53.855	2026-05-11 10:06:53.855
6155d36c-3c2d-4397-a5c7-4fb531ee642e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4071421918013728135	\N	\N	Nhóm 1 anh văn	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:06:58.619	2026-05-11 10:06:58.619
4738957d-d89e-4a84-a2f7-cfda03f130e2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8873600464055681826	\N	\N	BAN CHẤP HÀNH _ ĐOÀN KHOA CNTT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:03.339	2026-05-11 10:07:03.339
a5cde40b-4330-4ad8-bbec-152f935ef147	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2371019760478378720	\N	\N	Rss	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:08.043	2026-05-11 10:07:08.043
c58e28f4-8014-4bf6-88c8-92266c559994	ecae3be0-2ff7-4547-bf7a-308be16a20ad	246336029840242028	\N	\N	LEO SLAYER VÀ NHỮNG NGƯỜI BẠN LORDS MOBILE	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:12.817	2026-05-11 10:07:12.817
94a37959-459d-41d9-8480-bfffd2e81553	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2079734372083228123	\N	\N	Nhóm Kỹ Năng Mềm Real	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:17.577	2026-05-11 10:07:17.577
1e5054c8-be96-48fa-9f86-c822b877af41	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7543749161732064695	\N	\N	Iot chiều thứ 5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:22.356	2026-05-11 10:07:22.356
484110fb-fb45-4ac8-b3b7-1955bcd8fc94	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6124175347389412602	\N	\N	Nhóm làm TKHTM	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:27.11	2026-05-11 10:07:27.11
f85bbbae-92d5-40e4-8b37-9940c5ba7117	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2722567677942886607	\N	\N	22_23_Hệ quản trị Cơ sở dữ liệu_sáng thứ 3	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:31.795	2026-05-11 10:07:31.795
dc4c1533-49c8-44f6-905f-c8c7440e6220	ecae3be0-2ff7-4547-bf7a-308be16a20ad	590289547735442486	\N	\N	Nhóm 2 (51-100)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:36.505	2026-05-11 10:07:36.505
6e45816f-bcfa-4be1-a3e4-f2733526fc59	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8595229808384254543	\N	\N	Test5s	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:41.229	2026-05-11 10:07:41.229
451e3064-1fc0-4f4f-aa88-397cec127e02	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5331263858931509499	\N	\N	THDC-K21-CT5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:46	2026-05-11 10:07:46
5a119728-17e9-46ef-9075-67369bf585b9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2609045895282789426	\N	\N	Báo con 🐆🐆🐆	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:50.72	2026-05-11 10:07:50.72
b4761ce8-7a28-4d49-8c87-fc8471d624a6	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3649196476822293411	\N	\N	CTV	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:07:55.435	2026-05-11 10:07:55.435
59024efe-9c42-4fbf-b817-485e68e2a6b8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5899788998825389287	\N	\N	THỰC TẬP - 1CAR GARA BIÊN HÒA	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:00.174	2026-05-11 10:08:00.174
381a3fa2-5ba1-43fb-8ca3-39ff8a0242ca	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1909286789282003064	\N	\N	CNTT_Khóa 17 (21DTH)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:04.931	2026-05-11 10:08:04.931
a7c017cd-8310-4093-b27b-bd9309108a05	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5665346085205363864	\N	\N	Cô Liệu hướng dẫn thực tập 25_26	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:09.61	2026-05-11 10:08:09.61
90efb501-8d3a-4803-aea3-02ec1eb07ade	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4448177584679525308	\N	\N	Nhóm 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:14.325	2026-05-11 10:08:14.325
072e87e4-3986-412b-986c-2291a1111985	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5716733438302127954	\N	\N	HK2.2223 TT3. LĐQL Kết Thúc hP	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:19.012	2026-05-11 10:08:19.012
7f12d736-ae88-445b-8f2d-3aa96c6d8eb8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8696121609163951017	\N	\N	CHUYÊN ĐỀ CÔNG NGHỆ MẠNG	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:23.744	2026-05-11 10:08:23.744
1a12582d-79da-43cf-ae9d-491fb51b209d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8810000927059780676	\N	\N	Team Thực tập	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:28.482	2026-05-11 10:08:28.482
5ab424f7-8a32-47d9-88ca-c65e5f2b8df8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8063689222712825312	\N	\N	Website 1CAR Talent - HIỆP IT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:33.171	2026-05-11 10:08:33.171
e2a33ac8-e50f-48d7-bab4-d19998af4ec9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7271754842298225645	\N	\N	Training 3D - Online	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:37.947	2026-05-11 10:08:37.947
2fb1d892-d737-446b-b512-645b76d847a4	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1051917401023679134	\N	\N	Cung ứng việc làm DNTU 4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:42.705	2026-05-11 10:08:42.705
a7b5be40-75ff-4d5c-a588-3c56571c353f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4051302576088915006	\N	\N	PT_TK_Hệ Thống 😗	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:47.416	2026-05-11 10:08:47.416
3393d56f-7821-4449-b2bc-9d9496c42800	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9159988405536881689	\N	\N	HỖ TRỢ BỔ SUNG NGÀY CTXH CHO SINH VIÊN KHÓA CŨ	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:52.181	2026-05-11 10:08:52.181
8b5dd0bf-6d3f-4b10-a876-4679ec68fa5f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6554847223799984368	\N	\N	Đội Nhóm Trưởng	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:08:56.865	2026-05-11 10:08:56.865
b8ee6c37-5a26-4596-a19b-cc8daf8de65f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2472482735985192791	\N	\N	Quản trị mạng Tối 3 - 2023	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:01.587	2026-05-11 10:09:01.587
c35bb2ba-e5ff-49a0-a142-9a8d988cdd32	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3395217839606115353	\N	\N	NGÀY HỘI VIỆC LÀM 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:06.347	2026-05-11 10:09:06.347
2687ba76-548f-4e8b-9ef5-29a708b1bac2	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5004171251156036213	\N	\N	scam	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:11.073	2026-05-11 10:09:11.073
7143a3fc-6c07-4de9-8a24-96a727b9ddb3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3629778638870278232	\N	\N	CTDL_GT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:15.79	2026-05-11 10:09:15.79
1e082f15-9faa-41a5-aa37-1a126c140931	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9003638150981980916	\N	\N	nhóm kỹ năng lãnh đạo và quản lý	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:20.515	2026-05-11 10:09:20.515
717fe714-1888-459a-a9e8-dc20be3debd8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1153111552709004551	\N	\N	1153111552709004551	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:25.285	2026-05-11 10:09:25.285
b5f2c490-efdd-42e6-be2a-6d11a7d53667	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5329419338022822386	\N	\N	Nhóm 6 công nghệ mạng nâng cao	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:30.044	2026-05-11 10:09:30.044
0152501a-fba7-4190-a41f-9cc58d5fba60	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1747311573792176696	\N	\N	Ngọc Rồng Origin - Box Chat	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:34.788	2026-05-11 10:09:34.788
30734f59-07e4-443d-81b5-e55a044e1ebe	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3103705119462499349	\N	\N	Chúng tớ là 12A3🤟🤟🤟	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:39.519	2026-05-11 10:09:39.519
354a9040-1276-4828-864c-17972b58d91c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8701468137926403270	\N	\N	Nhóm 1600-1592	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:44.311	2026-05-11 10:09:44.311
f2c35055-e5b0-41a4-aa02-9f042e77ab61	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1151566821602093564	\N	\N	Cung ứng việc làm DNTU 6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:49.016	2026-05-11 10:09:49.016
b4d219ba-3e53-4caa-b38a-48c080f382ca	ecae3be0-2ff7-4547-bf7a-308be16a20ad	98134877466640475	\N	\N	nhóm kn khởi nghiệp	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:53.787	2026-05-11 10:09:53.787
21c11d37-9280-42fb-9b2a-34c6c340f8fc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2001866012699840207	\N	\N	1CAR - YOURSALES - SMS OTP	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:09:58.52	2026-05-11 10:09:58.52
73a31489-4431-4708-860c-633c3539b461	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6762098583920416720	\N	\N	CloudFly - Hỗ trợ sử dụng N8N DashBoard	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:03.251	2026-05-11 10:10:03.251
7d132294-10f4-45e3-bcf7-3d3b65c1c386	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7252331083136097442	\N	\N	VPBank Technology Hackathon 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:08.035	2026-05-11 10:10:08.035
c9c25fad-f4ff-48b4-b59e-a8481047f4b9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3746463315222450425	\N	\N	Fitness T1-3 Thứ 6(09/01/26)	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:12.746	2026-05-11 10:10:12.746
5ef94fbb-1b09-400c-a4c4-65ec86dbc5ee	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1756471503292523879	\N	\N	HK2.2223 TT3-G303 Quản Lý 0879163839 Lt đ Hoài	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:17.457	2026-05-11 10:10:17.457
439aa67d-d8d2-40b5-8fb7-0ce9ffb02a49	ecae3be0-2ff7-4547-bf7a-308be16a20ad	997865888976390622	\N	\N	NTB 1633	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:22.199	2026-05-11 10:10:22.199
dc1d046b-9149-4202-8c90-c40afb732fbe	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5698296576008898067	\N	\N	nhóm 3, công nghệ phần mền	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:26.912	2026-05-11 10:10:26.912
c7cbd1e3-ef1d-4535-a5db-0585c773c1ec	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2118997815892830319	\N	\N	Check bot	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:31.663	2026-05-11 10:10:31.663
11243b6e-e7ec-49c9-bc9f-c46b213fd5be	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1647900920563946969	\N	\N	1647900920563946969	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:36.404	2026-05-11 10:10:36.404
02fa8e45-724c-46df-a883-3f117347086f	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2101414264399767854	\N	\N	Đại đội 5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:41.151	2026-05-11 10:10:41.151
52b0db93-ac00-423c-9a50-c9f3529e2197	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9157460395104401170	\N	\N	Ngọc Rồng Private - Hỗ Trợ	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:45.923	2026-05-11 10:10:45.923
aea54fad-e6f9-429b-8a2d-edeeca0b219d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7907981006912605881	\N	\N	ĐOÀN THANH NIÊN - KHOA -CNTT -TT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:50.672	2026-05-11 10:10:50.672
16fc6579-9bcc-4457-b297-ae223bd6b6a3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5689422030318315507	\N	\N	Chém gió 1580	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:10:55.398	2026-05-11 10:10:55.398
1b9db60d-1933-4409-9682-a139d6d94f0b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5860025765213937237	\N	\N	Thi Tiếng Anh CDR- TTNN-TH	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:00.204	2026-05-11 10:11:00.204
ea974ac8-2994-46a0-b39a-684dd321bc42	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2435749988293865930	\N	\N	THIẾT KẾ HỆ THỐNG MẠNG_SÁNG 4	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:04.954	2026-05-11 10:11:04.954
dbf4c6f7-24bb-466d-8869-9100ec2cfa73	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1188675449747403384	\N	\N	K17_NHÓM TRƯỞNG KHÓA LUẬN	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:09.673	2026-05-11 10:11:09.673
bfc26560-f32b-46c5-b3ed-9e30f1fe9815	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1728961364013020409	\N	\N	Sinh viên tốt nghiệp đợt 3 2025-2026	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:14.39	2026-05-11 10:11:14.39
a5138f86-3813-48d7-b3e5-3d6576bb919d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1243418431723785542	\N	\N	K17_HỖ TRỢ XIN THỰC TẬP_KHOA CNTT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:19.091	2026-05-11 10:11:19.091
2ecbc58b-5950-4c19-b5a0-39a76ecf9462	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2428851805107554738	\N	\N	ppnckh nhóm 2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:23.789	2026-05-11 10:11:23.789
37f59908-7606-4640-9e25-21ed31acbddc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	138255639096981484	\N	\N	Nhóm 1| Bockchain	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:28.547	2026-05-11 10:11:28.547
ce2d969e-fa0f-4203-bead-683c42637785	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1342984663005375652	\N	\N	2025 TACN Chieu T4 T6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:33.284	2026-05-11 10:11:33.284
106f050c-547d-41cc-ae3f-13a3b0f70554	ecae3be0-2ff7-4547-bf7a-308be16a20ad	343302843501501124	\N	\N	Ae T4 VnH kingdom 1600	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:37.997	2026-05-11 10:11:37.997
f51e5435-c017-4d46-99ea-50527d8f85c3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7911211198102223565	\N	\N	Registration: VPBank Technology Hackathon 2025	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:42.76	2026-05-11 10:11:42.76
a85e62b0-6a7f-4947-b1e7-a85c88727861	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6825624186729331390	\N	\N	Bơi Lội - Thứ 4 - Tiết 7-10	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:47.479	2026-05-11 10:11:47.479
89241a69-012f-4c13-8844-a1777b98eb22	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3166179562918692599	\N	\N	HK1_2025_ThiGiaMayTinh_8.5 Chieu T5	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:52.17	2026-05-11 10:11:52.17
81f8fd78-70c1-481c-a099-4e3d2158fd25	ecae3be0-2ff7-4547-bf7a-308be16a20ad	7249519188486840988	\N	\N	Thực tập IMT	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:11:56.93	2026-05-11 10:11:56.93
b8f19106-9e2a-421e-80be-25d7995e3674	ecae3be0-2ff7-4547-bf7a-308be16a20ad	6046630024602298350	\N	\N	PPNCKH thứ 3, 4,5,6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:01.672	2026-05-11 10:12:01.672
a65a219a-3bcf-4ac1-ada6-59d630db1371	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5898439783757551580	\N	\N	Chiều thứ 2_Phân tích thiết kế hệ thống	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:06.415	2026-05-11 10:12:06.415
4a218d8d-bc52-4853-8b31-86392d7748d1	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8483183673842586301	\N	\N	8483183673842586301	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:15.985	2026-05-11 10:12:15.985
728f3070-fe4c-4824-a954-af33402ad77e	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4355685771079308149	\N	\N	Cấu trúc rời rạc	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:20.749	2026-05-11 10:12:20.749
b82d86c1-dbbb-4bb7-8e91-b819c7e45dee	ecae3be0-2ff7-4547-bf7a-308be16a20ad	4527671274784814802	\N	\N	Lư Văn Anh Tứ, Đình Trường, Nhật Nguyễn	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:25.466	2026-05-11 10:12:25.466
f6461095-5458-4c05-b6e0-d51dddf28052	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5388660826290233295	\N	\N	test5s-2	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:30.147	2026-05-11 10:12:30.147
1d44cc78-e497-48f3-bdc9-87ebe2b22b2d	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8511069149540513306	\N	\N	8511069149540513306	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:34.917	2026-05-11 10:12:34.917
0e1fb10d-04f3-4426-ab2b-61cfdfefd8b3	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8231969568510759482	\N	\N	Khôi Bad, Trần Nghĩa Hiệp,...	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:39.643	2026-05-11 10:12:39.643
874a9a51-3f9f-4cc5-bd57-1103cc486a7c	ecae3be0-2ff7-4547-bf7a-308be16a20ad	8894569411149203816	\N	\N	nhóm làm bài	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:44.35	2026-05-11 10:12:44.35
03a2ed74-f2a9-4913-87f6-fbc11b7c4147	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3372361451628068554	\N	\N	Huy, Đậu, Trần Nghĩa Hiệp	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:49.062	2026-05-11 10:12:49.062
3e1ed0a3-cc95-48d0-9a12-b548d7bd12e9	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3607273294922883080	\N	\N	Nhóm 8 CSDL nâng cao	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:53.844	2026-05-11 10:12:53.844
dcb1c62f-96d2-416e-82ef-97d4b157dff8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	1523818911020526882	\N	\N	Trí tuệ nhân tạo 123	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:12:58.612	2026-05-11 10:12:58.612
644e6915-bf66-4a61-b964-01523af5fe4b	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5193452114407638805	\N	\N	A1 thi 17/6	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:13:03.331	2026-05-11 10:13:03.331
4291656e-f333-4f04-b9be-5f328c0bf4cc	ecae3be0-2ff7-4547-bf7a-308be16a20ad	5296627932035274118	\N	\N	GIẢI TRÍ - 1CAR	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:13:08.084	2026-05-11 10:13:08.084
d4e4ce4c-9df5-42d3-978d-9aa58cc2de94	ecae3be0-2ff7-4547-bf7a-308be16a20ad	2334852433584249440	\N	\N	CNMNC2 s56 g202	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:13:12.809	2026-05-11 10:13:12.809
411d109c-93dc-4464-a54e-465f929639de	ecae3be0-2ff7-4547-bf7a-308be16a20ad	3395582845455412504	\N	\N	Hết Cứu 🧠🧠🧠🧠🧠	\N	\N	\N	\N	new	\N	\N	\N	[]	{"isGroup": true}	2026-05-11 10:13:17.517	2026-05-11 10:13:17.517
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.conversations (id, org_id, zalo_account_id, contact_id, "threadType", external_thread_id, last_message_at, unread_count, is_replied, created_at) FROM stdin;
\.


--
-- Data for Name: daily_message_stats; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.daily_message_stats (id, org_id, user_id, zalo_account_id, stat_date, messages_sent, messages_received, messages_unread, messages_unreplied, avg_response_time_seconds) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.messages (id, conversation_id, zalo_msg_id, sender_type, sender_uid, sender_name, content, content_type, attachments, is_deleted, deleted_at, sent_at, replied_by_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.orders (id, org_id, contact_id, created_by_user_id, conversation_id, order_code, total_amount, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.organizations (id, name, created_at, updated_at) FROM stdin;
ecae3be0-2ff7-4547-bf7a-308be16a20ad	1car	2026-05-02 04:55:34.533	2026-05-02 04:55:34.533
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.teams (id, org_id, name, created_at) FROM stdin;
9f96990a-679a-4962-8451-25d7d683ed47	ecae3be0-2ff7-4547-bf7a-308be16a20ad	makeeting	2026-05-02 06:05:19.012
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.users (id, org_id, team_id, email, password_hash, full_name, role, is_active, created_at, updated_at) FROM stdin;
e533888b-4c79-42d5-ab7b-7c25b35d6bc8	ecae3be0-2ff7-4547-bf7a-308be16a20ad	\N	hiephiep1002@gmail.com	$2b$12$0eaUaEl86Kxp8ex34agFAOcxfLv2pYaXL78NL7YU2jYkTxKANjuae	hiep	owner	t	2026-05-02 04:55:34.563	2026-05-02 04:55:34.563
fffd31b7-2279-4069-b124-6ef85d977285	ecae3be0-2ff7-4547-bf7a-308be16a20ad	9f96990a-679a-4962-8451-25d7d683ed47	hiephiep10023@gmail.com	$2b$10$kiXYOPwRgx14/gFMuWhDd..4oFvfS9s0yhD2iTJLMofabwxJg3oEa	trần nghĩa hiệp	member	t	2026-05-02 06:05:00.419	2026-05-02 06:05:27.091
\.


--
-- Data for Name: zalo_account_access; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.zalo_account_access (id, zalo_account_id, user_id, permission, created_at) FROM stdin;
\.


--
-- Data for Name: zalo_accounts; Type: TABLE DATA; Schema: public; Owner: crmuser
--

COPY public.zalo_accounts (id, org_id, owner_user_id, zalo_uid, display_name, avatar_url, phone, status, session_data, last_connected_at, created_at) FROM stdin;
9e323aaa-c1c6-4ffc-9683-6dfd26825d91	ecae3be0-2ff7-4547-bf7a-308be16a20ad	e533888b-4c79-42d5-ab7b-7c25b35d6bc8	\N	hiep	\N	\N	qr_pending	\N	\N	2026-05-11 10:31:34.611
\.


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: daily_message_stats daily_message_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: zalo_account_access zalo_account_access_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_pkey PRIMARY KEY (id);


--
-- Name: zalo_accounts zalo_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_pkey PRIMARY KEY (id);


--
-- Name: app_settings_org_id_setting_key_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX app_settings_org_id_setting_key_key ON public.app_settings USING btree (org_id, setting_key);


--
-- Name: conversations_zalo_account_id_external_thread_id_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX conversations_zalo_account_id_external_thread_id_key ON public.conversations USING btree (zalo_account_id, external_thread_id);


--
-- Name: daily_message_stats_user_id_zalo_account_id_stat_date_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX daily_message_stats_user_id_zalo_account_id_stat_date_key ON public.daily_message_stats USING btree (user_id, zalo_account_id, stat_date);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: zalo_account_access_zalo_account_id_user_id_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX zalo_account_access_zalo_account_id_user_id_key ON public.zalo_account_access USING btree (zalo_account_id, user_id);


--
-- Name: zalo_accounts_zalo_uid_key; Type: INDEX; Schema: public; Owner: crmuser
--

CREATE UNIQUE INDEX zalo_accounts_zalo_uid_key ON public.zalo_accounts USING btree (zalo_uid);


--
-- Name: activity_logs activity_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: app_settings app_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: appointments appointments_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contacts contacts_assigned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_assigned_user_id_fkey FOREIGN KEY (assigned_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contacts contacts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: conversations conversations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: daily_message_stats daily_message_stats_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: daily_message_stats daily_message_stats_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.daily_message_stats
    ADD CONSTRAINT daily_message_stats_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_replied_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_replied_by_user_id_fkey FOREIGN KEY (replied_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: teams teams_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: zalo_account_access zalo_account_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_account_access zalo_account_access_zalo_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_account_access
    ADD CONSTRAINT zalo_account_access_zalo_account_id_fkey FOREIGN KEY (zalo_account_id) REFERENCES public.zalo_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_accounts zalo_accounts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: zalo_accounts zalo_accounts_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crmuser
--

ALTER TABLE ONLY public.zalo_accounts
    ADD CONSTRAINT zalo_accounts_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict fGMot6HPmhtbnojvST5opxGTL9DmixeuUWlyQL2OWmoxzhMjG2MLeAU6Z0IaFGW

